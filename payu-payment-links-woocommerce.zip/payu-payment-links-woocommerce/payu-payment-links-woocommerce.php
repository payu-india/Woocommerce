<?php
/**
 * Plugin Name: PayU Payment Links for WooCommerce
 * Plugin URI: https://docs.payu.in/
 * Description: Create, share, and track PayU payment links from WooCommerce. Multi-currency support, settlement UTR reconciliation, and full PayU Payment Links API integration.
 * Version: 1.0.0
 * Author: PayU
 * Author URI: https://payu.in/
 * Text Domain: payu-payment-links-woocommerce
 * Domain Path: /languages
 * Requires at least: 5.9
 * Requires PHP: 7.4
 * WC requires at least: 7.0
 * WC tested up to: 9.x
 *
 * @package PayU_Payment_Links_WooCommerce
 */

defined( 'ABSPATH' ) || exit;

define( 'PAYU_PAYMENT_LINKS_VERSION', '1.0.0' );
define( 'PAYU_PAYMENT_LINKS_PLUGIN_FILE', __FILE__ );
define( 'PAYU_PAYMENT_LINKS_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'PAYU_PAYMENT_LINKS_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'PAYU_PAYMENT_LINKS_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

/** Replace with actual UTM URL when provided by PayU. */
define( 'PAYU_SIGNUP_UTM_URL', 'https://payu.in/' );

/* ---------------------------------------------------------------
 * Activation: create custom DB table.
 * ------------------------------------------------------------- */

register_activation_hook( __FILE__, 'payu_payment_links_activate' );

function payu_payment_links_activate() {
	require_once PAYU_PAYMENT_LINKS_PLUGIN_DIR . 'includes/class-payu-db.php';
	PayU_DB::create_table();
}

/* ---------------------------------------------------------------
 * Deactivation: clear cron.
 * ------------------------------------------------------------- */

register_deactivation_hook( __FILE__, 'payu_payment_links_deactivate' );

function payu_payment_links_deactivate() {
	wp_clear_scheduled_hook( 'payu_payment_links_fetch_utr' );
	wp_clear_scheduled_hook( 'payu_payment_links_poll_refunds' );
	wp_clear_scheduled_hook( 'payu_payment_links_poll_txns' );
	// Clear any pending single-event reconciliation jobs.
	wp_unschedule_hook( 'payu_payment_links_webhook_reconcile' );
}

/* ---------------------------------------------------------------
 * Dependency check.
 * ------------------------------------------------------------- */

function payu_payment_links_woocommerce_check_dependencies() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		add_action( 'admin_notices', function () {
			?>
			<div class="notice notice-error">
				<p><?php esc_html_e( 'PayU Payment Links for WooCommerce requires WooCommerce to be installed and active.', 'payu-payment-links-woocommerce' ); ?></p>
			</div>
			<?php
		} );
		return false;
	}
	return true;
}

/* ---------------------------------------------------------------
 * Bootstrap.
 * ------------------------------------------------------------- */

function payu_payment_links_woocommerce_init() {
	if ( ! payu_payment_links_woocommerce_check_dependencies() ) {
		return;
	}

	require_once PAYU_PAYMENT_LINKS_PLUGIN_DIR . 'includes/class-payu-db.php';
	require_once PAYU_PAYMENT_LINKS_PLUGIN_DIR . 'includes/class-payu-config.php';
	require_once PAYU_PAYMENT_LINKS_PLUGIN_DIR . 'includes/class-payu-exceptions.php';
	require_once PAYU_PAYMENT_LINKS_PLUGIN_DIR . 'includes/class-payu-error-handler.php';
	require_once PAYU_PAYMENT_LINKS_PLUGIN_DIR . 'includes/class-payu-api-client.php';
	require_once PAYU_PAYMENT_LINKS_PLUGIN_DIR . 'includes/class-payu-webhook-handler.php';
	require_once PAYU_PAYMENT_LINKS_PLUGIN_DIR . 'includes/class-payu-admin-order.php';
	require_once PAYU_PAYMENT_LINKS_PLUGIN_DIR . 'includes/class-payu-admin-manual-link.php';
	require_once PAYU_PAYMENT_LINKS_PLUGIN_DIR . 'includes/class-payu-list-page.php';
	require_once PAYU_PAYMENT_LINKS_PLUGIN_DIR . 'includes/class-payu-payment-links.php';

	PayU_Payment_Links::instance();
	new PayU_Admin_Order();
	new PayU_Admin_Manual_Link();
	new PayU_List_Page();
}

add_action( 'plugins_loaded', 'payu_payment_links_woocommerce_init', 20 );

/* ---------------------------------------------------------------
 * Declare HPOS compatibility.
 * ------------------------------------------------------------- */

add_action( 'before_woocommerce_init', function () {
	if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
	}
} );
