=== PayU Payment Links for WooCommerce ===

Contributors: PayU
Tags: woocommerce, payu, payment link, payment links, multi-currency
Requires at least: 5.9
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
WC requires at least: 7.0
WC tested up to: 9.x
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Create, share, and track PayU payment links from WooCommerce. Multi-currency support, settlement UTR reconciliation, and full PayU API integration.

== Description ==

A WooCommerce Admin plugin for B2B merchants to create payment links in multiple currencies, share them with buyers, and track + reconcile them back to WooCommerce orders.

= Features =

* **Multi-currency:** Configure multiple MIDs (one per currency) with separate credentials. Currency is selectable per link.
* **Create from Order:** Generate a payment link directly from the WooCommerce order edit screen.
* **Manual create:** Create a standalone payment link or attach it to an existing order.
* **Share via PayU API:** Share links to email addresses and phone numbers using the PayU Share Payment Link API.
* **Copy link:** Copy link URL for manual sharing via WhatsApp, SMS, or other channels.
* **List & filter:** View all payment links with date range filter, status, currency, and UTR number.
* **Detail view:** Full snapshot of a payment link including UDF audit fields, customer info, and UTR.
* **CSV export:** Export link history for a date range (includes UTR number).
* **Refresh status:** Fetch the latest status for a link from PayU (Get Single Payment Link API).
* **Sync statuses:** Bulk-sync all link statuses from PayU for a date range (Get All Payment Links API).
* **UTR reconciliation:** Daily WP-Cron job fetches UTR numbers from the PayU Settlement API for paid links.
* **Webhook handler:** Automatic order status update when payment is completed or fails.
* **Bulk generate:** Generate links for multiple orders at once from the orders list.
* **HPOS compatible:** Works with both legacy and High-Performance Order Storage.

= PayU APIs Used =

* Create Payment Link API
* Share Payment Link API
* Get Single Payment Link API
* Get All Payment Links API
* Settlement Reconciliation API (for UTR numbers)
* Get Token API (OAuth)

== Installation ==

1. Install WooCommerce if not already installed.
2. Upload the plugin folder to `/wp-content/plugins/` or install via WordPress admin.
3. Activate the plugin (this creates the `wp_payu_payment_links` database table).
4. Go to WooCommerce → Settings → PayU Payment Links and configure credentials.
5. Register the webhook URL with PayU: `https://yoursite.com/?payu_payment_link_webhook=1`

== Configuration ==

= Single Currency =

* **Environment:** Test (UAT) or Production.
* **Client ID / Client Secret:** OAuth credentials from PayU Dashboard.
* **Merchant ID:** Used in Payment Links API headers.
* **Merchant Key / Salt:** Used for Settlement API (UTR retrieval).

= Multi-Currency =

In the "Currency credentials" textarea, add one line per currency:
`CURRENCY,MERCHANT_ID,CLIENT_ID,CLIENT_SECRET,MERCHANT_KEY,SALT`

Example:
`INR,mid123,client_abc,secret_xyz,key_123,salt_456`
`USD,mid789,client_def,secret_uvw,key_789,salt_012`

== Changelog ==

= 1.0.0 =
* Initial release with full PRD scope.
* Custom database table for payment link storage.
* PayU Create, Share, Get, List, and Settlement APIs.
* Multi-currency credential switching.
* Per-link expiry date.
* UTR number reconciliation via Settlement API + daily cron.
* HPOS compatibility.
