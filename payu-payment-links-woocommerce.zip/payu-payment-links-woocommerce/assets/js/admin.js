/**
 * PayU Payment Links - Admin JS
 */
(function ($) {
	'use strict';

	var cfg = window.payuPaymentLinks || {};

	/* ---------------------------------------------------------------
	 * Helpers
	 * ------------------------------------------------------------- */

	function showMessage($ctx, text, isError) {
		var $msg = $ctx.find('.payu-message');
		if (!$msg.length) {
			$msg = $('<div class="payu-message"></div>').appendTo($ctx);
		}
		$msg.removeClass('error success').addClass(isError ? 'error' : 'success').text(text).show();
		if (!isError) {
			setTimeout(function () { $msg.fadeOut(); }, 6000);
		}
	}

	function copyToClipboard(text, onDone) {
		if (navigator.clipboard && navigator.clipboard.writeText) {
			navigator.clipboard.writeText(text).then(onDone).catch(function () {
				fallbackCopy(text); onDone();
			});
		} else {
			fallbackCopy(text); onDone();
		}
	}

	function fallbackCopy(text) {
		var inp = document.createElement('input');
		inp.value = text;
		document.body.appendChild(inp);
		inp.select();
		try { document.execCommand('copy'); } catch (e) { /* noop */ }
		document.body.removeChild(inp);
	}

	/* ---------------------------------------------------------------
	 * Order meta box: Copy link
	 * ------------------------------------------------------------- */

	$(document).on('click', '.payu-payment-link-box .payu-copy-link', function () {
		var $item = $(this).closest('.payu-link-item');
		var $box = $item.closest('.payu-payment-link-box');
		var url = $item.find('.payu-link-url').val();
		if (!url) return;
		copyToClipboard(url, function () {
			showMessage($box, cfg.i18n.copied, false);
		});
	});

	/* ---------------------------------------------------------------
	 * Order meta box: Generate link
	 * ------------------------------------------------------------- */

	$(document).on('click', '.payu-generate-link', function () {
		var $btn = $(this);
		var $box = $btn.closest('.payu-payment-link-box');
		var orderId = $box.data('order-id');
		if (!orderId) return;

		var expiryDate = $box.find('.payu-link-expiry').val() || '';
		var partialPayment = $box.find('.payu-partial-payment-override').is(':checked') ? '1' : '0';

		$btn.prop('disabled', true).text('Creating...');
		$.post(cfg.ajaxUrl, {
			action: 'payu_payment_links_generate',
			nonce: cfg.nonce,
			order_id: orderId,
			expiry_date: expiryDate,
			partial_payment: partialPayment
		}).done(function (res) {
			if (res.success) {
				showMessage($box, 'Payment link created.', false);
				// Redirect to the order edit page to ensure the link is visible.
				var editUrl = window.location.href;
				if (editUrl.indexOf('action=new') !== -1 || editUrl.indexOf('id=' + orderId) === -1) {
					editUrl = cfg.ajaxUrl.replace('admin-ajax.php', 'admin.php?page=wc-orders&action=edit&id=' + orderId);
				}
				window.location.href = editUrl;
			} else {
				showMessage($box, (res.data && res.data.message) || 'Error', true);
				$btn.prop('disabled', false).text('Generate new link');
			}
		}).fail(function () {
			showMessage($box, 'Request failed.', true);
			$btn.prop('disabled', false).text('Generate new link');
		});
	});

	/* ---------------------------------------------------------------
	 * Order meta box: Share link (toggle form + send)
	 * ------------------------------------------------------------- */

	$(document).on('click', '.payu-payment-link-box .payu-share-link', function () {
		$(this).closest('.payu-link-item').find('.payu-share-form').slideToggle(150);
	});

	$(document).on('click', '.payu-payment-link-box .payu-share-send', function () {
		var $item = $(this).closest('.payu-link-item');
		var $box = $item.closest('.payu-payment-link-box');
		var invoice = $item.data('invoice');
		var currency = $item.data('currency');
		var recipients = $item.find('.payu-share-recipients').val();

		if (!recipients) {
			showMessage($box, 'Enter at least one email or phone number.', true);
			return;
		}

		var $btn = $(this);
		$btn.prop('disabled', true).text('Sending...');
		$.post(cfg.ajaxUrl, {
			action: 'payu_payment_links_share',
			nonce: cfg.nonce,
			invoice_number: invoice,
			currency: currency,
			recipients: recipients
		}).done(function (res) {
			showMessage($box, (res.data && res.data.message) || (res.success ? 'Shared.' : 'Could not send.'), !res.success);
			if (res.success) {
				$item.find('.payu-share-form').slideUp(150);
				$item.find('.payu-share-recipients').val('');
			}
		}).fail(function () {
			showMessage($box, 'Could not send. Request failed.', true);
		}).always(function () {
			$btn.prop('disabled', false).text('Send');
		});
	});

	/* ---------------------------------------------------------------
	 * Order meta box: Expire link
	 * ------------------------------------------------------------- */

	$(document).on('click', '.payu-payment-link-box .payu-expire-link', function () {
		if (!confirm('Are you sure you want to expire this payment link? The customer will no longer be able to pay using this link.')) {
			return;
		}

		var $item = $(this).closest('.payu-link-item');
		var $box = $item.closest('.payu-payment-link-box');
		var linkId = $item.data('link-id');

		var $btn = $(this);
		$btn.prop('disabled', true).text('Expiring...');
		$.post(cfg.ajaxUrl, {
			action: 'payu_payment_links_expire',
			nonce: cfg.nonce,
			link_id: linkId
		}).done(function (res) {
			if (res.success) {
				showMessage($box, 'Payment link expired.', false);
				location.reload();
			} else {
				showMessage($box, (res.data && res.data.message) || 'Error', true);
				$btn.prop('disabled', false).text('Expire');
			}
		}).fail(function () {
			showMessage($box, 'Request failed.', true);
			$btn.prop('disabled', false).text('Expire');
		});
	});

	/* ---------------------------------------------------------------
	 * Order meta box: Refund link
	 * ------------------------------------------------------------- */

	$(document).on('click', '.payu-payment-link-box .payu-refund-link', function () {
		$(this).closest('.payu-link-item').find('.payu-refund-form').slideToggle(150);
	});

	$(document).on('click', '.payu-payment-link-box .payu-refund-submit', function () {
		var $item = $(this).closest('.payu-link-item');
		var $box = $item.closest('.payu-payment-link-box');
		var linkId = $item.data('link-id');
		var refundAmount = $item.find('.payu-refund-amount').val();

		if (!refundAmount || parseFloat(refundAmount) <= 0) {
			showMessage($box, 'Enter a valid refund amount.', true);
			return;
		}

		if (!confirm('Initiate refund of ' + refundAmount + '? This will process through PayU and cannot be undone.')) {
			return;
		}

		var $btn = $(this);
		$btn.prop('disabled', true).text('Processing...');
		$.post(cfg.ajaxUrl, {
			action: 'payu_payment_links_refund',
			nonce: cfg.nonce,
			link_id: linkId,
			refund_amount: refundAmount
		}).done(function (res) {
			if (res.success) {
				showMessage($box, (res.data && res.data.message) || 'Refund initiated.', false);
				location.reload();
			} else {
				showMessage($box, (res.data && res.data.message) || 'Refund failed.', true);
				$btn.prop('disabled', false).text('Confirm refund');
			}
		}).fail(function () {
			showMessage($box, 'Refund request failed.', true);
			$btn.prop('disabled', false).text('Confirm refund');
		});
	});

	/* ---------------------------------------------------------------
	 * Order meta box: Check refund status
	 * ------------------------------------------------------------- */

	$(document).on('click', '.payu-payment-link-box .payu-check-refund', function () {
		var $item = $(this).closest('.payu-link-item');
		var $box = $item.closest('.payu-payment-link-box');
		var linkId = $item.data('link-id');

		var $btn = $(this);
		$btn.prop('disabled', true).text('Checking...');
		$.post(cfg.ajaxUrl, {
			action: 'payu_payment_links_check_refund',
			nonce: cfg.nonce,
			link_id: linkId
		}).done(function (res) {
			if (res.success) {
				showMessage($box, (res.data && res.data.message) || 'Checked.', false);
				if (res.data && (res.data.refund_status === 'success' || res.data.refund_status === 'failure')) {
					location.reload();
				}
			} else {
				showMessage($box, (res.data && res.data.message) || 'Error', true);
			}
			$btn.prop('disabled', false).text('Check refund');
		}).fail(function () {
			showMessage($box, 'Request failed.', true);
			$btn.prop('disabled', false).text('Check refund');
		});
	});

	/* ---------------------------------------------------------------
	 * List page: Copy link
	 * ------------------------------------------------------------- */

	$(document).on('click', '.payu-copy-link-list', function (e) {
		e.preventDefault();
		var url = $(this).data('url');
		if (!url) return;
		copyToClipboard(url, function () {
			alert(cfg.i18n.copied || 'Copied.');
		});
	});

	$(document).on('click', '.payu-copy-detail', function () {
		var url = $(this).data('url');
		if (!url) return;
		copyToClipboard(url, function () {
			alert(cfg.i18n.copied || 'Copied.');
		});
	});

	/* ---------------------------------------------------------------
	 * List page: Refresh single link
	 * ------------------------------------------------------------- */

	$(document).on('click', '.payu-refresh-link-list', function (e) {
		e.preventDefault();
		var $tr = $(this).closest('tr');
		var linkId = $tr.data('link-id');
		var $link = $(this);

		$link.text('Refreshing...');
		$.post(cfg.ajaxUrl, {
			action: 'payu_payment_links_refresh',
			nonce: cfg.nonce,
			link_id: linkId
		}).done(function (res) {
			if (res.success && res.data) {
				if (res.data.status) {
					$tr.find('.payu-status-cell .payu-badge').text(res.data.status)
						.attr('class', 'payu-badge payu-badge-' + res.data.status);
				}
				if (res.data.payment_status) {
					$tr.find('.payu-payment-status-cell .payu-badge').text(res.data.payment_status)
						.attr('class', 'payu-badge payu-badge-' + res.data.payment_status);
				}
			} else {
				alert((res.data && res.data.message) || 'Error');
			}
			$link.text('Refresh');
		}).fail(function () {
			alert('Request failed.');
			$link.text('Refresh');
		});
	});

	/* ---------------------------------------------------------------
	 * List page: Resend (share) link
	 * ------------------------------------------------------------- */

	$(document).on('click', '.payu-resend-link-list', function (e) {
		e.preventDefault();
		var $tr = $(this).closest('tr');
		var invoice = $tr.data('invoice');
		var currency = $tr.data('currency');
		var recipients = prompt(cfg.i18n.enterRecipients || 'Enter email(s) or phone(s), comma-separated:');

		if (!recipients) return;

		var $link = $(this);
		$link.text('Sending...');
		$.post(cfg.ajaxUrl, {
			action: 'payu_payment_links_share',
			nonce: cfg.nonce,
			invoice_number: invoice,
			currency: currency,
			recipients: recipients
		}).done(function (res) {
			alert((res.data && res.data.message) || (res.success ? 'Shared.' : 'Could not send.'));
			$link.text('Resend');
		}).fail(function () {
			alert('Request failed.');
			$link.text('Resend');
		});
	});

	/* ---------------------------------------------------------------
	 * List page: Sync statuses from PayU
	 * ------------------------------------------------------------- */

	$(document).on('click', '.payu-sync-statuses', function () {
		var $btn = $(this);
		var from = $btn.data('from');
		var to = $btn.data('to');

		$btn.prop('disabled', true).text(cfg.i18n.syncing || 'Syncing...');
		$.post(cfg.ajaxUrl, {
			action: 'payu_payment_links_sync',
			nonce: cfg.nonce,
			from: from,
			to: to
		}).done(function (res) {
			if (res.success) {
				alert((res.data && res.data.message) || 'Sync complete.');
				if (res.data && res.data.updated > 0) {
					location.reload();
				}
			} else {
				alert((res.data && res.data.message) || 'Sync failed.');
			}
		}).fail(function () {
			alert('Sync request failed.');
		}).always(function () {
			$btn.prop('disabled', false).text('Sync statuses from PayU');
		});
	});

})(jQuery);
