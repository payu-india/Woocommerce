<?php
/**
 * Order integration: PayU Payment Link meta box, Order Actions, and AJAX handlers.
 *
 * @package PayU_Payment_Links_WooCommerce
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class PayU_Admin_Order
 */
class PayU_Admin_Order {

	public function __construct() {
		add_action( 'add_meta_boxes', array( $this, 'add_meta_box' ) );
		add_filter( 'woocommerce_order_actions', array( $this, 'add_order_actions' ), 10, 2 );
		add_action( 'woocommerce_order_action_payu_generate_link', array( $this, 'process_order_action_generate' ) );
		add_action( 'wp_ajax_payu_payment_links_generate', array( $this, 'ajax_generate_link' ) );
		add_action( 'wp_ajax_payu_payment_links_share', array( $this, 'ajax_share_link' ) );
		add_action( 'wp_ajax_payu_payment_links_refresh', array( $this, 'ajax_refresh_link' ) );
		add_action( 'wp_ajax_payu_payment_links_expire', array( $this, 'ajax_expire_link' ) );
		add_action( 'wp_ajax_payu_payment_links_refund', array( $this, 'ajax_refund_link' ) );
		add_action( 'wp_ajax_payu_payment_links_check_refund', array( $this, 'ajax_check_refund_status' ) );
		add_action( 'wp_ajax_payu_get_order_customer', array( $this, 'ajax_get_order_customer' ) );
		add_filter( 'bulk_actions-edit-shop_order', array( $this, 'bulk_actions' ), 20 );
		add_filter( 'handle_bulk_actions-edit-shop_order', array( $this, 'handle_bulk_actions' ), 10, 3 );
		add_action( 'admin_notices', array( $this, 'bulk_action_notices' ) );
	}

	private function has_credentials() {
		return get_option( 'payu_payment_links_merchant_id', '' )
			&& get_option( 'payu_payment_links_client_id', '' )
			&& get_option( 'payu_payment_links_client_secret', '' );
	}

	private function has_key_salt() {
		return ! PayU_Config::is_no_key_salt_mode();
	}

	/**
	 * Real-time poll: for any pending links, check PayU for transaction status.
	 *
	 * @param array $links DB rows.
	 */
	private function maybe_poll_pending_links( $links ) {
		$client = null;
		foreach ( $links as $link ) {
			$current_payment_status = isset( $link->payment_status ) ? $link->payment_status : 'pending';
			if ( ! in_array( $current_payment_status, array( 'pending', 'failed', 'partially_paid' ), true ) ) {
				continue;
			}
			if ( empty( $link->invoice_number ) ) {
				continue;
			}
			if ( null === $client ) {
				$client = new PayU_API_Client();
			}
			try {
				PayU_Payment_Links::poll_transaction_status( $client, $link );
			} catch ( Exception $e ) {
				PayU_Error_Handler::log_exception( 'admin_pending_link_poll_error', $e, array(
					'link_id'        => isset( $link->id ) ? (int) $link->id : 0,
					'invoice_number' => isset( $link->invoice_number ) ? (string) $link->invoice_number : '',
				) );
				continue;
			}
		}
	}

	/**
	 * Ensure WooCommerce order status reflects link payment outcomes.
	 *
	 * @param WC_Order $order Order object.
	 * @param array    $links Link rows.
	 */
	private function reconcile_order_from_links( $order, $links ) {
		if ( ! $order || ! is_a( $order, 'WC_Order' ) || empty( $links ) ) {
			return;
		}

		$current_status = $order->get_status();
		// Never auto-promote paid status for refund lifecycle statuses.
		if ( in_array( $current_status, array( 'refunded', 'partial-refund', 'on-hold' ), true ) ) {
			return;
		}

		$has_paid_link    = false;
		$has_partial_link = false;
		foreach ( $links as $link ) {
			$payment_status = isset( $link->payment_status ) ? (string) $link->payment_status : '';
			if ( 'paid' === $payment_status ) {
				$has_paid_link = true;
				break;
			}
			if ( 'partially_paid' === $payment_status ) {
				$has_partial_link = true;
			}
		}

		if ( $has_paid_link && ! $order->is_paid() ) {
			$target = PayU_Config::order_status_on_payment();
			if ( 'completed' === $target ) {
				$order->update_status( 'completed', __( 'PayU payment confirmed (reconciled from payment link status).', 'payu-payment-links-woocommerce' ) );
			} else {
				$order->payment_complete();
				$order->add_order_note( __( 'PayU payment confirmed (reconciled from payment link status).', 'payu-payment-links-woocommerce' ) );
			}
			return;
		}

		if ( $has_partial_link && 'partially-paid' !== $current_status ) {
			$order->update_status( 'partially-paid', __( 'PayU partial payment confirmed (reconciled from payment link status).', 'payu-payment-links-woocommerce' ) );
		}
	}

	/**
	 * Resolve WC_Order from meta box callback (works with legacy + HPOS).
	 */
	private function resolve_order( $post_or_order ) {
		if ( $post_or_order instanceof WC_Order ) {
			return $post_or_order;
		}
		if ( $post_or_order instanceof WP_Post ) {
			return wc_get_order( $post_or_order->ID );
		}
		$order_id = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
		return $order_id ? wc_get_order( $order_id ) : null;
	}

	/**
	 * Check if order is in a terminal state (no new links allowed).
	 *
	 * Blocks on:
	 *  - Paid, completed, processing, refunded, partial-refund, cancelled.
	 *  - Unpaid orders that already have WooCommerce refund records (pre-payment
	 *    refund edge case): generating a link here could lead to unrecoverable deductions.
	 */
	private function is_order_locked( $order ) {
		$status = $order->get_status();
		if ( $order->is_paid()
			|| in_array( $status, array( 'completed', 'processing', 'refunded', 'partial-refund', 'cancelled' ), true ) ) {
			return true;
		}
		// Block if WooCommerce refund records exist on an otherwise unpaid order.
		if ( ! $order->is_paid() && method_exists( $order, 'get_total_refunded' ) && (float) $order->get_total_refunded() > 0 ) {
			return true;
		}
		return false;
	}

	/**
	 * Check if order has an active payment link.
	 */
	private function get_active_link( $links ) {
		foreach ( $links as $link ) {
			if ( 'active' === $link->status ) {
				return $link;
			}
		}
		return null;
	}

	/* ---------------------------------------------------------------
	 * Order Actions dropdown
	 * ------------------------------------------------------------- */

	public function add_order_actions( $actions, $order = null ) {
		if ( ! $order ) {
			return $actions;
		}
		if ( $this->is_order_locked( $order ) ) {
			return $actions;
		}
		$links = PayU_DB::get_by_order( $order->get_id() );
		$active = $this->get_active_link( $links );
		if ( $active ) {
			return $actions;
		}
		if ( $this->has_credentials() ) {
			$actions['payu_generate_link'] = __( 'Generate PayU payment link', 'payu-payment-links-woocommerce' );
		}
		return $actions;
	}

	public function process_order_action_generate( $order ) {
		if ( ! $order || ! is_a( $order, 'WC_Order' ) ) {
			return;
		}
		if ( $this->is_order_locked( $order ) ) {
			$order->add_order_note( __( 'PayU: Cannot generate link — order is already paid or refunded.', 'payu-payment-links-woocommerce' ) );
			return;
		}
		$links  = PayU_DB::get_by_order( $order->get_id() );
		$active = $this->get_active_link( $links );
		if ( $active ) {
			$order->add_order_note( __( 'PayU: Cannot generate link — an active link already exists.', 'payu-payment-links-woocommerce' ) );
			return;
		}
		if ( (float) $order->get_total() <= 0 ) {
			$order->add_order_note( __( 'PayU: Cannot generate link — order total is zero.', 'payu-payment-links-woocommerce' ) );
			return;
		}
		try {
			$client = new PayU_API_Client();
			$creds  = $client->get_credentials_for_currency( null );
			$this->create_link_for_order( $client, $order, $creds['currency'] );
		} catch ( Exception $e ) {
			PayU_Error_Handler::log_exception( 'order_action_generate_error', $e, array( 'order_id' => (int) $order->get_id() ) );
			$order->add_order_note( sprintf( __( 'PayU link generation failed: %s', 'payu-payment-links-woocommerce' ), $e->getMessage() ) );
		}
	}

	/* ---------------------------------------------------------------
	 * Bulk actions
	 * ------------------------------------------------------------- */

	public function bulk_action_notices() {
		if ( isset( $_REQUEST['payu_links_error'] ) ) {
			echo '<div class="notice notice-error is-dismissible"><p>' . esc_html( urldecode( sanitize_text_field( wp_unslash( $_REQUEST['payu_links_error'] ) ) ) ) . '</p></div>';
			return;
		}
		if ( ! isset( $_REQUEST['payu_links_done'] ) && ! isset( $_REQUEST['payu_links_errors'] ) ) {
			return;
		}
		$done   = isset( $_REQUEST['payu_links_done'] ) ? absint( $_REQUEST['payu_links_done'] ) : 0;
		$errors = isset( $_REQUEST['payu_links_errors'] ) ? absint( $_REQUEST['payu_links_errors'] ) : 0;
		echo '<div class="notice notice-success is-dismissible"><p>';
		echo esc_html( sprintf( __( 'PayU payment links: %d generated.', 'payu-payment-links-woocommerce' ), $done ) );
		if ( $errors > 0 ) {
			echo ' ' . esc_html( sprintf( __( '%d order(s) skipped.', 'payu-payment-links-woocommerce' ), $errors ) );
		}
		echo '</p></div>';
	}

	public function bulk_actions( $actions ) {
		$actions['payu_generate_links'] = __( 'Generate PayU payment link', 'payu-payment-links-woocommerce' );
		return $actions;
	}

	public function handle_bulk_actions( $redirect_to, $action, $order_ids ) {
		if ( 'payu_generate_links' !== $action || empty( $order_ids ) ) {
			return $redirect_to;
		}
		$client = new PayU_API_Client();
		$done   = 0;
		$errors = 0;
		try {
			$creds         = $client->get_credentials_for_currency( null );
			$bulk_currency = $creds['currency'];
		} catch ( Exception $e ) {
			PayU_Error_Handler::log_exception( 'bulk_generate_creds_error', $e );
			return add_query_arg( array( 'payu_links_error' => urlencode( $e->getMessage() ) ), $redirect_to );
		}
		foreach ( $order_ids as $order_id ) {
			$order = wc_get_order( $order_id );
			if ( ! $order || $this->is_order_locked( $order ) || (float) $order->get_total() <= 0 ) {
				$errors++;
				continue;
			}
			$links = PayU_DB::get_by_order( $order_id );
			if ( $this->get_active_link( $links ) ) {
				$errors++;
				continue;
			}
			try {
				$this->create_link_for_order( $client, $order, $bulk_currency );
				$done++;
			} catch ( Exception $e ) {
				PayU_Error_Handler::log_exception( 'bulk_generate_link_error', $e, array( 'order_id' => (int) $order_id ) );
				$errors++;
			}
		}
		return add_query_arg( array( 'payu_links_done' => $done, 'payu_links_errors' => $errors ), $redirect_to );
	}

	/* ---------------------------------------------------------------
	 * Meta box
	 * ------------------------------------------------------------- */

	public function add_meta_box() {
		// Reset cached meta box position to ensure sidebar placement.
		$user_id = get_current_user_id();
		if ( $user_id ) {
			$hpos_order = get_user_meta( $user_id, 'meta-box-order_woocommerce_page_wc-orders', true );
			if ( is_array( $hpos_order ) && isset( $hpos_order['normal'] ) && strpos( $hpos_order['normal'], 'payu_payment_link' ) !== false ) {
				$hpos_order['normal'] = str_replace( array( 'payu_payment_link,', ',payu_payment_link', 'payu_payment_link' ), '', $hpos_order['normal'] );
				if ( ! isset( $hpos_order['side'] ) ) {
					$hpos_order['side'] = '';
				}
				if ( strpos( $hpos_order['side'], 'payu_payment_link' ) === false ) {
					$hpos_order['side'] = 'payu_payment_link,' . $hpos_order['side'];
				}
				update_user_meta( $user_id, 'meta-box-order_woocommerce_page_wc-orders', $hpos_order );
			}
		}

		add_meta_box( 'payu_payment_link', __( 'PayU Payment Link', 'payu-payment-links-woocommerce' ), array( $this, 'render_meta_box' ), 'shop_order', 'side', 'default' );

		if ( function_exists( 'wc_get_container' ) && class_exists( 'Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController' ) ) {
			try {
			$controller = wc_get_container()->get( \Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController::class );
			if ( $controller && $controller->custom_orders_table_usage_is_enabled() ) {
					add_meta_box( 'payu_payment_link', __( 'PayU Payment Link', 'payu-payment-links-woocommerce' ), array( $this, 'render_meta_box' ), 'woocommerce_page_wc-orders', 'side', 'default' );
				}
			} catch ( Exception $e ) {
				PayU_Error_Handler::log_exception( 'hpos_meta_box_bootstrap_error', $e );
				add_meta_box( 'payu_payment_link', __( 'PayU Payment Link', 'payu-payment-links-woocommerce' ), array( $this, 'render_meta_box' ), 'woocommerce_page_wc-orders', 'side', 'default' );
			}
		}
	}

	public function render_meta_box( $post_or_order ) {
		$order = $this->resolve_order( $post_or_order );
		if ( ! $order || ! is_a( $order, 'WC_Order' ) ) {
			echo '<p>' . esc_html__( 'Order not found.', 'payu-payment-links-woocommerce' ) . '</p>';
			return;
		}

		$order_id   = $order->get_id();
		$all_links  = PayU_DB::get_by_order( $order_id );

		$has_creds  = $this->has_credentials();
		$order_status = $order->get_status();
		$is_locked  = $this->is_order_locked( $order );
		$active_link = $this->get_active_link( $all_links );
		$default_expiry_days = (int) get_option( 'payu_payment_links_expiry_days', 7 );
		$default_expiry_date = gmdate( 'Y-m-d', strtotime( '+' . $default_expiry_days . ' days' ) );

		$can_generate = ! $is_locked && ! $active_link && $has_creds;

		wp_nonce_field( 'payu_payment_links_order_' . $order_id, 'payu_payment_links_nonce' );
		?>
		<div class="payu-payment-link-box" data-order-id="<?php echo absint( $order_id ); ?>">

			<?php if ( ! $has_creds ) : ?>
				<p class="payu-notice payu-error"><?php esc_html_e( 'PayU credentials not configured. Go to WooCommerce → Settings → PayU Payment Links.', 'payu-payment-links-woocommerce' ); ?></p>
			<?php endif; ?>

			<?php // --- Show the ACTIVE link (if any) --- ?>
			<?php if ( $active_link ) : ?>
				<?php $this->render_link_card( $active_link, true, $is_locked ); ?>
			<?php endif; ?>

			<?php // --- Show recent expired/non-active links (collapsed) --- ?>
			<?php
			$past_links = array_filter( $all_links, function( $l ) {
				return 'active' !== $l->status;
			} );
			?>
			<?php if ( ! empty( $past_links ) && ! $active_link ) : ?>
				<?php // No active link — show the most recent expired link ?>
				<?php $latest = reset( $past_links ); ?>
				<?php $this->render_link_card( $latest, false, $is_locked ); ?>
			<?php endif; ?>

			<?php if ( count( $past_links ) > ( $active_link ? 0 : 1 ) ) : ?>
				<details class="payu-past-links" style="margin:8px 0;">
					<summary style="cursor:pointer; font-size:12px; color:#646970;">
						<?php echo esc_html( sprintf( __( 'Show %d previous link(s)', 'payu-payment-links-woocommerce' ), $active_link ? count( $past_links ) : count( $past_links ) - 1 ) ); ?>
					</summary>
					<?php
					$skip_first = ! $active_link;
					foreach ( $past_links as $pl ) :
						if ( $skip_first ) { $skip_first = false; continue; }
						$this->render_link_card( $pl, false, true );
					endforeach;
					?>
				</details>
				<?php endif; ?>

			<?php // --- Status messages --- ?>
			<?php if ( $is_locked && in_array( $order_status, array( 'refunded', 'partial-refund' ), true ) ) : ?>
				<p class="payu-notice"><?php esc_html_e( 'Order is refunded. New link creation is disabled.', 'payu-payment-links-woocommerce' ); ?></p>
			<?php elseif ( $is_locked ) : ?>
				<p class="payu-notice"><?php esc_html_e( 'Order is already paid. New link creation is disabled.', 'payu-payment-links-woocommerce' ); ?></p>
			<?php elseif ( $active_link ) : ?>
				<p class="payu-notice"><?php esc_html_e( 'An active link exists. Expire it before creating a new one.', 'payu-payment-links-woocommerce' ); ?></p>
				<?php endif; ?>

			<?php // --- Generate form (only when allowed) --- ?>
			<?php if ( ! $is_locked && $has_creds ) : ?>
			<div class="payu-generate-section" <?php echo $can_generate ? '' : 'style="display:none;"'; ?>>
				<p class="payu-expiry-row">
					<label for="payu-link-expiry"><?php esc_html_e( 'Expiry date', 'payu-payment-links-woocommerce' ); ?></label>
					<input type="date" id="payu-link-expiry" class="payu-link-expiry" value="<?php echo esc_attr( $default_expiry_date ); ?>" min="<?php echo esc_attr( gmdate( 'Y-m-d' ) ); ?>" />
				</p>
				<p class="payu-partial-row">
					<label><input type="checkbox" class="payu-partial-payment-override" <?php checked( PayU_Config::is_partial_payment_enabled() ); ?> /> <?php esc_html_e( 'Allow partial payment', 'payu-payment-links-woocommerce' ); ?></label>
				</p>
				<p class="payu-actions">
					<button type="button" class="button button-primary payu-generate-link"><?php esc_html_e( 'Generate new link', 'payu-payment-links-woocommerce' ); ?></button>
				</p>
			</div>
			<?php endif; ?>

			<div class="payu-message" style="display:none;"></div>
		</div>
		<?php
	}

	/**
	 * Render a single payment link card inside the meta box.
	 *
	 * @param object $link      DB row.
	 * @param bool   $is_active Whether this is the active link.
	 * @param bool   $readonly  Whether actions should be hidden (locked order).
	 */
	private function render_link_card( $link, $is_active, $readonly = false ) {
		$payment_status = isset( $link->payment_status ) ? $link->payment_status : 'pending';
		$refund_amount  = isset( $link->refund_amount ) ? (float) $link->refund_amount : 0;
		$can_refund_api = $this->has_key_salt();
		$is_refundable  = $can_refund_api
						&& in_array( $payment_status, array( 'paid', 'partially_paid' ), true )
						&& ! empty( $link->payu_txn_id )
						&& $refund_amount < (float) $link->amount;
		$show_manual_refund_note = ! $can_refund_api && in_array( $payment_status, array( 'paid', 'partially_paid' ), true );
		$full_amount_display = number_format_i18n( (float) $link->amount, 2 );
		?>
		<div class="payu-link-item <?php echo $is_active ? 'payu-link-active' : 'payu-link-expired'; ?>"
			 data-link-id="<?php echo absint( $link->id ); ?>"
			 data-invoice="<?php echo esc_attr( $link->invoice_number ); ?>"
			 data-currency="<?php echo esc_attr( $link->currency ); ?>"
			 data-amount="<?php echo esc_attr( (int) $link->amount ); ?>"
			 data-txn-id="<?php echo esc_attr( $link->payu_txn_id ?: '' ); ?>">

			<p class="payu-link-row">
				<input type="text" class="payu-link-url widefat" value="<?php echo esc_url( $link->payment_link_url ); ?>" readonly />
			</p>
			<p>
				<strong><?php esc_html_e( 'Invoice:', 'payu-payment-links-woocommerce' ); ?></strong> <?php echo esc_html( $link->invoice_number ); ?>
				&nbsp;|&nbsp;
				<strong><?php echo esc_html( $link->currency ); ?></strong> <?php echo esc_html( $full_amount_display ); ?>
			</p>
		<p>
			<strong><?php esc_html_e( 'Link:', 'payu-payment-links-woocommerce' ); ?></strong>
			<span class="payu-badge payu-badge-<?php echo esc_attr( $link->status ); ?>"><?php echo esc_html( $link->status ); ?></span>
			&nbsp;
			<strong><?php esc_html_e( 'Payment:', 'payu-payment-links-woocommerce' ); ?></strong>
			<span class="payu-badge payu-badge-<?php echo esc_attr( $payment_status ); ?>"><?php echo esc_html( $payment_status ); ?></span>
		</p>

		<?php
		// Show paid vs pending breakdown for partial payments.
		$paid_amount_val = isset( $link->paid_amount ) ? (float) $link->paid_amount : 0.0;
		$link_total      = (float) $link->amount;
		if ( 'partially_paid' === $payment_status && $paid_amount_val > 0 ) :
			$pending_amount = max( 0.0, round( $link_total - $paid_amount_val, 2 ) );
			?>
			<p class="payu-partial-amounts">
				<strong><?php esc_html_e( 'Paid:', 'payu-payment-links-woocommerce' ); ?></strong>
				<?php echo esc_html( $link->currency . ' ' . number_format_i18n( $paid_amount_val, 2 ) ); ?>
				&nbsp;|&nbsp;
				<strong><?php esc_html_e( 'Pending:', 'payu-payment-links-woocommerce' ); ?></strong>
				<?php echo esc_html( $link->currency . ' ' . number_format_i18n( $pending_amount, 2 ) ); ?>
			</p>
		<?php endif; ?>

			<?php if ( $refund_amount > 0 ) : ?>
				<?php $r_status = isset( $link->refund_status ) ? $link->refund_status : ''; ?>
				<p class="payu-refund-info">
					<strong><?php esc_html_e( 'Refund:', 'payu-payment-links-woocommerce' ); ?></strong>
					<?php echo esc_html( $link->currency . ' ' . number_format_i18n( (float) $refund_amount, 2 ) ); ?>
					&nbsp;<span class="payu-badge payu-badge-<?php echo esc_attr( $r_status ?: 'pending' ); ?>"><?php echo esc_html( $r_status ?: 'queued' ); ?></span>
					<?php if ( ! empty( $link->refund_request_id ) ) : ?>
						<br /><small><?php esc_html_e( 'Ref:', 'payu-payment-links-woocommerce' ); ?> <?php echo esc_html( $link->refund_request_id ); ?></small>
					<?php endif; ?>
				</p>
			<?php endif; ?>

			<?php if ( $link->utr_number ) : ?>
				<p><strong><?php esc_html_e( 'UTR:', 'payu-payment-links-woocommerce' ); ?></strong> <?php echo esc_html( $link->utr_number ); ?></p>
			<?php endif; ?>

			<?php if ( ! empty( $link->last_shared_to ) ) : ?>
				<p class="payu-shared-info">
					<strong><?php esc_html_e( 'Shared to:', 'payu-payment-links-woocommerce' ); ?></strong> <?php echo esc_html( $link->last_shared_to ); ?>
					<?php if ( ! empty( $link->last_shared_at ) ) : ?>
						<br /><small><?php echo esc_html( date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $link->last_shared_at ) ) ); ?></small>
					<?php endif; ?>
				</p>
			<?php endif; ?>

			<?php if ( ! $readonly ) : ?>
				<p class="payu-link-actions">
					<button type="button" class="button button-small payu-copy-link"><?php esc_html_e( 'Copy', 'payu-payment-links-woocommerce' ); ?></button>
					<?php if ( $is_active ) : ?>
						<button type="button" class="button button-small payu-share-link"><?php esc_html_e( 'Share', 'payu-payment-links-woocommerce' ); ?></button>
						<button type="button" class="button button-small payu-expire-link" style="color:#d63638;"><?php esc_html_e( 'Expire', 'payu-payment-links-woocommerce' ); ?></button>
					<?php endif; ?>
					<?php if ( $is_refundable ) : ?>
						<button type="button" class="button button-small payu-refund-link" style="color:#d63638;"><?php esc_html_e( 'Refund', 'payu-payment-links-woocommerce' ); ?></button>
					<?php endif; ?>
					<?php
					$has_pending_refund = $can_refund_api && ! empty( $link->refund_request_id ) && isset( $link->refund_status ) && in_array( $link->refund_status, array( 'queued', 'in_progress', 'requested', 'pending', 'od_hit' ), true );
					if ( $has_pending_refund ) : ?>
						<button type="button" class="button button-small payu-check-refund"><?php esc_html_e( 'Check refund', 'payu-payment-links-woocommerce' ); ?></button>
					<?php endif; ?>
				</p>
				<?php if ( $is_active ) : ?>
				<?php
				// Build share prefill: always try both email and phone,
				// falling back to order billing data for each independently.
				$prefill_parts  = array();
				$fallback_order = ! empty( $link->order_id ) ? wc_get_order( (int) $link->order_id ) : null;
				$fb_order_valid = $fallback_order && is_a( $fallback_order, 'WC_Order' );

				$email = ! empty( $link->customer_email )
					? $link->customer_email
					: ( $fb_order_valid ? $fallback_order->get_billing_email() : '' );
				if ( $email ) {
					$prefill_parts[] = $email;
				}

				$phone = ! empty( $link->customer_phone )
					? $link->customer_phone
					: ( $fb_order_valid ? $fallback_order->get_billing_phone() : '' );
				if ( $phone ) {
					$prefill_parts[] = $phone;
				}

				$prefill = implode( ', ', $prefill_parts );
				?>
					<div class="payu-share-form" style="display:none; margin-top:6px;">
						<input type="text" class="payu-share-recipients widefat" placeholder="<?php esc_attr_e( 'Emails/phones, comma-separated', 'payu-payment-links-woocommerce' ); ?>" value="<?php echo esc_attr( $prefill ); ?>" />
						<button type="button" class="button button-small payu-share-send" style="margin-top:4px;"><?php esc_html_e( 'Send', 'payu-payment-links-woocommerce' ); ?></button>
					</div>
				<?php endif; ?>
				<?php if ( $is_refundable ) : ?>
					<?php $max_refundable = (float) $link->amount - $refund_amount; ?>
					<div class="payu-refund-form" style="display:none; margin-top:6px;">
						<label style="font-size:12px;"><?php esc_html_e( 'Refund amount:', 'payu-payment-links-woocommerce' ); ?></label>
						<input type="number" class="payu-refund-amount widefat" step="0.01" min="0.01" max="<?php echo esc_attr( $max_refundable ); ?>" value="<?php echo esc_attr( $max_refundable ); ?>" />
						<button type="button" class="button button-small payu-refund-submit" style="margin-top:4px; color:#d63638;"><?php esc_html_e( 'Confirm refund', 'payu-payment-links-woocommerce' ); ?></button>
					</div>
				<?php endif; ?>
				<?php if ( $show_manual_refund_note ) : ?>
					<p class="payu-notice" style="font-size:11px; margin-top:6px;">
						<?php
						printf(
							/* translators: %s: URL to PayU refunds dashboard docs */
							esc_html__( 'To refund, use the %s. After a successful refund, manually update the order status to Refunded or Partially Refunded.', 'payu-payment-links-woocommerce' ),
							'<a href="https://docs.payu.in/docs/refunds-dashboard" target="_blank" rel="noopener">' . esc_html__( 'PayU Dashboard', 'payu-payment-links-woocommerce' ) . '</a>'
						);
						?>
					</p>
				<?php endif; ?>
			<?php endif; ?>
		</div>
		<?php
	}

	/* ---------------------------------------------------------------
	 * AJAX: Generate link
	 * ------------------------------------------------------------- */

	public function ajax_generate_link() {
		check_ajax_referer( 'payu_payment_links_admin', 'nonce' );
		if ( ! current_user_can( 'edit_shop_orders' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'payu-payment-links-woocommerce' ) ) );
		}

		$order_id = isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
		$order    = $order_id ? wc_get_order( $order_id ) : null;
		if ( ! $order || ! is_a( $order, 'WC_Order' ) ) {
			wp_send_json_error( array( 'message' => __( 'Order not found.', 'payu-payment-links-woocommerce' ) ) );
		}

		if ( $this->is_order_locked( $order ) ) {
			wp_send_json_error( array( 'message' => __( 'Order is already paid or refunded. Cannot create a new link.', 'payu-payment-links-woocommerce' ) ) );
		}

		$links  = PayU_DB::get_by_order( $order_id );
		$active = $this->get_active_link( $links );
		if ( $active ) {
			wp_send_json_error( array( 'message' => __( 'An active payment link already exists. Expire it first.', 'payu-payment-links-woocommerce' ) ) );
		}

		$expiry_date   = isset( $_POST['expiry_date'] ) ? sanitize_text_field( wp_unslash( $_POST['expiry_date'] ) ) : '';
		$allow_partial = isset( $_POST['partial_payment'] ) && '1' === $_POST['partial_payment'];

		try {
			$client   = new PayU_API_Client();
			$creds    = $client->get_credentials_for_currency( null );
			$currency = isset( $creds['currency'] ) && $creds['currency'] ? $creds['currency'] : 'INR';
			$link_row = $this->create_link_for_order( $client, $order, $currency, $expiry_date, $allow_partial );
		} catch ( Exception $e ) {
			PayU_Error_Handler::log_exception( 'ajax_generate_link_error', $e, array( 'order_id' => (int) $order_id ) );
			wp_send_json_error( array( 'message' => $e->getMessage() ) );
		}

		wp_send_json_success( array(
			'payment_link'   => $link_row['payment_link_url'],
			'invoice_number' => $link_row['invoice_number'],
			'link_id'        => $link_row['id'],
		) );
	}

	/* ---------------------------------------------------------------
	 * Helper: normalize a share recipient (email or phone)
	 * ------------------------------------------------------------- */

	/**
	 * Normalize a recipient string for PayU's channelList.
	 *
	 * Emails are returned as-is. Phone numbers are cleaned of spaces/hyphens
	 * and, if 10 digits (Indian mobile), prefixed with +91.
	 *
	 * @param string $recipient Raw recipient value.
	 * @return string Normalized value, or empty string if invalid.
	 */
	private function normalize_share_recipient( $recipient ) {
		$recipient = trim( (string) $recipient );
		if ( is_email( $recipient ) ) {
			return $recipient;
		}
		// Strip common non-numeric characters (spaces, hyphens, dots, parentheses).
		$digits = preg_replace( '/[^\d+]/', '', $recipient );
		if ( '' === $digits ) {
			return '';
		}
		// Already has country code prefix (check on original trimmed string, not $digits).
		if ( strlen( $recipient ) > 0 && '+' === $recipient[0] ) {
			// Preserve +, rebuild from digits only (strip non-digit after the +).
			$clean = preg_replace( '/[^\d]/', '', $digits );
			return '+' . $clean;
		}
		// 10-digit Indian mobile: prepend +91.
		if ( preg_match( '/^[6-9]\d{9}$/', $digits ) ) {
			return '+91' . $digits;
		}
		// 12-digit with 91 prefix.
		if ( preg_match( '/^91[6-9]\d{9}$/', $digits ) ) {
			return '+' . $digits;
		}
		// Return cleaned digit string for other formats (international without +).
		return strlen( $digits ) >= 7 ? $digits : '';
	}

	/* ---------------------------------------------------------------
	 * AJAX: Share link
	 * ------------------------------------------------------------- */

	public function ajax_share_link() {
		check_ajax_referer( 'payu_payment_links_admin', 'nonce' );
		if ( ! current_user_can( 'edit_shop_orders' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'payu-payment-links-woocommerce' ) ) );
		}

		$invoice_number = isset( $_POST['invoice_number'] ) ? sanitize_text_field( wp_unslash( $_POST['invoice_number'] ) ) : '';
		$currency       = isset( $_POST['currency'] ) ? sanitize_text_field( wp_unslash( $_POST['currency'] ) ) : '';
		$recipients_raw = isset( $_POST['recipients'] ) ? sanitize_text_field( wp_unslash( $_POST['recipients'] ) ) : '';

		if ( ! $invoice_number ) {
			wp_send_json_error( array( 'message' => __( 'Invoice number is required.', 'payu-payment-links-woocommerce' ) ) );
		}

		$recipients = array_filter( array_map( 'trim', explode( ',', $recipients_raw ) ) );
		if ( empty( $recipients ) ) {
			wp_send_json_error( array( 'message' => __( 'Enter at least one email or phone number.', 'payu-payment-links-woocommerce' ) ) );
		}

		$link = PayU_DB::get_by_invoice( $invoice_number );
		if ( ! $link ) {
			wp_send_json_error( array( 'message' => __( 'Payment link not found.', 'payu-payment-links-woocommerce' ) ) );
		}

		// Normalize recipients: strip spaces/hyphens from phone numbers, ensure
		// 10-digit Indian numbers are prefixed with +91 for PayU's channelList.
		$normalized_recipients = array_map( array( $this, 'normalize_share_recipient' ), $recipients );
		$normalized_recipients = array_values( array_filter( $normalized_recipients ) );

		if ( empty( $normalized_recipients ) ) {
			wp_send_json_error( array( 'message' => __( 'No valid email addresses or phone numbers found after normalization. Please check the values and try again.', 'payu-payment-links-woocommerce' ) ) );
		}

		$shared_via        = '';
		$payu_api_error    = '';

		// Try PayU Share API first.
		try {
			$client = new PayU_API_Client();
			$client->share_payment_link( $invoice_number, $normalized_recipients, $currency ?: null );
			$shared_via = 'PayU API';
		} catch ( Exception $e ) {
			$payu_api_error = $e->getMessage();
			PayU_Error_Handler::log_exception( 'ajax_share_link_error', $e, array( 'invoice_number' => (string) $invoice_number ) );
			// Fall back to wp_mail for email recipients only.
			$emails = array_filter( $normalized_recipients, 'is_email' );
			if ( ! empty( $emails ) ) {
				$subject = sprintf( __( 'Payment link for %s', 'payu-payment-links-woocommerce' ), $link->description ?: $invoice_number );
				$body    = sprintf(
					__( "Please use the link below to complete your payment:\n\n%s\n\nAmount: %s %s", 'payu-payment-links-woocommerce' ),
					$link->payment_link_url,
					number_format( (float) $link->amount, 2 ),
					$link->currency
				);
				$sent = wp_mail( $emails, $subject, $body );
				if ( $sent ) {
					$shared_via = 'email';
				}
			}
		}

		// Only record audit data when at least one delivery channel succeeded.
		if ( $shared_via ) {
			PayU_DB::update( $link->id, array(
				'last_shared_to' => implode( ', ', $recipients ),
				'last_shared_at' => current_time( 'mysql', true ),
			) );

			if ( $link->order_id ) {
				$order = wc_get_order( $link->order_id );
				if ( $order ) {
					$order->add_order_note(
						sprintf( __( 'PayU payment link shared to: %s (via %s)', 'payu-payment-links-woocommerce' ), implode( ', ', $recipients ), $shared_via )
					);
				}
			}

			wp_send_json_success( array(
				'message' => sprintf( __( 'Link shared to %s (via %s).', 'payu-payment-links-woocommerce' ), implode( ', ', $recipients ), $shared_via ),
			) );
		}

		// Both API and email failed — give a precise error so merchant knows the cause.
		$phones = array_filter( $recipients, function( $r ) { return ! is_email( $r ); } );
		if ( ! empty( $phones ) && empty( array_filter( $recipients, 'is_email' ) ) ) {
			// Phone-only recipients, PayU API failed.
			wp_send_json_error( array(
				'message' => sprintf(
					/* translators: 1: PayU error */
					__( 'PayU SMS delivery failed: %1$s. SMS cannot be sent as a fallback. Please copy the link and send it via WhatsApp/SMS manually.', 'payu-payment-links-woocommerce' ),
					$payu_api_error ?: __( 'Unknown PayU error.', 'payu-payment-links-woocommerce' )
				),
			) );
		}

		wp_send_json_error( array(
			'message' => sprintf(
				__( 'Automatic delivery failed. PayU error: %1$s. Email fallback also failed (check SMTP settings). Please copy the link and share manually to: %2$s', 'payu-payment-links-woocommerce' ),
				$payu_api_error ?: __( 'Unknown.', 'payu-payment-links-woocommerce' ),
				implode( ', ', $recipients )
			),
		) );
	}

	/* ---------------------------------------------------------------
	 * AJAX: Refresh link status from PayU
	 * ------------------------------------------------------------- */

	public function ajax_refresh_link() {
		check_ajax_referer( 'payu_payment_links_admin', 'nonce' );
		if ( ! current_user_can( 'edit_shop_orders' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'payu-payment-links-woocommerce' ) ) );
		}

		$link_id = isset( $_POST['link_id'] ) ? absint( $_POST['link_id'] ) : 0;
		$link    = $link_id ? PayU_DB::get_by_id( $link_id ) : null;
		if ( ! $link ) {
			$invoice = isset( $_POST['invoice_number'] ) ? sanitize_text_field( wp_unslash( $_POST['invoice_number'] ) ) : '';
			$link    = $invoice ? PayU_DB::get_by_invoice( $invoice ) : null;
		}
		if ( ! $link ) {
			wp_send_json_error( array( 'message' => __( 'Payment link not found.', 'payu-payment-links-woocommerce' ) ) );
		}

		try {
			$client = new PayU_API_Client();
			$payu   = $client->get_payment_link( $link->invoice_number, $link->currency );
		} catch ( Exception $e ) {
			PayU_Error_Handler::log_exception( 'ajax_refresh_link_error', $e, array(
				'link_id'        => (int) $link->id,
				'invoice_number' => (string) $link->invoice_number,
			) );
			wp_send_json_error( array( 'message' => $e->getMessage() ) );
		}

		$update = array();
		if ( isset( $payu['status'] ) ) {
			$link_status = strtolower( sanitize_text_field( $payu['status'] ) );
			if ( in_array( $link_status, array( 'active', 'expired' ), true ) ) {
				$update['status'] = $link_status;
			}
		}
		if ( isset( $payu['totalAmount'] ) ) {
			$update['amount'] = (int) $payu['totalAmount'];
		}
		if ( isset( $payu['expiryDate'] ) ) {
			$update['expiry_date'] = sanitize_text_field( $payu['expiryDate'] );
		}
		if ( isset( $payu['paymentLink'] ) ) {
			$update['payment_link_url'] = esc_url_raw( $payu['paymentLink'] );
		}
		// Resolve payment_status from PayU's authoritative amountStatus field.
		$resolved_payment_status = '';
		$collected_amount        = 0.0;
		$compare_total           = isset( $link->amount ) ? (float) $link->amount : 0.0;
		if ( ! empty( $link->order_id ) ) {
			$order_for_cmp = wc_get_order( (int) $link->order_id );
			if ( $order_for_cmp && is_a( $order_for_cmp, 'WC_Order' ) ) {
				$compare_total = (float) $order_for_cmp->get_total();
			}
		}
		if ( isset( $payu['amountStatus'] ) ) {
			$as = strtoupper( $payu['amountStatus'] );
			if ( 'FULLY_PAID' === $as ) {
				$resolved_payment_status = 'paid';
				$collected_amount        = $compare_total;
			} elseif ( 'PARTIALLY_PAID' === $as ) {
				$resolved_payment_status = 'partially_paid';
				if ( isset( $payu['totalAmountCollected'] ) && is_numeric( $payu['totalAmountCollected'] ) ) {
					$collected_amount = (float) $payu['totalAmountCollected'];
				} else {
					// Fallback: fetch transactions to get authoritative collected amount.
					try {
						$txns    = $client->get_payment_link_transactions( $link->invoice_number, $link->currency );
						$summary = PayU_Payment_Links::summarize_payment_transactions( $txns );
						if ( ! empty( $summary['collected_amount'] ) && (float) $summary['collected_amount'] > 0 ) {
							$collected_amount = (float) $summary['collected_amount'];
						}
					} catch ( Exception $e ) {
						PayU_Error_Handler::log_exception( 'ajax_refresh_txn_fallback_error', $e, array(
							'link_id'        => (int) $link->id,
							'invoice_number' => (string) $link->invoice_number,
						) );
					}
				}
			} elseif ( in_array( $as, array( 'NOT_PAID', 'UNPAID' ), true ) ) {
				$resolved_payment_status = 'pending';
			}
		} elseif ( isset( $payu['totalAmountCollected'] ) && (float) $payu['totalAmountCollected'] > 0 ) {
			$collected_amount        = (float) $payu['totalAmountCollected'];
			$outcome                 = PayU_Payment_Links::resolve_payment_outcome( $compare_total, $collected_amount, true );
			$resolved_payment_status = $outcome['payment_status'];
		}

		// Write non-payment fields directly (link lifecycle metadata).
		if ( ! empty( $update ) ) {
			PayU_DB::update( $link->id, $update );
		}

		// Use state machine for payment_status + order sync.
		if ( '' !== $resolved_payment_status ) {
			$update['payment_status'] = $resolved_payment_status;
			$extra_updates            = array();
			if ( $collected_amount > 0 ) {
				$extra_updates['paid_amount'] = round( $collected_amount, 2 );
			}
			PayU_Payment_Links::transition_payment_status(
				(int) $link->id,
				$resolved_payment_status,
				$extra_updates,
				sprintf( __( 'PayU payment status updated to %s (manual refresh).', 'payu-payment-links-woocommerce' ), $resolved_payment_status )
			);
		}

		wp_send_json_success( array(
			'message'        => __( 'Status refreshed.', 'payu-payment-links-woocommerce' ),
			'status'         => isset( $update['status'] ) ? $update['status'] : $link->status,
			'payment_status' => isset( $update['payment_status'] ) ? $update['payment_status'] : ( isset( $link->payment_status ) ? $link->payment_status : 'pending' ),
			'link_id'        => $link->id,
		) );
	}

	/* ---------------------------------------------------------------
	 * AJAX: Expire link (UI-only for now, marks as expired locally)
	 * ------------------------------------------------------------- */

	public function ajax_expire_link() {
		check_ajax_referer( 'payu_payment_links_admin', 'nonce' );
		if ( ! current_user_can( 'edit_shop_orders' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'payu-payment-links-woocommerce' ) ) );
		}

		$link_id = isset( $_POST['link_id'] ) ? absint( $_POST['link_id'] ) : 0;
		$link    = $link_id ? PayU_DB::get_by_id( $link_id ) : null;
		if ( ! $link ) {
			wp_send_json_error( array( 'message' => __( 'Payment link not found.', 'payu-payment-links-woocommerce' ) ) );
		}

		// Attempt to expire via PayU API. Returns JSON error if PayU rejects the request.
		try {
			$client = new PayU_API_Client();
			$client->expire_payment_link( $link->invoice_number, $link->currency );
		} catch ( Exception $e ) {
			PayU_Error_Handler::log_exception( 'ajax_expire_link_error', $e, array(
				'link_id'        => (int) $link->id,
				'invoice_number' => (string) $link->invoice_number,
			) );
			wp_send_json_error( array( 'message' => sprintf( __( 'PayU expire API failed: %s', 'payu-payment-links-woocommerce' ), $e->getMessage() ) ) );
		}

		PayU_DB::update( $link->id, array( 'status' => 'expired' ) );

		if ( $link->order_id ) {
			$order = wc_get_order( $link->order_id );
			if ( $order ) {
				$order->add_order_note( sprintf( __( 'PayU payment link expired on PayU: %s', 'payu-payment-links-woocommerce' ), $link->invoice_number ) );
			}
		}

		wp_send_json_success( array( 'message' => __( 'Payment link expired.', 'payu-payment-links-woocommerce' ) ) );
	}

	/* ---------------------------------------------------------------
	 * AJAX: Refund via PayU Refund Transaction API
	 * ------------------------------------------------------------- */

	public function ajax_refund_link() {
		check_ajax_referer( 'payu_payment_links_admin', 'nonce' );
		if ( ! current_user_can( 'edit_shop_orders' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'payu-payment-links-woocommerce' ) ) );
		}
		if ( ! $this->has_key_salt() ) {
			wp_send_json_error( array( 'message' => __( 'Refunds require Merchant Key & Salt. Configure them in settings or use the PayU Dashboard.', 'payu-payment-links-woocommerce' ) ) );
		}

		$link_id = isset( $_POST['link_id'] ) ? absint( $_POST['link_id'] ) : 0;
		$link    = $link_id ? PayU_DB::get_by_id( $link_id ) : null;
		if ( ! $link ) {
			wp_send_json_error( array( 'message' => __( 'Payment link not found.', 'payu-payment-links-woocommerce' ) ) );
		}

		if ( empty( $link->payu_txn_id ) ) {
			wp_send_json_error( array( 'message' => __( 'No PayU transaction ID. Cannot refund.', 'payu-payment-links-woocommerce' ) ) );
		}

		$refund_amount_input = isset( $_POST['refund_amount'] ) ? (float) sanitize_text_field( wp_unslash( $_POST['refund_amount'] ) ) : 0;
		if ( $refund_amount_input <= 0 ) {
			wp_send_json_error( array( 'message' => __( 'Enter a valid refund amount.', 'payu-payment-links-woocommerce' ) ) );
		}

		$original_amount  = (float) $link->amount;
		$already_refunded = isset( $link->refund_amount ) ? (float) $link->refund_amount : 0;
		$max_refundable   = $original_amount - $already_refunded;

		if ( $refund_amount_input > $max_refundable + 0.01 ) {
			wp_send_json_error( array( 'message' => sprintf( __( 'Refund amount exceeds maximum refundable: %s', 'payu-payment-links-woocommerce' ), number_format( $max_refundable, 2 ) ) ) );
		}

		try {
			$client = new PayU_API_Client();
			$result = $client->refund_transaction( $link->payu_txn_id, $refund_amount_input, $link->currency );
		} catch ( Exception $e ) {
			PayU_Error_Handler::log_exception( 'ajax_refund_link_error', $e, array(
				'link_id'        => (int) $link->id,
				'invoice_number' => (string) $link->invoice_number,
			) );
			wp_send_json_error( array( 'message' => $e->getMessage() ) );
		}

		$request_id = isset( $result['request_id'] ) ? trim( (string) $result['request_id'] ) : '';
		if ( '' === $request_id ) {
			PayU_DB::update( $link->id, array( 'refund_status' => 'failed' ) );
			wp_send_json_error( array( 'message' => __( 'PayU refund response missing request ID. Refund was not queued for tracking.', 'payu-payment-links-woocommerce' ) ) );
		}

		$new_refund_total = $already_refunded + $refund_amount_input;

		// Initial state: queued. Final state set by cron polling check_refund_status.
		$db_update = array(
			'refund_amount'     => $new_refund_total,
			'refund_request_id' => $request_id,
			'refund_status'     => 'queued',
		);
		PayU_DB::update( $link->id, $db_update );

		// Set order to Refund In Progress while refund is being processed.
		if ( $link->order_id ) {
			$order = wc_get_order( $link->order_id );
			if ( $order ) {
				$note = sprintf(
					__( 'PayU refund initiated: %s %s. Refund is queued. Request ID: %s', 'payu-payment-links-woocommerce' ),
					$link->currency,
					number_format( $refund_amount_input, 2 ),
					$request_id
				);
				$order->update_status( 'refund-in-progress', $note );
			}
		}

		wp_send_json_success( array(
			'message'       => sprintf( __( 'Refund of %s %s queued. Status will be updated automatically.', 'payu-payment-links-woocommerce' ), $link->currency, number_format( $refund_amount_input, 2 ) ),
			'refund_status' => 'queued',
		) );
	}

	/* ---------------------------------------------------------------
	 * AJAX: Check refund status from PayU
	 * ------------------------------------------------------------- */

	public function ajax_check_refund_status() {
		check_ajax_referer( 'payu_payment_links_admin', 'nonce' );
		if ( ! current_user_can( 'edit_shop_orders' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'payu-payment-links-woocommerce' ) ) );
		}
		if ( ! $this->has_key_salt() ) {
			wp_send_json_error( array( 'message' => __( 'Requires Merchant Key & Salt.', 'payu-payment-links-woocommerce' ) ) );
		}

		$link_id = isset( $_POST['link_id'] ) ? absint( $_POST['link_id'] ) : 0;
		$link    = $link_id ? PayU_DB::get_by_id( $link_id ) : null;
		if ( ! $link || empty( $link->refund_request_id ) ) {
			wp_send_json_error( array( 'message' => __( 'No refund to check.', 'payu-payment-links-woocommerce' ) ) );
		}

		try {
			$result = self::poll_refund_status( $link );
		} catch ( Exception $e ) {
			PayU_Error_Handler::log_exception( 'refund_status_poll_error', $e, array( 'link_id' => (int) $link->id ) );
			wp_send_json_error( array(
				'message' => sprintf( __( 'Refund status check failed: %s', 'payu-payment-links-woocommerce' ), $e->getMessage() ),
			) );
		}

		wp_send_json_success( array(
			'message'       => sprintf( __( 'Refund status: %s', 'payu-payment-links-woocommerce' ), $result ),
			'refund_status' => $result,
		) );
	}

	/**
	 * Poll PayU for refund status and update DB + order accordingly.
	 *
	 * @param object $link DB row.
	 * @return string The resolved refund status.
	 */
	public static function poll_refund_status( $link ) {
		$previous_status = isset( $link->refund_status ) ? strtolower( (string) $link->refund_status ) : '';
		try {
			$client        = new PayU_API_Client();
			$refund_status = $client->check_refund_status( $link->refund_request_id, $link->currency );
		} catch ( Exception $e ) {
			PayU_Error_Handler::log_exception( 'refund_status_poll_error', $e, array(
				'link_id'     => (int) $link->id,
				'request_id'  => isset( $link->refund_request_id ) ? (string) $link->refund_request_id : '',
				'invoice_number' => isset( $link->invoice_number ) ? (string) $link->invoice_number : '',
			) );
			return isset( $link->refund_status ) ? $link->refund_status : 'queued';
		}

		$db_update = array( 'refund_status' => $refund_status );

		$order_for_check = $link->order_id ? wc_get_order( (int) $link->order_id ) : null;
		$order_total     = ( $order_for_check && is_a( $order_for_check, 'WC_Order' ) )
			? (float) $order_for_check->get_total()
			: (float) $link->amount;
		$is_full_refund  = isset( $link->refund_amount ) && (float) $link->refund_amount + 0.01 >= $order_total;

		if ( 'success' === $refund_status ) {
			$db_update['payment_status'] = $is_full_refund ? 'refunded' : 'partially_refunded';
		} elseif ( 'failure' === $refund_status ) {
			$db_update['refund_status']  = 'failed';
		}

		PayU_DB::update( $link->id, $db_update );

		if ( $link->order_id ) {
			$order = wc_get_order( $link->order_id );
			if ( $order ) {
				if ( 'success' === $refund_status && $is_full_refund ) {
					$order->update_status( 'refunded', __( 'PayU refund successful.', 'payu-payment-links-woocommerce' ) );
				} elseif ( 'success' === $refund_status ) {
					$order->update_status( 'partial-refund', sprintf( __( 'PayU partial refund successful. Refunded: %s %s', 'payu-payment-links-woocommerce' ), $link->currency, number_format( (float) $link->refund_amount, 2 ) ) );
				} elseif ( 'failure' === $refund_status ) {
					$order->add_order_note( __( 'PayU refund failed. Order status left unchanged.', 'payu-payment-links-woocommerce' ) );
				} else {
					// Non-terminal: ensure order is in Refund In Progress.
					$cur = $order->get_status();
					if ( ! in_array( $cur, array( 'refund-in-progress', 'on-hold' ), true ) ) {
						$order->update_status( 'refund-in-progress', sprintf( __( 'PayU refund status: %s (Request ID: %s).', 'payu-payment-links-woocommerce' ), $refund_status, $link->refund_request_id ) );
					} elseif ( $refund_status !== $previous_status ) {
						$order->add_order_note(
							sprintf(
								/* translators: 1: refund status, 2: request ID */
								__( 'PayU refund status updated to %1$s (Request ID: %2$s).', 'payu-payment-links-woocommerce' ),
								$refund_status,
								$link->refund_request_id
							)
						);
					}
				}
			}
		}

		return $refund_status;
	}

	/**
	 * Poll refund states by PayU transaction ID (mihpayid) and aggregate outcomes.
	 *
	 * @param object   $link  DB link row.
	 * @param WC_Order $order Woo order.
	 * @return string Effective refund state.
	 */
	public static function poll_refund_status_by_payu_id( $link, $order ) {
		if ( ! $link || empty( $link->payu_txn_id ) || ! $order || ! is_a( $order, 'WC_Order' ) ) {
			return 'pending';
		}

		try {
			$client  = new PayU_API_Client();
			$actions = $client->check_action_status_by_payu_id( $link->payu_txn_id, $link->currency );
		} catch ( Exception $e ) {
			PayU_Error_Handler::log_exception( 'refund_status_poll_by_payu_id_error', $e, array(
				'link_id'        => (int) $link->id,
				'invoice_number' => isset( $link->invoice_number ) ? (string) $link->invoice_number : '',
			) );
			$order->add_order_note(
				sprintf( __( 'PayU refund poll (PayU ID) failed: %s', 'payu-payment-links-woocommerce' ), $e->getMessage() )
			);
			return isset( $link->refund_status ) ? $link->refund_status : 'pending';
		}

		if ( empty( $actions ) ) {
			return isset( $link->refund_status ) ? $link->refund_status : 'pending';
		}

		$previous_refund_status = isset( $link->refund_status ) ? strtolower( (string) $link->refund_status ) : '';
		$success_total          = 0.0;
		$has_failure            = false;
		$pending_priority       = array( 'od_hit' => 5, 'in_progress' => 4, 'requested' => 3, 'queued' => 2, 'pending' => 1 );
		$best_pending           = '';

		foreach ( $actions as $action ) {
			$status = isset( $action['status'] ) ? self::normalize_refund_state( $action['status'] ) : '';
			$amt    = isset( $action['amt'] ) ? (float) $action['amt'] : 0.0;

			if ( 'success' === $status ) {
				$success_total += $amt;
				continue;
			}
			if ( 'failure' === $status ) {
				$has_failure = true;
				continue;
			}

			if ( isset( $pending_priority[ $status ] ) ) {
				if ( '' === $best_pending || $pending_priority[ $status ] > $pending_priority[ $best_pending ] ) {
					$best_pending = $status;
				}
			}
		}

		$effective_state = $best_pending ? $best_pending : ( $has_failure ? 'failure' : 'pending' );
		$payment_status  = isset( $link->payment_status ) ? (string) $link->payment_status : 'paid';
		$order_status    = $order->get_status();
		$order_total     = (float) $order->get_total();

		// Only treat as success when NO pending actions remain.
		// If any refund action is still pending, keep order in refund-in-progress.
		if ( $success_total > 0 && '' === $best_pending ) {
			if ( $success_total + 0.01 >= $order_total ) {
				$effective_state = 'success';
				$payment_status  = 'refunded';
			} else {
				$effective_state = 'success';
				$payment_status  = 'partially_refunded';
			}
		} elseif ( '' !== $best_pending ) {
			// Some actions still pending — keep current payment_status, just update refund state.
			if ( in_array( $payment_status, array( 'refunded', 'partially_refunded' ), true ) ) {
				$payment_status = 'paid';
			}
		} elseif ( in_array( $payment_status, array( 'refunded', 'partially_refunded' ), true ) ) {
			$payment_status = 'paid';
		}

		$db_update = array(
			'refund_status'  => 'success' === $effective_state ? 'success' : ( 'failure' === $effective_state ? 'failed' : $effective_state ),
			'refund_amount'  => $success_total > 0 ? max( (float) ( isset( $link->refund_amount ) ? $link->refund_amount : 0 ), round( $success_total, 2 ) ) : (float) ( isset( $link->refund_amount ) ? $link->refund_amount : 0 ),
			'payment_status' => $payment_status,
		);
		PayU_DB::update( $link->id, $db_update );

		if ( 'success' === $effective_state ) {
			if ( 'refunded' === $payment_status && 'refunded' !== $order_status ) {
				$order->update_status( 'refunded', __( 'PayU refund successful (PayU ID poll).', 'payu-payment-links-woocommerce' ) );
			} elseif ( 'partially_refunded' === $payment_status && 'partial-refund' !== $order_status ) {
				$order->update_status( 'partial-refund', sprintf( __( 'PayU partial refund successful (PayU ID poll). Refunded: %s %s', 'payu-payment-links-woocommerce' ), $link->currency, number_format( $success_total, 2 ) ) );
			}
		} elseif ( in_array( $effective_state, array( 'queued', 'pending', 'requested', 'in_progress', 'od_hit' ), true ) ) {
			if ( ! in_array( $order_status, array( 'refund-in-progress', 'on-hold' ), true ) ) {
				$order->update_status( 'refund-in-progress', sprintf( __( 'PayU refund status is %s (PayU ID poll).', 'payu-payment-links-woocommerce' ), $effective_state ) );
			} elseif ( $previous_refund_status !== $effective_state ) {
				$order->add_order_note( sprintf( __( 'PayU refund status updated to %s (PayU ID poll).', 'payu-payment-links-woocommerce' ), $effective_state ) );
			}
		} elseif ( 'failure' === $effective_state && $previous_refund_status !== 'failure' ) {
			$order->add_order_note( __( 'PayU refund status is failed (PayU ID poll). Order remains unchanged.', 'payu-payment-links-woocommerce' ) );
		}

		return $effective_state;
	}

	/**
	 * Normalize PayU refund state labels.
	 *
	 * @param string $status Raw status.
	 * @return string
	 */
	private static function normalize_refund_state( $status ) {
		$status = strtolower( trim( (string) $status ) );
		$status = str_replace( array( '-', ' ' ), '_', $status );
		if ( 'inprogress' === $status ) {
			$status = 'in_progress';
		}
		return $status;
	}

	/* ---------------------------------------------------------------
	 * Internal: create link and persist
	 * ------------------------------------------------------------- */

	private function create_link_for_order( $client, $order, $currency, $expiry = '', $allow_partial = null ) {
		$order_id    = $order->get_id();
		$order_total = (float) $order->get_total();
		if ( $order_total <= 0 ) {
			throw new Exception( __( 'Order total is zero.', 'payu-payment-links-woocommerce' ) );
		}

		// Deduct amounts already collected via prior partial payment links so the
		// new link only charges the remaining balance, preventing overpayment.
		$paid_so_far = 0.0;
		$prior_links = PayU_DB::get_by_order( $order_id );
		foreach ( $prior_links as $prior ) {
			if ( in_array( $prior->payment_status, array( 'partially_paid', 'paid' ), true ) ) {
				$link_paid = isset( $prior->paid_amount ) ? (float) $prior->paid_amount : 0.0;
				// Fall back to link face-value when paid_amount is not yet recorded
				// (e.g. legacy rows set to paid before this column existed).
				if ( $link_paid <= 0 && 'paid' === $prior->payment_status ) {
					$link_paid = isset( $prior->amount ) ? (float) $prior->amount : 0.0;
				}
				$paid_so_far += $link_paid;
			}
		}
		$amount = $paid_so_far > 0 ? max( 0.01, round( $order_total - $paid_so_far, 2 ) ) : $order_total;
		if ( $paid_so_far >= $order_total ) {
			throw new Exception( __( 'Remaining balance is zero. The order has already been fully paid.', 'payu-payment-links-woocommerce' ) );
		}
		if ( $amount <= 0 ) {
			throw new Exception( __( 'Remaining balance is zero. The order has already been fully paid.', 'payu-payment-links-woocommerce' ) );
		}

		$prefix      = get_option( 'payu_payment_links_description_prefix', 'Order' );
		$invoice     = substr( 'WC' . $order_id . 'L' . wp_rand( 1000, 9999 ), 0, 16 );
		$expiry_days = (int) get_option( 'payu_payment_links_expiry_days', 7 );
		// Append balance indicator to description when generating a link for the remainder.
		$description = $paid_so_far > 0
			? $prefix . ' #' . $order_id . ' ' . __( '(balance)', 'payu-payment-links-woocommerce' )
			: $prefix . ' #' . $order_id;

		if ( $expiry && strtotime( $expiry ) ) {
			$expiry_date = gmdate( 'Y-m-d', strtotime( $expiry ) ) . 'T23:59:59Z';
		} else {
			$expiry_date = gmdate( 'Y-m-d\TH:i:s\Z', strtotime( '+' . $expiry_days . ' days' ) );
		}

		$link_args = array(
			'amount'         => $amount,
			'description'    => $description,
			'invoice_number' => $invoice,
			'expiry_date'    => $expiry_date,
			'currency'       => $currency,
			'order_id'       => $order_id,
			'success_url'    => $order->get_checkout_order_received_url(),
			'failure_url'    => $order->get_view_order_url(),
					'customer'       => array(
						'email' => $order->get_billing_email(),
				'name'  => trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ),
						'phone' => $order->get_billing_phone(),
					),
					'address'        => array(
						'address1' => $order->get_billing_address_1(),
						'address2' => $order->get_billing_address_2(),
						'city'     => $order->get_billing_city(),
						'state'    => $order->get_billing_state(),
						'zip'      => $order->get_billing_postcode(),
			),
		);

		if ( null !== $allow_partial ) {
			$link_args['is_partial_payment_allowed'] = (bool) $allow_partial;
		}

		$result = $client->create_payment_link( $link_args );

		$row_data = array(
			'order_id'         => $order_id,
			'invoice_number'   => $result['invoiceNumber'],
			'payment_link_url' => $result['paymentLink'],
			'amount'           => isset( $result['totalAmount'] ) ? (float) $result['totalAmount'] : $amount,
			'currency'         => $result['currency'],
			'status'           => 'active',
			'payment_status'   => 'pending',
			'description'      => $description,
			'expiry_date'      => $result['expiryDate'] ? gmdate( 'Y-m-d H:i:s', strtotime( $result['expiryDate'] ) ) : null,
			'created_at'       => current_time( 'mysql', true ),
			'udf1'             => (string) $order_id,
			'udf5'             => PayU_API_Client::UDF5_SOURCE,
			'customer_email'   => $order->get_billing_email(),
			'customer_phone'   => $order->get_billing_phone(),
			'customer_name'    => trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ),
		);

		$row_id = PayU_DB::insert( $row_data );
		if ( ! $row_id ) {
			throw new Exception( __( 'Failed to save payment link to database.', 'payu-payment-links-woocommerce' ) );
		}

		$order->add_order_note( sprintf( __( 'PayU payment link generated: %s', 'payu-payment-links-woocommerce' ), $result['paymentLink'] ) );
		$row_data['id'] = $row_id;
		return $row_data;
	}

	/* ---------------------------------------------------------------
	 * AJAX: Return billing email + phone for an order (manual link form autofill)
	 * ------------------------------------------------------------- */

	public function ajax_get_order_customer() {
		check_ajax_referer( 'payu_get_order_customer', 'nonce' );
		if ( ! current_user_can( 'edit_shop_orders' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'payu-payment-links-woocommerce' ) ) );
		}
		$order_id = isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
		$order    = $order_id ? wc_get_order( $order_id ) : null;
		if ( ! $order ) {
			wp_send_json_error( array( 'message' => __( 'Order not found.', 'payu-payment-links-woocommerce' ) ) );
		}
		wp_send_json_success( array(
			'email' => $order->get_billing_email(),
			'phone' => $order->get_billing_phone(),
		) );
	}
}
