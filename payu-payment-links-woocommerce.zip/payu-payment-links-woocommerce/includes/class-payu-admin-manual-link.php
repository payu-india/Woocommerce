<?php
/**
 * Manual PayU payment link creation (standalone or attached to an order).
 *
 * @package PayU_Payment_Links_WooCommerce
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class PayU_Admin_Manual_Link
 */
class PayU_Admin_Manual_Link {

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'add_menu' ), 20 );
		add_action( 'admin_init', array( $this, 'handle_form' ) );
	}

	public function add_menu() {
		add_submenu_page(
			'woocommerce',
			__( 'PayU Create Link', 'payu-payment-links-woocommerce' ),
			__( 'PayU Create Link', 'payu-payment-links-woocommerce' ),
			'manage_woocommerce',
			'payu-payment-links-create',
			array( $this, 'render_page' )
		);
	}

	/**
	 * Configured currency codes for dropdown.
	 *
	 * @return string[]
	 */
	

	/* ---------------------------------------------------------------
	 * Form handler
	 * ------------------------------------------------------------- */

	/**
	 * Block new links for paid/refunded orders.
	 *
	 * @param WC_Order $order Order object.
	 * @return bool
	 */
	private function is_order_locked( $order ) {
		if ( ! $order || ! is_a( $order, 'WC_Order' ) ) {
			return false;
		}
		$status = $order->get_status();
		if ( $order->is_paid()
			|| in_array( $status, array( 'completed', 'processing', 'refunded', 'partial-refund', 'cancelled' ), true ) ) {
			return true;
		}
		// Block if WooCommerce refund records exist on an unpaid order.
		if ( ! $order->is_paid() && method_exists( $order, 'get_total_refunded' ) && (float) $order->get_total_refunded() > 0 ) {
			return true;
		}
		return false;
	}

	/**
	 * Find active link for an order.
	 *
	 * @param int $order_id Order ID.
	 * @return object|null
	 */
	private function get_active_link_for_order( $order_id ) {
		$links = PayU_DB::get_by_order( $order_id );
		foreach ( $links as $link ) {
			if ( isset( $link->status ) && 'active' === $link->status ) {
				return $link;
			}
		}
		return null;
	}

	public function handle_form() {
		if ( ! isset( $_POST['payu_manual_link_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['payu_manual_link_nonce'] ) ), 'payu_manual_link' ) ) {
			return;
		}
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		$amount = isset( $_POST['payu_amount'] ) ? wc_format_decimal( sanitize_text_field( wp_unslash( $_POST['payu_amount'] ) ), 2 ) : '';
		if ( (float) $amount <= 0 ) {
			set_transient( 'payu_manual_link_error_' . get_current_user_id(), __( 'Please enter a valid amount greater than zero.', 'payu-payment-links-woocommerce' ), 60 );
			wp_safe_redirect( add_query_arg( array( 'payu_error' => '1', 'page' => 'payu-payment-links-create' ), admin_url( 'admin.php' ) ) );
			exit;
		}

		$desc             = isset( $_POST['payu_description'] ) ? sanitize_text_field( wp_unslash( $_POST['payu_description'] ) ) : '';
		$email            = isset( $_POST['payu_customer_email'] ) ? sanitize_email( wp_unslash( $_POST['payu_customer_email'] ) ) : '';
		$phone            = isset( $_POST['payu_customer_phone'] ) ? sanitize_text_field( wp_unslash( $_POST['payu_customer_phone'] ) ) : '';
		$attach_order_id  = isset( $_POST['payu_attach_order'] ) ? absint( $_POST['payu_attach_order'] ) : 0;
		$currency         = 'INR';
		$expiry_input     = isset( $_POST['payu_expiry_date'] ) ? sanitize_text_field( wp_unslash( $_POST['payu_expiry_date'] ) ) : '';

		$expiry_days = (int) get_option( 'payu_payment_links_expiry_days', 7 );
		if ( $expiry_input && strtotime( $expiry_input ) ) {
			$expiry_date = gmdate( 'Y-m-d', strtotime( $expiry_input ) ) . 'T23:59:59Z';
		} else {
			$expiry_date = gmdate( 'Y-m-d\TH:i:s\Z', strtotime( '+' . $expiry_days . ' days' ) );
		}

		$allow_partial = isset( $_POST['payu_partial_payment'] ) && '1' === $_POST['payu_partial_payment'];

		$args = array(
			'amount'                     => (float) $amount,
			'description'                => $desc ? $desc : __( 'Manual payment link', 'payu-payment-links-woocommerce' ),
			'expiry_date'                => $expiry_date,
			'success_url'                => wc_get_page_permalink( 'shop' ),
			'failure_url'                => wc_get_page_permalink( 'shop' ),
			'is_partial_payment_allowed' => $allow_partial,
		);

		if ( $email ) {
			$args['customer'] = array( 'name' => 'Customer', 'email' => $email, 'phone' => $phone );
		}
		if ( $currency ) {
			$args['currency'] = $currency;
		}
		if ( $attach_order_id ) {
			$order = wc_get_order( $attach_order_id );
			if ( ! $order || ! is_a( $order, 'WC_Order' ) ) {
				set_transient( 'payu_manual_link_error_' . get_current_user_id(), __( 'Attached order not found.', 'payu-payment-links-woocommerce' ), 60 );
				wp_safe_redirect( add_query_arg( array( 'payu_error' => '1', 'page' => 'payu-payment-links-create' ), admin_url( 'admin.php' ) ) );
				exit;
			}
			if ( $this->is_order_locked( $order ) ) {
				set_transient( 'payu_manual_link_error_' . get_current_user_id(), __( 'Cannot attach a new link: order is already paid or refunded.', 'payu-payment-links-woocommerce' ), 60 );
				wp_safe_redirect( add_query_arg( array( 'payu_error' => '1', 'page' => 'payu-payment-links-create' ), admin_url( 'admin.php' ) ) );
				exit;
			}
			if ( $this->get_active_link_for_order( $attach_order_id ) ) {
				set_transient( 'payu_manual_link_error_' . get_current_user_id(), __( 'Cannot attach a new link: an active link already exists for this order.', 'payu-payment-links-woocommerce' ), 60 );
				wp_safe_redirect( add_query_arg( array( 'payu_error' => '1', 'page' => 'payu-payment-links-create' ), admin_url( 'admin.php' ) ) );
				exit;
			}
		$args['invoice_number'] = substr( 'WC' . $attach_order_id . 'L' . wp_rand( 1000, 9999 ), 0, 16 );
		$args['order_id']       = $attach_order_id;

		// Apply remaining-balance deduction: subtract already-collected partial amounts.
		$order_total = (float) $order->get_total();
		$paid_so_far = 0.0;
		foreach ( PayU_DB::get_by_order( $attach_order_id ) as $prior ) {
			if ( in_array( $prior->payment_status, array( 'partially_paid', 'paid' ), true ) ) {
				$link_paid = isset( $prior->paid_amount ) ? (float) $prior->paid_amount : 0.0;
				if ( $link_paid <= 0 && 'paid' === $prior->payment_status ) {
					$link_paid = isset( $prior->amount ) ? (float) $prior->amount : 0.0;
				}
				$paid_so_far += $link_paid;
			}
		}
		if ( $paid_so_far > 0 && $order_total > 0 ) {
			$remaining = max( 0.01, round( $order_total - $paid_so_far, 2 ) );
			if ( $paid_so_far >= $order_total ) {
				set_transient( 'payu_manual_link_error_' . get_current_user_id(), __( 'Cannot create link: order balance is already fully collected.', 'payu-payment-links-woocommerce' ), 60 );
				wp_safe_redirect( add_query_arg( array( 'payu_error' => '1', 'page' => 'payu-payment-links-create' ), admin_url( 'admin.php' ) ) );
				exit;
			}
			// Cap entered amount to the remaining balance.
			if ( (float) $args['amount'] > $remaining ) {
				$args['amount'] = $remaining;
			}
		}
	}

		try {
			$client = new PayU_API_Client();
			$result = $client->create_payment_link( $args );

			$row_data = array(
				'order_id'         => $attach_order_id ?: null,
				'invoice_number'   => $result['invoiceNumber'],
				'payment_link_url' => $result['paymentLink'],
				'amount'           => isset( $result['totalAmount'] ) ? (float) $result['totalAmount'] : $args['amount'],
				'currency'         => $result['currency'],
				'status'           => 'active',
				'description'      => $args['description'],
				'expiry_date'      => $result['expiryDate'] ? gmdate( 'Y-m-d H:i:s', strtotime( $result['expiryDate'] ) ) : null,
				'created_at'       => current_time( 'mysql', true ),
				'udf1'             => $attach_order_id ? (string) $attach_order_id : null,
				'udf5'             => PayU_API_Client::UDF5_SOURCE,
				'customer_email'   => $email ?: null,
				'customer_phone'   => $phone ?: null,
			);

			$row_id = PayU_DB::insert( $row_data );
			if ( ! $row_id ) {
				throw new Exception( __( 'Failed to save payment link to database.', 'payu-payment-links-woocommerce' ) );
			}

			if ( $attach_order_id ) {
				$order = wc_get_order( $attach_order_id );
				if ( $order && is_a( $order, 'WC_Order' ) ) {
					$order->add_order_note( sprintf( __( 'PayU payment link (manual): %s', 'payu-payment-links-woocommerce' ), $result['paymentLink'] ) );
				}
			}

			set_transient( 'payu_manual_link_result_' . get_current_user_id(), $result, 60 );
			wp_safe_redirect( add_query_arg( array( 'payu_created' => '1', 'page' => 'payu-payment-links-create' ), admin_url( 'admin.php' ) ) );
			exit;

		} catch ( Exception $e ) {
			set_transient( 'payu_manual_link_error_' . get_current_user_id(), $e->getMessage(), 60 );
			wp_safe_redirect( add_query_arg( array( 'payu_error' => '1', 'page' => 'payu-payment-links-create' ), admin_url( 'admin.php' ) ) );
			exit;
		}
	}

	/* ---------------------------------------------------------------
	 * Render
	 * ------------------------------------------------------------- */

	public function render_page() {
		$result = get_transient( 'payu_manual_link_result_' . get_current_user_id() );
		$error  = get_transient( 'payu_manual_link_error_' . get_current_user_id() );
		if ( isset( $_GET['payu_created'] ) && $result ) {
			delete_transient( 'payu_manual_link_result_' . get_current_user_id() );
		}
		if ( isset( $_GET['payu_error'] ) && $error ) {
			delete_transient( 'payu_manual_link_error_' . get_current_user_id() );
		}

		$orders     = wc_get_orders( array( 'limit' => 200, 'orderby' => 'date', 'order' => 'DESC', 'return' => 'ids' ) );
		$default_expiry_days = (int) get_option( 'payu_payment_links_expiry_days', 7 );
		$default_expiry_date = gmdate( 'Y-m-d', strtotime( '+' . $default_expiry_days . ' days' ) );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Create PayU Payment Link', 'payu-payment-links-woocommerce' ); ?></h1>

			<?php if ( $error ) : ?>
				<div class="notice notice-error"><p><?php echo esc_html( $error ); ?></p></div>
			<?php endif; ?>

			<?php if ( $result && ! empty( $result['paymentLink'] ) ) : ?>
				<div class="notice notice-success">
					<p><strong><?php esc_html_e( 'Payment link created:', 'payu-payment-links-woocommerce' ); ?></strong></p>
					<p><input type="text" id="payu-manual-link-url" class="large-text" value="<?php echo esc_url( $result['paymentLink'] ); ?>" readonly /></p>
					<p><button type="button" class="button button-secondary" id="payu-manual-copy"><?php esc_html_e( 'Copy link', 'payu-payment-links-woocommerce' ); ?></button></p>
				</div>
			<?php endif; ?>

			<form method="post" action="">
				<?php wp_nonce_field( 'payu_manual_link', 'payu_manual_link_nonce' ); ?>
				<table class="form-table">
					<tr>
						<th scope="row"><label for="payu_amount"><?php esc_html_e( 'Amount', 'payu-payment-links-woocommerce' ); ?> <span class="required">*</span></label></th>
						<td><input type="number" name="payu_amount" id="payu_amount" step="0.01" min="0.01" required class="regular-text" /></td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Currency', 'payu-payment-links-woocommerce' ); ?></th>
						<td><strong>INR</strong></td>
					</tr>
					<tr>
						<th scope="row"><label for="payu_description"><?php esc_html_e( 'Description', 'payu-payment-links-woocommerce' ); ?></label></th>
						<td><input type="text" name="payu_description" id="payu_description" class="large-text" placeholder="<?php esc_attr_e( 'e.g. Invoice #ABC-123', 'payu-payment-links-woocommerce' ); ?>" /></td>
					</tr>
					<tr>
						<th scope="row"><label for="payu_expiry_date"><?php esc_html_e( 'Expiry date', 'payu-payment-links-woocommerce' ); ?></label></th>
						<td><input type="date" name="payu_expiry_date" id="payu_expiry_date" value="<?php echo esc_attr( $default_expiry_date ); ?>" min="<?php echo esc_attr( gmdate( 'Y-m-d' ) ); ?>" class="regular-text" /></td>
					</tr>
					<tr>
						<th scope="row"><label for="payu_customer_email"><?php esc_html_e( 'Customer email(s)', 'payu-payment-links-woocommerce' ); ?></label></th>
						<td><input type="text" name="payu_customer_email" id="payu_customer_email" class="regular-text" placeholder="<?php esc_attr_e( 'email@example.com', 'payu-payment-links-woocommerce' ); ?>" /></td>
					</tr>
					<tr>
						<th scope="row"><label for="payu_customer_phone"><?php esc_html_e( 'Customer phone', 'payu-payment-links-woocommerce' ); ?></label></th>
						<td><input type="text" name="payu_customer_phone" id="payu_customer_phone" class="regular-text" /></td>
					</tr>
					<tr>
						<th scope="row"><label for="payu_attach_order"><?php esc_html_e( 'Attach to order', 'payu-payment-links-woocommerce' ); ?></label></th>
						<td>
							<select name="payu_attach_order" id="payu_attach_order">
								<option value="0"><?php esc_html_e( '-- None (standalone) --', 'payu-payment-links-woocommerce' ); ?></option>
								<?php foreach ( $orders as $oid ) : $o = wc_get_order( $oid ); if ( ! $o ) { continue; } ?>
									<option value="<?php echo absint( $oid ); ?>">#<?php echo absint( $oid ); ?> &ndash; <?php echo esc_html( $o->get_billing_email() ); ?></option>
								<?php endforeach; ?>
							</select>
							<p class="description"><?php esc_html_e( 'Optional: attach this link to an existing WooCommerce order.', 'payu-payment-links-woocommerce' ); ?></p>
						</td>
					</tr>
				<tr>
						<th scope="row"><?php esc_html_e( 'Partial payment', 'payu-payment-links-woocommerce' ); ?></th>
						<td>
							<label><input type="checkbox" name="payu_partial_payment" value="1" <?php checked( PayU_Config::is_partial_payment_enabled() ); ?> /> <?php esc_html_e( 'Allow partial payment for this link', 'payu-payment-links-woocommerce' ); ?></label>
						</td>
					</tr>
				</table>
			<p class="submit"><button type="submit" class="button button-primary"><?php esc_html_e( 'Create payment link', 'payu-payment-links-woocommerce' ); ?></button></p>
			</form>
		</div>
	<script>
	(function(){
		var btn = document.getElementById('payu-manual-copy');
		var input = document.getElementById('payu-manual-link-url');
		if (btn && input) {
			btn.onclick = function() {
				if (navigator.clipboard && navigator.clipboard.writeText) {
					navigator.clipboard.writeText(input.value).then(function(){ btn.textContent = '<?php echo esc_js( __( 'Copied!', 'payu-payment-links-woocommerce' ) ); ?>'; });
				} else {
					input.select(); document.execCommand('copy');
					btn.textContent = '<?php echo esc_js( __( 'Copied!', 'payu-payment-links-woocommerce' ) ); ?>';
				}
			};
		}

		// Auto-fill customer email/phone when an order is selected.
		var orderSelect = document.getElementById('payu_attach_order');
		var emailInput  = document.getElementById('payu_customer_email');
		var phoneInput  = document.getElementById('payu_customer_phone');
		if (orderSelect && emailInput && phoneInput) {
			orderSelect.addEventListener('change', function () {
				var orderId = this.value;
				if (!orderId || orderId === '0') {
					return; // standalone — leave fields as-is
				}
				var data = new URLSearchParams();
				data.append('action', 'payu_get_order_customer');
				data.append('order_id', orderId);
				data.append('nonce', '<?php echo esc_js( wp_create_nonce( 'payu_get_order_customer' ) ); ?>');
				fetch(ajaxurl, { method: 'POST', body: data })
					.then(function (r) { return r.json(); })
					.then(function (resp) {
						if (resp.success) {
							if (resp.data.email && !emailInput.value) {
								emailInput.value = resp.data.email;
							}
							if (resp.data.phone && !phoneInput.value) {
								phoneInput.value = resp.data.phone;
							}
						}
					})
					.catch(function () {
					console.warn('[PayU] Could not auto-fill customer details for the selected order.');
				});
			});
		}
	})();
	</script>
		<?php
	}
}
