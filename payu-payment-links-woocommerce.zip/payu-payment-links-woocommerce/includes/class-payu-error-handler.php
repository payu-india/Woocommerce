<?php
/**
 * Shared helpers to normalize and log exceptions.
 *
 * @package PayU_Payment_Links_WooCommerce
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class PayU_Error_Handler
 */
class PayU_Error_Handler {

	/**
	 * Convert unknown exceptions to plugin exceptions.
	 *
	 * @param Throwable $error   Source error.
	 * @param string    $message Fallback message.
	 * @param array     $context Extra context.
	 * @return PayU_Plugin_Exception
	 */
	public static function normalize( $error, $message, array $context = array() ) {
		if ( $error instanceof PayU_Plugin_Exception ) {
			return $error;
		}

		$context['source_message'] = $error instanceof Exception ? $error->getMessage() : $message;
		return new PayU_Plugin_Exception( $message, 0, $context, $error instanceof Throwable ? $error : null );
	}

	/**
	 * Return safe message for UI/order notes.
	 *
	 * @param Throwable $error Source error.
	 * @return string
	 */
	public static function user_message( $error ) {
		if ( $error instanceof Exception && $error->getMessage() ) {
			return $error->getMessage();
		}
		return __( 'Unexpected error occurred.', 'payu-payment-links-woocommerce' );
	}

	/**
	 * Persist exception details to events table.
	 *
	 * @param string    $event_type Event type.
	 * @param Throwable $error      Exception.
	 * @param array     $context    Additional context.
	 * @return void
	 */
	public static function log_exception( $event_type, $error, array $context = array() ) {
		$payload = array(
			'event_type'      => $event_type,
			'direction'       => 'internal',
			'status'          => 'error',
			'error_message'   => self::user_message( $error ),
			'context_payload' => wp_json_encode( $context ),
		);

		if ( $error instanceof PayU_Plugin_Exception ) {
			$ctx = $error->get_context();
			if ( isset( $ctx['order_id'] ) ) {
				$payload['order_id'] = (int) $ctx['order_id'];
			}
			if ( isset( $ctx['link_id'] ) ) {
				$payload['link_id'] = (int) $ctx['link_id'];
			}
			if ( isset( $ctx['invoice_number'] ) ) {
				$payload['invoice_number'] = (string) $ctx['invoice_number'];
			}
			if ( isset( $ctx['request_id'] ) ) {
				$payload['request_id'] = (string) $ctx['request_id'];
			}
			$payload['context_payload'] = wp_json_encode( $ctx );
		}

		PayU_DB::log_event( $payload );
	}
}
