<?php
/**
 * Centralized config accessor for plugin options.
 *
 * @package PayU_Payment_Links_WooCommerce
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class PayU_Config
 */
class PayU_Config {

	/**
	 * Get PayU environment.
	 *
	 * @return string
	 */
	public static function env() {
		return get_option( 'payu_payment_links_environment', 'test' );
	}

	/**
	 * Whether partial payment is enabled by default.
	 *
	 * @return bool
	 */
	public static function is_partial_payment_enabled() {
		return 'yes' === get_option( 'payu_payment_links_partial_payment', 'no' );
	}

	/**
	 * Whether merchant opted out of key/salt mode.
	 *
	 * @return bool
	 */
	public static function is_no_key_salt_mode() {
		return 'yes' === get_option( 'payu_payment_links_no_key_salt', 'no' );
	}

	/**
	 * Order status configured for successful full payment.
	 *
	 * @return string
	 */
	public static function order_status_on_payment() {
		return get_option( 'payu_payment_links_order_status_on_payment', 'completed' );
	}

	/**
	 * Get primary credentials.
	 *
	 * @return array{currency:string,merchant_id:string,client_id:string,client_secret:string,merchant_key:string,salt:string}
	 */
	public static function credentials() {
		return array(
			'currency'      => 'INR',
			'merchant_id'   => (string) get_option( 'payu_payment_links_merchant_id', '' ),
			'client_id'     => (string) get_option( 'payu_payment_links_client_id', '' ),
			'client_secret' => (string) get_option( 'payu_payment_links_client_secret', '' ),
			'merchant_key'  => (string) get_option( 'payu_payment_links_merchant_key', '' ),
			'salt'          => (string) get_option( 'payu_payment_links_salt', '' ),
		);
	}
}
