<?php
/**
 * Plugin-specific exception taxonomy.
 *
 * @package PayU_Payment_Links_WooCommerce
 */

defined( 'ABSPATH' ) || exit;

/**
 * Base exception that carries structured context.
 */
class PayU_Plugin_Exception extends Exception {
	/** @var array */
	protected $context = array();

	/**
	 * @param string         $message  Error message.
	 * @param int            $code     Error code.
	 * @param array          $context  Additional context.
	 * @param Throwable|null $previous Previous exception.
	 */
	public function __construct( $message = '', $code = 0, array $context = array(), Throwable $previous = null ) {
		$context['thread_id'] = isset( $context['thread_id'] ) ? $context['thread_id'] : ( function_exists( 'getmypid' ) ? (int) getmypid() : 0 );
		$context['time']      = isset( $context['time'] ) ? $context['time'] : gmdate( 'c' );
		$this->context        = $context;
		parent::__construct( $message, $code, $previous );
	}

	/**
	 * @return array
	 */
	public function get_context() {
		return $this->context;
	}
}

/**
 * Exception for configuration issues.
 */
class PayU_Configuration_Exception extends PayU_Plugin_Exception {}

/**
 * Exception for validation issues.
 */
class PayU_Validation_Exception extends PayU_Plugin_Exception {}

/**
 * Exception for upstream transport/network issues.
 */
class PayU_Transport_Exception extends PayU_Plugin_Exception {}

/**
 * Exception for upstream API semantic failures.
 */
class PayU_API_Exception extends PayU_Plugin_Exception {}
