<?php
/**
 * PayU Payment Links settings page (WooCommerce Settings).
 *
 * @package PayU_Payment_Links_WooCommerce
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'WC_Settings_Page' ) ) {
	return;
}

/**
 * Class PayU_Settings
 */
class PayU_Settings extends WC_Settings_Page {

	public function __construct() {
		$this->id    = 'payu_payment_links';
		$this->label = __( 'PayU Payment Links', 'payu-payment-links-woocommerce' );
		parent::__construct();
		add_action( 'admin_footer', array( $this, 'print_no_key_salt_realtime_script' ) );
	}

	/**
	 * Get settings fields array.
	 *
	 * @return array
	 */
	public function get_settings() {
		$signup_url  = defined( 'PAYU_SIGNUP_UTM_URL' ) ? PAYU_SIGNUP_UTM_URL : 'https://payu.in/';
		$no_key_salt = 'yes' === get_option( 'payu_payment_links_no_key_salt', 'no' );

		$limited_mode_note = '<div id="payu-no-key-salt-note" style="background:#fff3cd;border-left:4px solid #ffc107;padding:10px 14px;margin:10px 0;font-size:13px;' . ( $no_key_salt ? '' : 'display:none;' ) . '">'
			. '<strong>' . esc_html__( 'Limited mode (no Merchant Key & Salt):', 'payu-payment-links-woocommerce' ) . '</strong><br>'
			. esc_html__( '1. Refunds cannot be initiated from WooCommerce. To refund, use the', 'payu-payment-links-woocommerce' )
			. ' <a href="https://docs.payu.in/docs/refunds-dashboard" target="_blank" rel="noopener">' . esc_html__( 'PayU Dashboard', 'payu-payment-links-woocommerce' ) . '</a>. '
			. esc_html__( 'After a successful refund on PayU, manually mark the order as Refunded or Partially Refunded in WooCommerce.', 'payu-payment-links-woocommerce' ) . '<br>'
			. esc_html__( '2. UTR numbers will not be automatically populated.', 'payu-payment-links-woocommerce' ) . '<br>'
			. esc_html__( '3. Payment status is updated via a background poll every 5 minutes and in real-time when you open an order.', 'payu-payment-links-woocommerce' ) . '<br>'
			. esc_html__( '4. Webhook verification is disabled; payment status relies on polling.', 'payu-payment-links-woocommerce' )
			. '</div>';

		$settings = array(
			array(
				'title' => __( 'PayU Payment Links', 'payu-payment-links-woocommerce' ),
				'type'  => 'title',
				'desc'  => __( 'Configure PayU credentials and defaults for creating payment links.', 'payu-payment-links-woocommerce' )
					. ' <p><a href="' . esc_url( $signup_url ) . '" target="_blank" rel="noopener noreferrer" class="button button-secondary">'
					. esc_html__( 'Create PayU Account', 'payu-payment-links-woocommerce' ) . '</a></p>',
				'id'    => 'payu_payment_links_options',
			),
			array(
				'title'   => __( 'Environment', 'payu-payment-links-woocommerce' ),
				'id'      => 'payu_payment_links_environment',
				'type'    => 'select',
				'default' => 'test',
				'options' => array(
					'test' => __( 'Test (UAT)', 'payu-payment-links-woocommerce' ),
					'prod' => __( 'Production', 'payu-payment-links-woocommerce' ),
				),
			),
			array(
				'title'       => __( 'Client ID', 'payu-payment-links-woocommerce' ),
				'id'          => 'payu_payment_links_client_id',
				'type'        => 'text',
				'desc_tip'    => __( 'OAuth Client ID from PayU Dashboard.', 'payu-payment-links-woocommerce' ),
			),
			array(
				'title'       => __( 'Client Secret', 'payu-payment-links-woocommerce' ),
				'id'          => 'payu_payment_links_client_secret',
				'type'        => 'password',
				'desc_tip'    => __( 'OAuth Client Secret from PayU Dashboard.', 'payu-payment-links-woocommerce' ),
			),
			array(
				'title'       => __( 'Merchant ID', 'payu-payment-links-woocommerce' ),
				'id'          => 'payu_payment_links_merchant_id',
				'type'        => 'text',
				'desc_tip'    => __( 'Used as merchantId header in Payment Links API requests.', 'payu-payment-links-woocommerce' ),
			),
			array(
				'title'   => __( 'I don\'t have Merchant Key & Salt', 'payu-payment-links-woocommerce' ),
				'id'      => 'payu_payment_links_no_key_salt',
				'type'    => 'checkbox',
				'default' => 'no',
				'desc'    => __( 'Check this if you do not have a Merchant Key and Salt from PayU. Refunds, UTR retrieval, and webhook verification will be unavailable.', 'payu-payment-links-woocommerce' )
					. $limited_mode_note,
			),
		);

		$settings[] = array(
			'title'       => __( 'Merchant Key', 'payu-payment-links-woocommerce' ),
			'id'          => 'payu_payment_links_merchant_key',
			'type'        => 'text',
			'desc_tip'    => __( 'Merchant key for Settlement, Refund APIs, and webhook verification. From PayU Dashboard.', 'payu-payment-links-woocommerce' ),
		);
		$settings[] = array(
			'title'       => __( 'Salt', 'payu-payment-links-woocommerce' ),
			'id'          => 'payu_payment_links_salt',
			'type'        => 'password',
			'desc_tip'    => __( 'Salt for hash verification. From PayU Dashboard.', 'payu-payment-links-woocommerce' ),
		);
		$settings = array_merge( $settings, array(
			array(
				'title'   => __( 'Allow partial payment', 'payu-payment-links-woocommerce' ),
				'id'      => 'payu_payment_links_partial_payment',
				'type'    => 'checkbox',
				'default' => 'no',
				'desc'    => __( 'Allow customers to pay less than the full amount (if supported by PayU).', 'payu-payment-links-woocommerce' ),
			),
			array(
				'title'   => __( 'Order status after payment', 'payu-payment-links-woocommerce' ),
				'id'      => 'payu_payment_links_order_status_on_payment',
				'type'    => 'select',
				'default' => 'completed',
				'options' => array(
					'completed'  => __( 'Completed — invoice paid, order done (recommended for payment links)', 'payu-payment-links-woocommerce' ),
					'processing' => __( 'Processing — payment received, awaiting fulfillment', 'payu-payment-links-woocommerce' ),
				),
				'desc'    => __( 'WooCommerce order status to set when payment is confirmed.', 'payu-payment-links-woocommerce' ),
			),
			array(
				'title'             => __( 'Default link expiry (days)', 'payu-payment-links-woocommerce' ),
				'id'                => 'payu_payment_links_expiry_days',
				'type'              => 'number',
				'default'           => 7,
				'custom_attributes' => array( 'min' => 1, 'max' => 365, 'step' => 1 ),
				'desc'              => __( 'Number of days until a payment link expires (1-365). Can be overridden per link.', 'payu-payment-links-woocommerce' ),
			),
			array(
				'title'   => __( 'Description prefix', 'payu-payment-links-woocommerce' ),
				'id'      => 'payu_payment_links_description_prefix',
				'type'    => 'text',
				'default' => 'Order',
				'desc'    => __( 'Prefix for auto-generated link description, e.g. "Order" produces "Order #1234".', 'payu-payment-links-woocommerce' ),
			),
			array(
				'type' => 'sectionend',
				'id'   => 'payu_payment_links_options',
			),
		) );

		return apply_filters( 'woocommerce_get_settings_payu_payment_links', $settings );
	}

	/**
	 * Save settings and clear token cache when credentials change.
	 */
	public function save() {
		$client_id_old    = get_option( 'payu_payment_links_client_id', '' );
		$no_key_salt_old  = get_option( 'payu_payment_links_no_key_salt', 'no' );

		parent::save();

		$client_id_new   = get_option( 'payu_payment_links_client_id', '' );
		$no_key_salt_new = get_option( 'payu_payment_links_no_key_salt', 'no' );

		// Clear token cache when credentials change.
		if ( $client_id_old !== $client_id_new ) {
			global $wpdb;
			$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_payu_payment_links_token_%'" );
		}

		// Reschedule crons when key/salt availability changes.
		if ( $no_key_salt_old !== $no_key_salt_new ) {
			if ( 'yes' === $no_key_salt_new ) {
				wp_clear_scheduled_hook( 'payu_payment_links_fetch_utr' );
				wp_clear_scheduled_hook( 'payu_payment_links_poll_refunds' );
			} else {
				if ( ! wp_next_scheduled( 'payu_payment_links_fetch_utr' ) ) {
					wp_schedule_event( time(), 'daily', 'payu_payment_links_fetch_utr' );
				}
				if ( ! wp_next_scheduled( 'payu_payment_links_poll_refunds' ) ) {
					wp_schedule_event( time(), 'hourly', 'payu_payment_links_poll_refunds' );
				}
			}

			// Always ensure txn polling is running.
			if ( ! wp_next_scheduled( 'payu_payment_links_poll_txns' ) ) {
				wp_schedule_event( time(), 'every_five_minutes', 'payu_payment_links_poll_txns' );
			}
		}
	}

	/**
	 * Real-time settings UI toggle for no key/salt mode.
	 */
	public function print_no_key_salt_realtime_script() {
		if ( ! function_exists( 'get_current_screen' ) ) {
			return;
		}
		$screen = get_current_screen();
		if ( ! $screen || 'woocommerce_page_wc-settings' !== $screen->id ) {
			return;
		}

		$tab = isset( $_GET['tab'] ) ? sanitize_text_field( wp_unslash( $_GET['tab'] ) ) : '';
		if ( $this->id !== $tab ) {
			return;
		}
		?>
		<script>
		(function () {
			var checkbox = document.getElementById('payu_payment_links_no_key_salt');
			if (!checkbox) {
				return;
			}

			function toggleRows() {
				var hide = checkbox.checked;
				var rowIds = [
					'payu_payment_links_merchant_key',
					'payu_payment_links_salt'
				];
				for (var i = 0; i < rowIds.length; i++) {
					var field = document.getElementById(rowIds[i]);
					if (!field) {
						continue;
					}
					var row = field.closest('tr');
					if (row) {
						row.style.display = hide ? 'none' : '';
					}
				}

				var note = document.getElementById('payu-no-key-salt-note');
				if (note) {
					note.style.display = hide ? 'block' : 'none';
				}
			}

			checkbox.addEventListener('change', toggleRows);
			toggleRows();
		})();
		</script>
		<?php
	}
}

return new PayU_Settings();
