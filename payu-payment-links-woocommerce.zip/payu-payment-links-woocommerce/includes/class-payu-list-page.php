<?php
/**
 * Payment Links list, detail view, CSV export, and sync actions.
 *
 * @package PayU_Payment_Links_WooCommerce
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class PayU_List_Page
 */
class PayU_List_Page {

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'add_menu' ), 21 );
		add_action( 'admin_init', array( $this, 'handle_export' ) );
		add_action( 'wp_ajax_payu_payment_links_sync', array( $this, 'ajax_sync_statuses' ) );
	}

	public function add_menu() {
		add_submenu_page(
			'woocommerce',
			__( 'Payment Links', 'payu-payment-links-woocommerce' ),
			__( 'Payment Links', 'payu-payment-links-woocommerce' ),
			'manage_woocommerce',
			'payu-payment-links',
			array( $this, 'render_page' )
		);
	}

	/* ---------------------------------------------------------------
	 * CSV Export
	 * ------------------------------------------------------------- */

	public function handle_export() {
		if ( ! isset( $_GET['payu_export_csv'] ) || ! isset( $_GET['_wpnonce'] ) || ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'payu_export_csv' ) ) {
			return;
		}

		$from = isset( $_GET['from'] ) ? sanitize_text_field( wp_unslash( $_GET['from'] ) ) : gmdate( 'Y-m-d', strtotime( '-30 days' ) );
		$to   = isset( $_GET['to'] ) ? sanitize_text_field( wp_unslash( $_GET['to'] ) ) : gmdate( 'Y-m-d' );

		$rows = PayU_DB::get_for_date_range(
			$from . ' 00:00:00',
			$to . ' 23:59:59',
			array( 'limit' => 5000 )
		);

		$filename = 'payu-payment-links-' . gmdate( 'Y-m-d' ) . '.csv';
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=' . $filename );
		$out = fopen( 'php://output', 'w' );
		fputcsv( $out, array( 'Invoice', 'Order ID', 'Amount', 'Currency', 'Paid Amount', 'Pending Amount', 'Link Status', 'Payment Status', 'Refund Amount', 'Failure Count', 'Created', 'Expiry', 'UTR Number', 'Shared To', 'Shared At', 'Customer Email', 'Payment Link' ) );

		foreach ( $rows as $row ) {
			$paid_amount    = isset( $row->paid_amount ) ? (float) $row->paid_amount : 0.0;
			$link_amount    = isset( $row->amount ) ? (float) $row->amount : 0.0;
			$pending_amount = max( 0.0, round( $link_amount - $paid_amount, 2 ) );
			fputcsv( $out, array(
				$row->invoice_number,
				$row->order_id ?: '',
				$link_amount ? number_format( $link_amount, 2, '.', '' ) : '0.00',
				$row->currency,
				number_format( $paid_amount, 2, '.', '' ),
				number_format( $pending_amount, 2, '.', '' ),
				$row->status,
				isset( $row->payment_status ) ? $row->payment_status : 'pending',
				isset( $row->refund_amount ) && (float) $row->refund_amount > 0 ? number_format( (float) $row->refund_amount, 2, '.', '' ) : '0.00',
				isset( $row->failure_count ) ? (int) $row->failure_count : 0,
				$row->created_at,
				$row->expiry_date ?: '',
				$row->utr_number ?: '',
				isset( $row->last_shared_to ) ? $row->last_shared_to : '',
				isset( $row->last_shared_at ) ? $row->last_shared_at : '',
				$row->customer_email ?: '',
				$row->payment_link_url,
			) );
		}

		fclose( $out );
		exit;
	}

	/* ---------------------------------------------------------------
	 * AJAX: Sync statuses from PayU (Get All Payment Links API)
	 * ------------------------------------------------------------- */

	public function ajax_sync_statuses() {
		check_ajax_referer( 'payu_payment_links_admin', 'nonce' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'payu-payment-links-woocommerce' ) ) );
		}

		$from     = isset( $_POST['from'] ) ? sanitize_text_field( wp_unslash( $_POST['from'] ) ) : gmdate( 'Y-m-d', strtotime( '-30 days' ) );
		$to       = isset( $_POST['to'] ) ? sanitize_text_field( wp_unslash( $_POST['to'] ) ) : gmdate( 'Y-m-d' );
		$currency = isset( $_POST['currency'] ) ? sanitize_text_field( wp_unslash( $_POST['currency'] ) ) : '';

		try {
			$client = new PayU_API_Client();
			$payu   = $client->get_all_payment_links( $from, $to, $currency ?: null, 0, 500 );
		} catch ( Exception $e ) {
			wp_send_json_error( array( 'message' => $e->getMessage() ) );
		}

		$links = array();
		if ( isset( $payu['result'] ) && is_array( $payu['result'] ) ) {
			$links = $payu['result'];
		} elseif ( isset( $payu['result']['data'] ) && is_array( $payu['result']['data'] ) ) {
			$links = $payu['result']['data'];
		}

		$updated = 0;
		foreach ( $links as $pl ) {
			$inv = isset( $pl['invoiceNumber'] ) ? $pl['invoiceNumber'] : '';
			if ( ! $inv ) {
				continue;
			}
			$local = PayU_DB::get_by_invoice( $inv );
			if ( ! $local ) {
				continue;
			}
			$update = array();
			if ( isset( $pl['status'] ) ) {
				$normalized_status = strtolower( sanitize_text_field( $pl['status'] ) );
				if ( in_array( $normalized_status, array( 'active', 'expired' ), true ) && $normalized_status !== $local->status ) {
					$update['status'] = $normalized_status;
				}
			}
			if ( isset( $pl['totalAmount'] ) && (float) $pl['totalAmount'] !== (float) $local->amount ) {
				$update['amount'] = (float) $pl['totalAmount'];
			}
			if ( ! empty( $update ) ) {
				PayU_DB::update( $local->id, $update );
				$updated++;
			}
		}

		wp_send_json_success( array(
			'message' => sprintf( __( 'Sync complete. %d link(s) updated.', 'payu-payment-links-woocommerce' ), $updated ),
			'updated' => $updated,
		) );
	}

	/* ---------------------------------------------------------------
	 * Router
	 * ------------------------------------------------------------- */

	public function render_page() {
		$view     = isset( $_GET['view'] ) ? sanitize_text_field( wp_unslash( $_GET['view'] ) ) : 'list';
		$order_id = isset( $_GET['link_id'] ) ? absint( $_GET['link_id'] ) : 0;

		if ( 'detail' === $view && $order_id ) {
			$this->render_detail( $order_id );
			return;
		}
		$this->render_list();
	}

	/* ---------------------------------------------------------------
	 * List view
	 * ------------------------------------------------------------- */

	private function render_list() {
		$from = isset( $_GET['from'] ) ? sanitize_text_field( wp_unslash( $_GET['from'] ) ) : gmdate( 'Y-m-d', strtotime( '-30 days' ) );
		$to   = isset( $_GET['to'] ) ? sanitize_text_field( wp_unslash( $_GET['to'] ) ) : gmdate( 'Y-m-d' );

		$rows = PayU_DB::get_for_date_range(
			$from . ' 00:00:00',
			$to . ' 23:59:59'
		);

		$export_url = wp_nonce_url( add_query_arg( array(
			'payu_export_csv' => '1',
			'from'            => $from,
			'to'              => $to,
		), admin_url( 'admin.php' ) ), 'payu_export_csv' );
		?>
		<div class="wrap payu-list-page">
			<h1><?php esc_html_e( 'Payment Links', 'payu-payment-links-woocommerce' ); ?></h1>

			<form method="get" action="" class="payu-filters" style="margin-bottom:16px;">
				<input type="hidden" name="page" value="payu-payment-links" />
				<label for="payu-from"><?php esc_html_e( 'From', 'payu-payment-links-woocommerce' ); ?></label>
				<input type="date" id="payu-from" name="from" value="<?php echo esc_attr( $from ); ?>" />
				<label for="payu-to"><?php esc_html_e( 'To', 'payu-payment-links-woocommerce' ); ?></label>
				<input type="date" id="payu-to" name="to" value="<?php echo esc_attr( $to ); ?>" />
				<button type="submit" class="button"><?php esc_html_e( 'Filter', 'payu-payment-links-woocommerce' ); ?></button>
				<a href="<?php echo esc_url( $export_url ); ?>" class="button"><?php esc_html_e( 'Export CSV', 'payu-payment-links-woocommerce' ); ?></a>
				<button type="button" class="button payu-sync-statuses" data-from="<?php echo esc_attr( $from ); ?>" data-to="<?php echo esc_attr( $to ); ?>"><?php esc_html_e( 'Sync statuses from PayU', 'payu-payment-links-woocommerce' ); ?></button>
			</form>

			<table class="wp-list-table widefat fixed striped">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Invoice', 'payu-payment-links-woocommerce' ); ?></th>
						<th><?php esc_html_e( 'Order', 'payu-payment-links-woocommerce' ); ?></th>
						<th><?php esc_html_e( 'Amount', 'payu-payment-links-woocommerce' ); ?></th>
						<th><?php esc_html_e( 'Currency', 'payu-payment-links-woocommerce' ); ?></th>
						<th><?php esc_html_e( 'Link Status', 'payu-payment-links-woocommerce' ); ?></th>
						<th><?php esc_html_e( 'Payment', 'payu-payment-links-woocommerce' ); ?></th>
						<th><?php esc_html_e( 'Refund Amount', 'payu-payment-links-woocommerce' ); ?></th>
						<th><?php esc_html_e( 'Refund Status', 'payu-payment-links-woocommerce' ); ?></th>
						<th><?php esc_html_e( 'Created', 'payu-payment-links-woocommerce' ); ?></th>
						<th><?php esc_html_e( 'Expiry', 'payu-payment-links-woocommerce' ); ?></th>
						<th><?php esc_html_e( 'UTR', 'payu-payment-links-woocommerce' ); ?></th>
						<th><?php esc_html_e( 'Actions', 'payu-payment-links-woocommerce' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( empty( $rows ) ) : ?>
						<tr><td colspan="12"><?php esc_html_e( 'No payment links in this date range.', 'payu-payment-links-woocommerce' ); ?></td></tr>
					<?php else : ?>
						<?php foreach ( $rows as $row ) : ?>
							<tr data-link-id="<?php echo absint( $row->id ); ?>" data-invoice="<?php echo esc_attr( $row->invoice_number ); ?>" data-currency="<?php echo esc_attr( $row->currency ); ?>">
								<td><?php echo esc_html( $row->invoice_number ); ?></td>
								<td>
									<?php if ( $row->order_id ) : ?>
										<a href="<?php echo esc_url( $this->get_order_edit_url( $row->order_id ) ); ?>">#<?php echo absint( $row->order_id ); ?></a>
									<?php else : ?>
										&mdash;
									<?php endif; ?>
								</td>
								<td><?php echo esc_html( $row->amount ? number_format_i18n( (float) $row->amount, 2 ) : '-' ); ?></td>
								<td><?php echo esc_html( $row->currency ); ?></td>
								<td class="payu-status-cell"><span class="payu-badge payu-badge-<?php echo esc_attr( $row->status ); ?>"><?php echo esc_html( $row->status ); ?></span></td>
								<td class="payu-payment-status-cell"><span class="payu-badge payu-badge-<?php echo esc_attr( isset( $row->payment_status ) ? $row->payment_status : 'pending' ); ?>"><?php echo esc_html( isset( $row->payment_status ) ? $row->payment_status : 'pending' ); ?></span></td>
								<td><?php echo ( isset( $row->refund_amount ) && (float) $row->refund_amount > 0 ) ? esc_html( number_format_i18n( (float) $row->refund_amount, 2 ) ) : 'NA'; ?></td>
								<td><?php echo ! empty( $row->refund_status ) ? '<span class="payu-badge payu-badge-' . esc_attr( $row->refund_status ) . '">' . esc_html( $row->refund_status ) . '</span>' : 'NA'; ?></td>
								<td><?php echo esc_html( $row->created_at ); ?></td>
								<td><?php echo esc_html( $row->expiry_date ?: '-' ); ?></td>
								<td class="payu-utr-cell"><?php echo esc_html( $row->utr_number ?: '-' ); ?></td>
								<td>
									<a href="<?php echo esc_url( add_query_arg( array( 'page' => 'payu-payment-links', 'view' => 'detail', 'link_id' => $row->id ), admin_url( 'admin.php' ) ) ); ?>"><?php esc_html_e( 'View', 'payu-payment-links-woocommerce' ); ?></a>
									| <a href="#" class="payu-copy-link-list" data-url="<?php echo esc_attr( $row->payment_link_url ); ?>"><?php esc_html_e( 'Copy', 'payu-payment-links-woocommerce' ); ?></a>
									| <a href="#" class="payu-resend-link-list"><?php esc_html_e( 'Resend', 'payu-payment-links-woocommerce' ); ?></a>
									| <a href="#" class="payu-refresh-link-list"><?php esc_html_e( 'Refresh', 'payu-payment-links-woocommerce' ); ?></a>
								</td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>
		</div>
		<?php
	}

	/* ---------------------------------------------------------------
	 * Detail view
	 * ------------------------------------------------------------- */

	private function render_detail( $link_id ) {
		$link = PayU_DB::get_by_id( $link_id );
		if ( ! $link ) {
			echo '<div class="wrap"><p>' . esc_html__( 'Payment link not found.', 'payu-payment-links-woocommerce' ) . '</p></div>';
			return;
		}

		$list_url = add_query_arg( array( 'page' => 'payu-payment-links' ), admin_url( 'admin.php' ) );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Payment Link Detail', 'payu-payment-links-woocommerce' ); ?></h1>
			<p>
				<a href="<?php echo esc_url( $list_url ); ?>">&larr; <?php esc_html_e( 'Back to list', 'payu-payment-links-woocommerce' ); ?></a>
				<?php if ( $link->order_id ) : ?>
					| <a href="<?php echo esc_url( $this->get_order_edit_url( $link->order_id ) ); ?>"><?php esc_html_e( 'Edit order', 'payu-payment-links-woocommerce' ); ?></a>
				<?php endif; ?>
			</p>
			<table class="form-table">
				<tr><th scope="row"><?php esc_html_e( 'Invoice number', 'payu-payment-links-woocommerce' ); ?></th><td><?php echo esc_html( $link->invoice_number ); ?></td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Order ID', 'payu-payment-links-woocommerce' ); ?></th><td><?php echo $link->order_id ? '<a href="' . esc_url( $this->get_order_edit_url( $link->order_id ) ) . '">#' . absint( $link->order_id ) . '</a>' : '&mdash; (standalone)'; ?></td></tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Payment link URL', 'payu-payment-links-woocommerce' ); ?></th>
					<td>
						<input type="text" class="large-text" value="<?php echo esc_url( $link->payment_link_url ); ?>" readonly />
						<button type="button" class="button payu-copy-detail" data-url="<?php echo esc_attr( $link->payment_link_url ); ?>"><?php esc_html_e( 'Copy', 'payu-payment-links-woocommerce' ); ?></button>
					</td>
				</tr>
			<tr><th scope="row"><?php esc_html_e( 'Amount', 'payu-payment-links-woocommerce' ); ?></th><td><?php echo esc_html( $link->amount ? number_format_i18n( (float) $link->amount, 2 ) : '-' ); ?> <?php echo esc_html( $link->currency ); ?></td></tr>
			<tr><th scope="row"><?php esc_html_e( 'Currency', 'payu-payment-links-woocommerce' ); ?></th><td><?php echo esc_html( $link->currency ); ?></td></tr>
			<?php
			$paid_v    = isset( $link->paid_amount ) ? (float) $link->paid_amount : 0.0;
			$link_tot  = (float) $link->amount;
			$p_status  = isset( $link->payment_status ) ? $link->payment_status : 'pending';
			if ( 'partially_paid' === $p_status && $paid_v > 0 ) :
				$pending_v = max( 0.0, round( $link_tot - $paid_v, 2 ) );
				?>
			<tr>
				<th scope="row"><?php esc_html_e( 'Paid amount', 'payu-payment-links-woocommerce' ); ?></th>
				<td><?php echo esc_html( $link->currency . ' ' . number_format_i18n( $paid_v, 2 ) ); ?></td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Pending amount', 'payu-payment-links-woocommerce' ); ?></th>
				<td><?php echo esc_html( $link->currency . ' ' . number_format_i18n( $pending_v, 2 ) ); ?></td>
			</tr>
			<?php endif; ?>
				<tr><th scope="row"><?php esc_html_e( 'Link status', 'payu-payment-links-woocommerce' ); ?></th><td><span class="payu-badge payu-badge-<?php echo esc_attr( $link->status ); ?>"><?php echo esc_html( $link->status ); ?></span></td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Payment status', 'payu-payment-links-woocommerce' ); ?></th><td><span class="payu-badge payu-badge-<?php echo esc_attr( isset( $link->payment_status ) ? $link->payment_status : 'pending' ); ?>"><?php echo esc_html( isset( $link->payment_status ) ? $link->payment_status : 'pending' ); ?></span></td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Description', 'payu-payment-links-woocommerce' ); ?></th><td><?php echo esc_html( $link->description ?: '-' ); ?></td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Created', 'payu-payment-links-woocommerce' ); ?></th><td><?php echo esc_html( $link->created_at ); ?></td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Expiry date', 'payu-payment-links-woocommerce' ); ?></th><td><?php echo esc_html( $link->expiry_date ?: '-' ); ?></td></tr>
				<tr><th scope="row"><?php esc_html_e( 'UTR number', 'payu-payment-links-woocommerce' ); ?></th><td><?php echo esc_html( $link->utr_number ?: '-' ); ?></td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Refund amount', 'payu-payment-links-woocommerce' ); ?></th><td><?php echo isset( $link->refund_amount ) && (float) $link->refund_amount > 0 ? esc_html( $link->currency . ' ' . number_format_i18n( (float) $link->refund_amount, 2 ) ) : '-'; ?></td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Refund request ID', 'payu-payment-links-woocommerce' ); ?></th><td><?php echo esc_html( ! empty( $link->refund_request_id ) ? $link->refund_request_id : '-' ); ?></td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Refund status', 'payu-payment-links-woocommerce' ); ?></th><td><?php echo ! empty( $link->refund_status ) ? '<span class="payu-badge payu-badge-' . esc_attr( $link->refund_status ) . '">' . esc_html( $link->refund_status ) . '</span>' : '-'; ?></td></tr>
				<tr><th scope="row"><?php esc_html_e( 'PayU Transaction ID', 'payu-payment-links-woocommerce' ); ?></th><td><?php echo esc_html( $link->payu_txn_id ?: '-' ); ?></td></tr>
				<tr><th scope="row"><?php esc_html_e( 'UDF1 (Order ID)', 'payu-payment-links-woocommerce' ); ?></th><td><?php echo esc_html( $link->udf1 ?: '-' ); ?></td></tr>
				<tr><th scope="row"><?php esc_html_e( 'UDF5 (Source)', 'payu-payment-links-woocommerce' ); ?></th><td><?php echo esc_html( $link->udf5 ?: '-' ); ?></td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Customer email', 'payu-payment-links-woocommerce' ); ?></th><td><?php echo esc_html( $link->customer_email ?: '-' ); ?></td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Customer phone', 'payu-payment-links-woocommerce' ); ?></th><td><?php echo esc_html( $link->customer_phone ?: '-' ); ?></td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Customer name', 'payu-payment-links-woocommerce' ); ?></th><td><?php echo esc_html( $link->customer_name ?: '-' ); ?></td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Last shared to', 'payu-payment-links-woocommerce' ); ?></th><td><?php echo esc_html( ! empty( $link->last_shared_to ) ? $link->last_shared_to : '-' ); ?></td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Last shared at', 'payu-payment-links-woocommerce' ); ?></th><td><?php echo esc_html( ! empty( $link->last_shared_at ) ? $link->last_shared_at : '-' ); ?></td></tr>
			</table>
		</div>
		<?php
	}

	/* ---------------------------------------------------------------
	 * Helpers
	 * ------------------------------------------------------------- */

	private function get_order_edit_url( $order_id ) {
		if ( function_exists( 'wc_get_container' ) && class_exists( 'Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController' ) ) {
			try {
				$controller = wc_get_container()->get( \Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController::class );
				if ( $controller && $controller->custom_orders_table_usage_is_enabled() ) {
					return admin_url( 'admin.php?page=wc-orders&action=edit&id=' . $order_id );
				}
			} catch ( Exception $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement
			}
		}
		return admin_url( 'post.php?post=' . $order_id . '&action=edit' );
	}
}
