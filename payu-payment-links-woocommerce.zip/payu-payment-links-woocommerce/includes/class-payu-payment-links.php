<?php
/**
 * Core plugin class: hooks, assets, cron, settings, and DB version check.
 *
 * @package PayU_Payment_Links_WooCommerce
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class PayU_Payment_Links
 */
class PayU_Payment_Links {

	/** @var PayU_Payment_Links|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'init', array( $this, 'load_textdomain' ), 0 );
		add_action( 'init', array( $this, 'maybe_upgrade_db' ), 5 );
		add_action( 'init', array( $this, 'register_custom_order_statuses' ), 5 );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_assets' ) );
		add_action( 'current_screen', array( $this, 'maybe_sync_transactions_on_order_screens' ) );
		add_filter( 'woocommerce_get_settings_pages', array( $this, 'add_settings_page' ) );
		add_action( 'init', array( $this, 'register_webhook' ), 5 );
		add_action( 'init', array( $this, 'schedule_cron' ), 10 );
		add_filter( 'cron_schedules', array( $this, 'add_cron_intervals' ) );
		add_action( 'payu_payment_links_fetch_utr', array( $this, 'cron_fetch_utr' ) );
		add_action( 'payu_payment_links_poll_refunds', array( $this, 'cron_poll_refunds' ) );
		add_action( 'payu_payment_links_poll_txns', array( $this, 'cron_poll_transactions' ) );
		add_action( 'payu_payment_links_webhook_reconcile', array( $this, 'cron_reconcile_webhook' ), 10, 3 );
		add_action( 'woocommerce_order_status_changed', array( $this, 'sync_payment_link_on_order_status_change' ), 10, 4 );
		add_action( 'woocommerce_order_refunded', array( $this, 'sync_payment_link_on_refund' ), 10, 2 );
	}

	/* ---------------------------------------------------------------
	 * Text domain
	 * ------------------------------------------------------------- */

	public function load_textdomain() {
		load_plugin_textdomain(
			'payu-payment-links-woocommerce',
			false,
			dirname( PAYU_PAYMENT_LINKS_PLUGIN_BASENAME ) . '/languages'
		);
	}

	/* ---------------------------------------------------------------
	 * DB version check (handles upgrades without reactivation)
	 * ------------------------------------------------------------- */

	public function maybe_upgrade_db() {
		PayU_DB::maybe_upgrade();
	}

	/* ---------------------------------------------------------------
	 * Custom order status: Partially Refunded
	 * ------------------------------------------------------------- */

	public function register_custom_order_statuses() {
		register_post_status( 'wc-partial-refund', array(
			'label'                     => _x( 'Partially Refunded', 'Order status', 'payu-payment-links-woocommerce' ),
			'public'                    => true,
			'exclude_from_search'       => false,
			'show_in_admin_all_list'    => true,
			'show_in_admin_status_list' => true,
			/* translators: %s: count */
			'label_count'               => _n_noop( 'Partially Refunded <span class="count">(%s)</span>', 'Partially Refunded <span class="count">(%s)</span>', 'payu-payment-links-woocommerce' ),
		) );
		register_post_status( 'wc-partially-paid', array(
			'label'                     => _x( 'Partially Paid', 'Order status', 'payu-payment-links-woocommerce' ),
			'public'                    => true,
			'exclude_from_search'       => false,
			'show_in_admin_all_list'    => true,
			'show_in_admin_status_list' => true,
			/* translators: %s: count */
			'label_count'               => _n_noop( 'Partially Paid <span class="count">(%s)</span>', 'Partially Paid <span class="count">(%s)</span>', 'payu-payment-links-woocommerce' ),
		) );
		register_post_status( 'wc-refund-in-progress', array(
			'label'                     => _x( 'Refund In Progress', 'Order status', 'payu-payment-links-woocommerce' ),
			'public'                    => true,
			'exclude_from_search'       => false,
			'show_in_admin_all_list'    => true,
			'show_in_admin_status_list' => true,
			/* translators: %s: count */
			'label_count'               => _n_noop( 'Refund In Progress <span class="count">(%s)</span>', 'Refund In Progress <span class="count">(%s)</span>', 'payu-payment-links-woocommerce' ),
		) );
		add_filter( 'wc_order_statuses', array( $this, 'add_custom_order_statuses_to_list' ) );
	}

	public function add_custom_order_statuses_to_list( $statuses ) {
		$statuses['wc-partial-refund']      = _x( 'Partially Refunded', 'Order status', 'payu-payment-links-woocommerce' );
		$statuses['wc-partially-paid']      = _x( 'Partially Paid', 'Order status', 'payu-payment-links-woocommerce' );
		$statuses['wc-refund-in-progress']  = _x( 'Refund In Progress', 'Order status', 'payu-payment-links-woocommerce' );
		return $statuses;
	}

	/* ---------------------------------------------------------------
	 * Sync payment link status when WooCommerce order status changes
	 * ------------------------------------------------------------- */

	public function sync_payment_link_on_order_status_change( $order_id, $old_status, $new_status, $order ) {
		// Only do local status mirroring in no-key/salt mode (no PayU refund APIs available).
		if ( in_array( $new_status, array( 'refunded', 'partial-refund' ), true ) && PayU_Config::is_no_key_salt_mode() ) {
			$links = PayU_DB::get_by_order( $order_id );
			foreach ( $links as $link ) {
				if ( in_array( $link->payment_status, array( 'paid', 'partially_paid', 'partially_refunded' ), true ) ) {
					PayU_DB::update( $link->id, array( 'payment_status' => 'refunded' === $new_status ? 'refunded' : 'partially_refunded' ) );
				}
			}
		}
	}

	/**
	 * When WooCommerce creates a refund, update payment link status.
	 *
	 * @param int $order_id  Order ID.
	 * @param int $refund_id Refund ID.
	 */
	public function sync_payment_link_on_refund( $order_id, $refund_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}

		$refund = wc_get_order( $refund_id );
		$refund_amount = $refund ? abs( (float) $refund->get_total() ) : 0;
		if ( $refund_amount <= 0 ) {
			$order->add_order_note( __( 'PayU refund hook triggered but skipped: refund amount is zero.', 'payu-payment-links-woocommerce' ) );
			return;
		}

		$has_key_salt = ! PayU_Config::is_no_key_salt_mode();

		$links = PayU_DB::get_by_order( $order_id );
		if ( empty( $links ) ) {
			$order->add_order_note( __( 'PayU refund hook triggered but no payment link found for this order.', 'payu-payment-links-woocommerce' ) );
			return;
		}

		$skip_reasons = array();
		$attempted    = false;
		$client       = null;
		foreach ( $links as $link ) {
			$is_refund_recoverable = (
				'refunded' === $link->payment_status
				&& empty( $link->refund_request_id )
				&& (float) ( isset( $link->refund_amount ) ? $link->refund_amount : 0 ) <= 0
			);
			if ( ! in_array( $link->payment_status, array( 'paid', 'partially_paid', 'partially_refunded' ), true ) && ! $is_refund_recoverable ) {
				$skip_reasons[] = sprintf(
					/* translators: 1: invoice number, 2: payment status */
					__( 'Invoice %1$s skipped (payment status: %2$s).', 'payu-payment-links-woocommerce' ),
					$link->invoice_number ?: '-',
					$link->payment_status ?: 'unknown'
				);
				continue;
			}

			$txn_id = ! empty( $link->payu_txn_id ) ? (string) $link->payu_txn_id : '';

			// Backfill missing txn id from PayU txns API so native Woo refund can still trigger PayU refund API.
			if ( '' === $txn_id && ! empty( $link->invoice_number ) ) {
				try {
					if ( null === $client ) {
						$client = new PayU_API_Client();
					}
					$txns   = $client->get_payment_link_transactions( $link->invoice_number, $link->currency );
					$txn_id = $this->extract_success_transaction_id( $txns );
					if ( $txn_id ) {
						PayU_DB::update( $link->id, array( 'payu_txn_id' => $txn_id ) );
					}
				} catch ( Exception $e ) {
					PayU_Error_Handler::log_exception( 'refund_txn_backfill_error', $e, array(
						'order_id'       => (int) $order_id,
						'link_id'        => (int) $link->id,
						'invoice_number' => (string) $link->invoice_number,
					) );
					// Keep graceful skip behavior below with clear note.
				}
			}

			if ( empty( $link->payu_txn_id ) ) {
				// Use freshly fetched txn id (if any) for this execution.
				$link->payu_txn_id = $txn_id;
			}
			if ( empty( $link->payu_txn_id ) ) {
				$skip_reasons[] = sprintf(
					/* translators: %s: invoice number */
					__( 'Invoice %s skipped (missing PayU transaction ID).', 'payu-payment-links-woocommerce' ),
					$link->invoice_number ?: '-'
				);
				continue;
			}

			// Call PayU Refund API when key/salt is available.
			if ( $has_key_salt ) {
				try {
					if ( null === $client ) {
						$client = new PayU_API_Client();
					}
					$result = $client->refund_transaction( $link->payu_txn_id, $refund_amount, $link->currency );
					$attempted = true;
					$request_id = isset( $result['request_id'] ) ? trim( (string) $result['request_id'] ) : '';

					if ( '' === $request_id ) {
						PayU_DB::update( $link->id, array( 'refund_status' => 'failed' ) );
						$order->add_order_note(
							__( 'PayU refund API response missing request ID. Refund status cannot be tracked; refund marked as failed.', 'payu-payment-links-woocommerce' )
						);
						break;
					}

					$already_refunded = isset( $link->refund_amount ) ? (float) $link->refund_amount : 0;
					$new_refund_total = $already_refunded + $refund_amount;

					PayU_DB::update( $link->id, array(
						'refund_amount'     => $new_refund_total,
						'refund_request_id' => $request_id,
						'refund_status'     => 'queued',
					) );

					$order->update_status(
						'refund-in-progress',
						sprintf( __( 'PayU refund initiated: %s %s. Request ID: %s', 'payu-payment-links-woocommerce' ),
							$link->currency, number_format( $refund_amount, 2 ),
							$request_id
						)
					);
				} catch ( Exception $e ) {
					PayU_Error_Handler::log_exception( 'refund_api_error', $e, array(
						'order_id'       => (int) $order_id,
						'link_id'        => (int) $link->id,
						'invoice_number' => (string) $link->invoice_number,
					) );
					PayU_DB::update( $link->id, array( 'refund_status' => 'failed' ) );
					$order->add_order_note(
						sprintf( __( 'PayU refund API failed: %s. No local refund finalization was applied.', 'payu-payment-links-woocommerce' ), $e->getMessage() )
					);
				}
			} else {
				// No key/salt: only update local status.
				$this->update_link_refund_local( $link, $refund_amount, $order );
				$order->add_order_note(
					__( 'PayU refund API not available (no Merchant Key/Salt). Refund recorded locally only. Process the actual refund via PayU Dashboard.', 'payu-payment-links-woocommerce' )
				);
				$attempted = true;
			}
			// Continue loop — process all eligible links on this order, not just the first.
		}

		if ( ! $attempted && ! empty( $skip_reasons ) ) {
			$order->add_order_note(
				sprintf(
					/* translators: %s: skip reasons */
					__( 'PayU refund API not called. %s', 'payu-payment-links-woocommerce' ),
					implode( ' ', $skip_reasons )
				)
			);
		}
	}

	/**
	 * Pick a successful transaction ID from PayU txns payload.
	 *
	 * @param array $txns Transaction rows.
	 * @return string
	 */
	private function extract_success_transaction_id( $txns ) {
		if ( empty( $txns ) || ! is_array( $txns ) ) {
			return '';
		}

		foreach ( $txns as $txn ) {
			$status = isset( $txn['status'] ) ? strtolower( (string) $txn['status'] ) : '';
			if ( ! $status && isset( $txn['transactionStatus'] ) ) {
				$status = strtolower( (string) $txn['transactionStatus'] );
			}
			if ( ! $status && isset( $txn['txnStatus'] ) ) {
				$status = strtolower( (string) $txn['txnStatus'] );
			}
			if ( ! in_array( $status, array( 'success', 'paid', 'captured', 'charged', 'settled', 'credited' ), true ) ) {
				continue;
			}

			$txn_id = isset( $txn['transactionId'] ) ? (string) $txn['transactionId'] : '';
			if ( ! $txn_id && isset( $txn['mihpayid'] ) ) {
				$txn_id = (string) $txn['mihpayid'];
			}
			if ( ! $txn_id && isset( $txn['payuId'] ) ) {
				$txn_id = (string) $txn['payuId'];
			}
			if ( ! $txn_id && isset( $txn['txnId'] ) ) {
				$txn_id = (string) $txn['txnId'];
			}
			if ( $txn_id ) {
				return $txn_id;
			}
		}

		return '';
	}

	/**
	 * Update payment link refund status locally (no PayU API call).
	 */
	private function update_link_refund_local( $link, $refund_amount, $order ) {
		$already_refunded = isset( $link->refund_amount ) ? (float) $link->refund_amount : 0;
		$new_refund_total = $already_refunded + $refund_amount;
		$is_full          = $new_refund_total >= (float) $link->amount;

		PayU_DB::update( $link->id, array(
			'refund_amount'  => $new_refund_total,
			'payment_status' => $is_full ? 'refunded' : 'partially_refunded',
		) );
	}

	/* ---------------------------------------------------------------
	 * Admin assets (HPOS-aware)
	 * ------------------------------------------------------------- */

	/**
	 * Enqueue admin CSS and JS on relevant screens.
	 *
	 * @param string $hook_suffix Current admin page.
	 */
	public function admin_assets( $hook_suffix ) {
		$load = false;

		// Legacy order edit screen.
		if ( in_array( $hook_suffix, array( 'post.php', 'post-new.php' ), true ) ) {
			$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
			if ( $screen && 'shop_order' === $screen->post_type ) {
				$load = true;
			}
		}

		// HPOS order edit screen.
		if ( ! $load ) {
			$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
			if ( $screen && 'woocommerce_page_wc-orders' === $screen->id ) {
				$load = true;
			}
		}

		// Plugin's own admin pages (list + create).
		$plugin_pages = array(
			'woocommerce_page_payu-payment-links',
			'woocommerce_page_payu-payment-links-create',
		);
		if ( in_array( $hook_suffix, $plugin_pages, true ) ) {
			$load = true;
		}

		if ( ! $load ) {
			return;
		}

		wp_enqueue_style(
			'payu-payment-links-admin',
			PAYU_PAYMENT_LINKS_PLUGIN_URL . 'assets/css/admin.css',
			array(),
			PAYU_PAYMENT_LINKS_VERSION
		);
		wp_enqueue_script(
			'payu-payment-links-admin',
			PAYU_PAYMENT_LINKS_PLUGIN_URL . 'assets/js/admin.js',
			array( 'jquery' ),
			PAYU_PAYMENT_LINKS_VERSION,
			true
		);
		wp_localize_script( 'payu-payment-links-admin', 'payuPaymentLinks', array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'payu_payment_links_admin' ),
			'i18n'    => array(
				'copied'        => __( 'Link copied to clipboard.', 'payu-payment-links-woocommerce' ),
				'error'         => __( 'Failed to copy.', 'payu-payment-links-woocommerce' ),
				'syncing'       => __( 'Syncing...', 'payu-payment-links-woocommerce' ),
				'refreshing'    => __( 'Refreshing...', 'payu-payment-links-woocommerce' ),
				'enterRecipients' => __( 'Enter email(s) or phone(s), comma-separated:', 'payu-payment-links-woocommerce' ),
			),
		) );
	}

	/* ---------------------------------------------------------------
	 * Settings
	 * ------------------------------------------------------------- */

	public function add_settings_page( $settings ) {
		$settings[] = include PAYU_PAYMENT_LINKS_PLUGIN_DIR . 'includes/class-payu-settings.php';
		return $settings;
	}

	/* ---------------------------------------------------------------
	 * Webhook
	 * ------------------------------------------------------------- */

	public function register_webhook() {
		add_filter( 'query_vars', function ( $vars ) {
			$vars[] = 'payu_payment_link_webhook';
			return $vars;
		} );
		add_action( 'template_redirect', array( PayU_Webhook_Handler::class, 'maybe_handle' ), 1 );
	}

	/* ---------------------------------------------------------------
	 * WP-Cron: UTR fetch
	 * ------------------------------------------------------------- */

	/**
	 * Register custom cron interval (5 minutes).
	 */
	public function add_cron_intervals( $schedules ) {
		$schedules['every_five_minutes'] = array(
			'interval' => 300,
			'display'  => __( 'Every 5 minutes', 'payu-payment-links-woocommerce' ),
		);
		return $schedules;
	}

	public function schedule_cron() {
		$no_key_salt = PayU_Config::is_no_key_salt_mode();

		// Transaction polling: always runs (5 min).
		if ( ! wp_next_scheduled( 'payu_payment_links_poll_txns' ) ) {
			wp_schedule_event( time(), 'every_five_minutes', 'payu_payment_links_poll_txns' );
		}

		// UTR and refund polling: only when key/salt available.
		if ( ! $no_key_salt ) {
			if ( ! wp_next_scheduled( 'payu_payment_links_fetch_utr' ) ) {
				wp_schedule_event( time(), 'daily', 'payu_payment_links_fetch_utr' );
			}
			if ( ! wp_next_scheduled( 'payu_payment_links_poll_refunds' ) ) {
				wp_schedule_event( time(), 'hourly', 'payu_payment_links_poll_refunds' );
			}
		} else {
			wp_clear_scheduled_hook( 'payu_payment_links_fetch_utr' );
			wp_clear_scheduled_hook( 'payu_payment_links_poll_refunds' );
		}
	}

	/**
	 * Cron handler: fetch UTR numbers for paid links via Settlement API.
	 */
	public function cron_fetch_utr() {
		if ( PayU_Config::is_no_key_salt_mode() ) {
			return;
		}
		$links = PayU_DB::get_paid_without_utr( 200 );
		if ( empty( $links ) ) {
			return;
		}

		// Group by currency so we call Settlement API once per currency.
		$by_currency = array();
		foreach ( $links as $link ) {
			$cur = $link->currency ?: 'INR';
			if ( ! isset( $by_currency[ $cur ] ) ) {
				$by_currency[ $cur ] = array();
			}
			$by_currency[ $cur ][] = $link;
		}

		$client = new PayU_API_Client();

		foreach ( $by_currency as $currency => $currency_links ) {
			// Determine date range from the oldest and newest link.
			$dates = array_map( function ( $l ) {
				return $l->created_at;
			}, $currency_links );
			sort( $dates );
			$date_from = gmdate( 'Y-m-d', strtotime( reset( $dates ) . ' -1 day' ) );
			$date_to   = gmdate( 'Y-m-d' );

			try {
				$settlements = $client->get_settlement_details( $date_from, $date_to, $currency );
			} catch ( Exception $e ) {
				PayU_Error_Handler::log_exception( 'utr_poll_error', $e, array(
					'currency' => (string) $currency,
				) );
				continue;
			}

			if ( ! is_array( $settlements ) ) {
				continue;
			}

			// Build a lookup: merchantTransactionId => utrNumber.
			$utr_map = array();
			foreach ( $settlements as $settlement ) {
				$utr = isset( $settlement['utrNumber'] ) ? $settlement['utrNumber'] : ( isset( $settlement['utrnumber'] ) ? $settlement['utrnumber'] : '' );
				if ( ! $utr || empty( $settlement['transaction'] ) || ! is_array( $settlement['transaction'] ) ) {
					continue;
				}
				foreach ( $settlement['transaction'] as $txn ) {
					$mtid = isset( $txn['merchantTransactionId'] ) ? $txn['merchantTransactionId'] : '';
					$puid = isset( $txn['payuId'] ) ? $txn['payuId'] : '';
					if ( $mtid ) {
						$utr_map[ $mtid ] = $utr;
					}
					if ( $puid ) {
						$utr_map[ $puid ] = $utr;
					}
				}
			}

			if ( empty( $utr_map ) ) {
				continue;
			}

			// Match UTR to local links by payu_txn_id.
			foreach ( $currency_links as $link ) {
				if ( ! $link->payu_txn_id ) {
					continue;
				}
				$utr = isset( $utr_map[ $link->payu_txn_id ] ) ? $utr_map[ $link->payu_txn_id ] : '';
				if ( $utr ) {
					PayU_DB::update( $link->id, array( 'utr_number' => sanitize_text_field( $utr ) ) );
				}
			}
		}
	}

	/* ---------------------------------------------------------------
	 * WP-Cron: Poll refund statuses
	 * ------------------------------------------------------------- */

	public function cron_poll_refunds() {
		if ( PayU_Config::is_no_key_salt_mode() ) {
			return;
		}
		$links = PayU_DB::get_pending_refunds( 100 );
		if ( empty( $links ) ) {
			return;
		}
		foreach ( $links as $link ) {
			PayU_Admin_Order::poll_refund_status( $link );
		}

		// Additional reconciliation path: on-hold PayU-linked orders via PayU-ID lookup.
		$payu_id_links = PayU_DB::get_on_hold_refund_candidates( 150 );
		if ( empty( $payu_id_links ) ) {
			return;
		}
		foreach ( $payu_id_links as $link ) {
			if ( empty( $link->order_id ) || empty( $link->payu_txn_id ) ) {
				continue;
			}
			$order = wc_get_order( (int) $link->order_id );
			if ( ! $order ) {
				continue;
			}
			$o_status = $order->get_status();
			// Poll both on-hold and the new refund-in-progress status.
			if ( ! in_array( $o_status, array( 'on-hold', 'refund-in-progress' ), true ) ) {
				continue;
			}
			PayU_Admin_Order::poll_refund_status_by_payu_id( $link, $order );
		}
	}

	/* ---------------------------------------------------------------
	 * WP-Cron: Poll transaction status (every 5 min, OAuth-based)
	 * ------------------------------------------------------------- */

	public function cron_poll_transactions() {
		$links = PayU_DB::get_active_pending_links( 50 );
		if ( empty( $links ) ) {
			return;
		}

		$client = new PayU_API_Client();

		foreach ( $links as $link ) {
			self::poll_transaction_status( $client, $link );
		}
	}

	/* ---------------------------------------------------------------
	 * WP-Cron: Deferred webhook reconciliation
	 * ------------------------------------------------------------- */

	/**
	 * Perform the PayU link reconciliation that was deferred from the webhook
	 * handler to prevent operation timeouts. Called via a scheduled single event.
	 *
	 * @param int    $link_id         DB link row ID.
	 * @param string $invoice_number  Invoice number for PayU API lookup.
	 * @param float  $webhook_amount  Raw amount from the webhook payload.
	 */
	public function cron_reconcile_webhook( $link_id, $invoice_number, $webhook_amount ) {
		$link = PayU_DB::get_by_id( (int) $link_id );
		if ( ! $link ) {
			return;
		}

		$order_id    = ! empty( $link->order_id ) ? (int) $link->order_id : 0;
		$order       = $order_id ? wc_get_order( $order_id ) : null;
		$order_total = ( $order && is_a( $order, 'WC_Order' ) )
			? (float) $order->get_total()
			: (float) $link->amount;

		$collected_amount  = (float) $webhook_amount;
		$reconcile_success = false;

		try {
			$client   = new PayU_API_Client();
			$currency = ! empty( $link->currency ) ? $link->currency : null;
			$payu     = $client->get_payment_link( (string) $invoice_number, $currency );
			$as       = isset( $payu['amountStatus'] ) ? strtoupper( (string) $payu['amountStatus'] ) : '';

			if ( 'FULLY_PAID' === $as ) {
				$collected_amount  = $order_total;
				$reconcile_success = true;
			} elseif ( 'PARTIALLY_PAID' === $as ) {
				if ( isset( $payu['totalAmountCollected'] ) && is_numeric( $payu['totalAmountCollected'] ) ) {
					$collected_amount = (float) $payu['totalAmountCollected'];
				} else {
					$txns    = $client->get_payment_link_transactions( (string) $invoice_number, $currency );
					$summary = self::summarize_payment_transactions( $txns );
					if ( ! empty( $summary['collected_amount'] ) && (float) $summary['collected_amount'] > 0 ) {
						$collected_amount = (float) $summary['collected_amount'];
					}
				}
				$reconcile_success = true;
			} elseif ( isset( $payu['totalAmountCollected'] ) && is_numeric( $payu['totalAmountCollected'] ) && (float) $payu['totalAmountCollected'] > 0 ) {
				$collected_amount  = (float) $payu['totalAmountCollected'];
				$reconcile_success = true;
			}
		} catch ( Exception $e ) {
			PayU_Error_Handler::log_exception( 'webhook_deferred_reconcile_error', $e, array(
				'link_id'        => (int) $link_id,
				'invoice_number' => (string) $invoice_number,
			) );
			// Add order note so merchants can see reconciliation failed and act.
			if ( $order && is_a( $order, 'WC_Order' ) ) {
				$order->add_order_note(
					sprintf( __( 'PayU payment reconciliation failed (deferred). Error: %s. Payment status not updated automatically — use the Refresh button to retry.', 'payu-payment-links-woocommerce' ), $e->getMessage() )
				);
			}
			// Do not update payment status using potentially incorrect raw webhook amount.
			return;
		}

		if ( ! $reconcile_success ) {
			// No authoritative data from PayU — do not update status.
			return;
		}

		$outcome = self::resolve_payment_outcome( $order_total, $collected_amount, true );
		$extra   = array();
		if ( $collected_amount > 0 ) {
			$extra['paid_amount'] = round( $collected_amount, 2 );
		}

		$note = 'paid' === $outcome['payment_status']
			? __( 'PayU payment confirmed (deferred reconciliation).', 'payu-payment-links-woocommerce' )
			: sprintf( __( 'PayU partial payment confirmed (deferred reconciliation). Collected: %1$s of %2$s.', 'payu-payment-links-woocommerce' ), number_format( $collected_amount, 2 ), number_format( $order_total, 2 ) );

		self::transition_payment_status( (int) $link_id, $outcome['payment_status'], $extra, $note );
	}

	/**
	 * Formerly ran opportunistic polling on order screens. Removed to prevent
	 * side-effect writes on page load. Status updates now come exclusively
	 * from cron, webhooks, or explicit user "Refresh" clicks.
	 *
	 * @param WP_Screen $screen Current admin screen.
	 */
	public function maybe_sync_transactions_on_order_screens( $screen ) {
		// Intentionally empty — status writes are event-driven only.
	}

	/**
	 * Poll PayU for transaction status on a single link and update DB + order.
	 *
	 * @param PayU_API_Client $client API client.
	 * @param object          $link   DB row.
	 */
	public static function poll_transaction_status( $client, $link ) {
		try {
			$txns = $client->get_payment_link_transactions( $link->invoice_number );
		} catch ( Exception $e ) {
			PayU_Error_Handler::log_exception( 'txn_poll_error', $e, array(
				'link_id'        => isset( $link->id ) ? (int) $link->id : 0,
				'invoice_number' => isset( $link->invoice_number ) ? (string) $link->invoice_number : '',
			) );
			if ( ! empty( $link->order_id ) ) {
				$note_order = wc_get_order( (int) $link->order_id );
				if ( $note_order ) {
					$note_order->add_order_note(
						sprintf( __( 'PayU transaction status poll failed for link %s: %s', 'payu-payment-links-woocommerce' ), $link->invoice_number, $e->getMessage() )
					);
				}
			}
			return;
		}

		if ( empty( $txns ) ) {
			return;
		}

		$summary        = self::summarize_payment_transactions( $txns );
		$success_txn_id = $summary['success_txn_id'];
		$failed_txn_id  = $summary['failed_txn_id'];

		// Prefer success if both failed and successful attempts exist on the same link.
		if ( $success_txn_id ) {
			$order_total = self::get_order_total_for_link( $link );
			$collected   = (float) $summary['collected_amount'];

			// Reconcile with latest link snapshot for accurate partial/full classification.
			$collected = self::reconcile_collected_from_payu( $client, $link, $order_total, $collected );

			$outcome = self::resolve_payment_outcome( $order_total, $collected, true );

			$note = 'paid' === $outcome['payment_status']
				? sprintf( __( 'PayU payment confirmed (polled). Transaction ID: %s', 'payu-payment-links-woocommerce' ), $success_txn_id )
				: sprintf( __( 'PayU partial payment confirmed (polled). Collected: %1$s of %2$s. Transaction ID: %3$s', 'payu-payment-links-woocommerce' ), number_format( $collected, 2 ), number_format( $order_total, 2 ), $success_txn_id );

			self::transition_payment_status(
				(int) $link->id,
				$outcome['payment_status'],
				array(
					'payu_txn_id' => $success_txn_id,
					'paid_amount' => round( $collected, 2 ),
				),
				$note
			);
			return;
		}

		if ( $failed_txn_id ) {
			self::transition_payment_status(
				(int) $link->id,
				'failed',
				array( 'payu_txn_id' => $failed_txn_id ),
				sprintf( __( 'PayU payment failed (polled). Transaction ID: %s', 'payu-payment-links-woocommerce' ), $failed_txn_id )
			);
		}
	}

	/**
	 * Fetch authoritative collected amount from PayU link snapshot.
	 *
	 * @param PayU_API_Client $client      API client.
	 * @param object          $link        DB link row.
	 * @param float           $order_total Order total for comparison.
	 * @param float           $fallback    Fallback collected amount from txn rows.
	 * @return float
	 */
	public static function reconcile_collected_from_payu( $client, $link, $order_total, $fallback = 0.0 ) {
		try {
			$payu = $client->get_payment_link( $link->invoice_number, isset( $link->currency ) ? $link->currency : null );
			$as   = isset( $payu['amountStatus'] ) ? strtoupper( (string) $payu['amountStatus'] ) : '';
			if ( 'FULLY_PAID' === $as ) {
				return (float) $order_total;
			}
			if ( 'PARTIALLY_PAID' === $as ) {
				if ( isset( $payu['totalAmountCollected'] ) && is_numeric( $payu['totalAmountCollected'] ) ) {
					return (float) $payu['totalAmountCollected'];
				}
			}
			if ( isset( $payu['totalAmountCollected'] ) && is_numeric( $payu['totalAmountCollected'] ) && (float) $payu['totalAmountCollected'] > 0 ) {
				return (float) $payu['totalAmountCollected'];
			}
		} catch ( Exception $e ) {
			PayU_Error_Handler::log_exception( 'reconcile_collected_error', $e, array(
				'link_id'        => isset( $link->id ) ? (int) $link->id : 0,
				'invoice_number' => isset( $link->invoice_number ) ? (string) $link->invoice_number : '',
			) );
		}
		return (float) $fallback;
	}

	/* ---------------------------------------------------------------
	 * Strict payment status state machine
	 * ------------------------------------------------------------- */

	/**
	 * Allowed forward transitions for payment_status.
	 * Key = current status, Value = array of allowed next statuses.
	 */
	private static $payment_status_transitions = array(
		'pending'              => array( 'partially_paid', 'paid', 'failed' ),
		'failed'               => array( 'pending', 'partially_paid', 'paid' ),
		'partially_paid'       => array( 'partially_paid', 'paid' ),
		'paid'                 => array( 'partially_refunded', 'refunded' ),
		'partially_refunded'   => array( 'refunded' ),
		'refunded'             => array(),
	);

	/**
	 * Attempt to transition a link's payment_status. Only writes if the
	 * transition is allowed by the state machine. Also syncs order status.
	 *
	 * @param int         $link_id       Link row ID.
	 * @param string      $new_status    Desired payment_status.
	 * @param array       $extra_updates Additional DB columns to write (e.g. payu_txn_id).
	 * @param string|null $order_note    Optional note to add to the linked order.
	 * @return bool Whether the transition was applied.
	 */
	public static function transition_payment_status( $link_id, $new_status, array $extra_updates = array(), $order_note = null ) {
		$link = PayU_DB::get_by_id( $link_id );
		if ( ! $link ) {
			return false;
		}

		$current = isset( $link->payment_status ) ? (string) $link->payment_status : 'pending';
		$new_status = (string) $new_status;

		if ( $current === $new_status && empty( $extra_updates ) ) {
			return false;
		}

		$allowed = isset( self::$payment_status_transitions[ $current ] ) ? self::$payment_status_transitions[ $current ] : array();

		if ( $current !== $new_status && ! in_array( $new_status, $allowed, true ) ) {
			return false;
		}

		$db_data = array_merge( $extra_updates, array( 'payment_status' => $new_status ) );

		// Increment failure_count when transitioning to failed; check cap.
		if ( 'failed' === $new_status && 'failed' !== $current ) {
			$current_count = isset( $link->failure_count ) ? (int) $link->failure_count : 0;
			$new_count     = $current_count + 1;
			$db_data['failure_count'] = $new_count;
			$max_fails = (int) apply_filters( 'payu_payment_links_max_failure_count', PayU_DB::MAX_FAILURE_COUNT );

			if ( $new_count >= $max_fails ) {
				// Auto-expire the link on PayU; only mark locally expired if PayU succeeds.
				$payu_expired = false;
				try {
					$client = new PayU_API_Client();
					$client->expire_payment_link( $link->invoice_number, isset( $link->currency ) ? $link->currency : null );
					$payu_expired      = true;
					$db_data['status'] = 'expired';
				} catch ( Exception $e ) {
					PayU_Error_Handler::log_exception( 'auto_expire_at_failure_cap_error', $e, array(
						'link_id'        => (int) $link->id,
						'invoice_number' => (string) $link->invoice_number,
						'failure_count'  => $new_count,
					) );
				}
				if ( ! empty( $link->order_id ) ) {
					$cap_order = wc_get_order( (int) $link->order_id );
					if ( $cap_order ) {
						if ( $payu_expired ) {
							$cap_order->add_order_note(
								sprintf(
									__( 'PayU payment link auto-expired after %d failed attempts: %s', 'payu-payment-links-woocommerce' ),
									$new_count,
									$link->invoice_number
								)
							);
						} else {
							$cap_order->add_order_note(
								sprintf(
									__( 'PayU payment link reached max failure limit (%d attempts) but could not be auto-expired on PayU. Please expire it manually from the PayU Dashboard: %s', 'payu-payment-links-woocommerce' ),
									$new_count,
									$link->invoice_number
								)
							);
						}
					}
				}
			}
		}

		PayU_DB::update( $link->id, $db_data );

		if ( ! empty( $link->order_id ) ) {
			$paid_amount = isset( $db_data['paid_amount'] ) ? (float) $db_data['paid_amount'] : ( isset( $link->paid_amount ) ? (float) $link->paid_amount : 0.0 );
			self::sync_order_status_from_link( (int) $link->order_id, $new_status, $order_note, $paid_amount );
		}

		return true;
	}

	/**
	 * Map link payment_status to the appropriate WooCommerce order status.
	 *
	 * @param int         $order_id    WooCommerce order ID.
	 * @param string      $link_status The link's payment_status after transition.
	 * @param string|null $note        Optional order note.
	 * @param float       $paid_amount Collected amount to persist on the order.
	 */
	private static function sync_order_status_from_link( $order_id, $link_status, $note = null, $paid_amount = 0.0 ) {
		$order = wc_get_order( $order_id );
		if ( ! $order || ! is_a( $order, 'WC_Order' ) ) {
			return;
		}

		$current = $order->get_status();
		if ( self::is_protected_order_status( $current ) ) {
			return;
		}

		switch ( $link_status ) {
			case 'paid':
				self::sync_order_paid_amount_meta( $order, (float) $order->get_total() );
				if ( ! $order->is_paid() ) {
					$target = PayU_Config::order_status_on_payment();
					if ( 'completed' === $target ) {
						$order->update_status( 'completed', $note ?: __( 'PayU payment confirmed.', 'payu-payment-links-woocommerce' ) );
					} else {
						$order->payment_complete();
						if ( $note ) {
							$order->add_order_note( $note );
						}
					}
				}
				break;

			case 'partially_paid':
				if ( (float) $paid_amount > 0 ) {
					self::sync_order_paid_amount_meta( $order, (float) $paid_amount );
				}
				if ( 'partially-paid' !== $current ) {
					$order->update_status( 'partially-paid', $note ?: __( 'PayU partial payment confirmed.', 'payu-payment-links-woocommerce' ) );
				}
				break;

			case 'failed':
				if ( ! $order->is_paid() && 'partially-paid' !== $current ) {
					$order->update_status( 'failed', $note ?: __( 'PayU payment failed.', 'payu-payment-links-woocommerce' ) );
				}
				break;
		}
	}

	/**
	 * Persist collected amount against WooCommerce order for visibility/audit.
	 *
	 * @param WC_Order $order       Order object.
	 * @param float    $paid_amount Amount collected so far.
	 */
	private static function sync_order_paid_amount_meta( $order, $paid_amount ) {
		$normalized = max( 0.0, round( (float) $paid_amount, 2 ) );
		$current    = (float) $order->get_meta( '_payu_paid_amount', true );

		if ( abs( $current - $normalized ) < 0.01 ) {
			return;
		}

		$order->update_meta_data( '_payu_paid_amount', sprintf( '%.2f', $normalized ) );
		$order->save();
	}

	/**
	 * Resolve payment status from collected amount vs order amount.
	 *
	 * @param float $order_total      Order total amount.
	 * @param float $collected_amount Collected amount from PayU.
	 * @param bool  $has_success      Whether a successful transaction exists.
	 * @return array{payment_status:string,is_full:bool,is_partial:bool}
	 */
	public static function resolve_payment_outcome( $order_total, $collected_amount, $has_success = false ) {
		$order_total      = max( 0.0, (float) $order_total );
		$collected_amount = max( 0.0, (float) $collected_amount );
		$tolerance        = 0.01;

		$is_full    = $order_total > 0 && $collected_amount + $tolerance >= $order_total;
		$is_partial = $collected_amount > $tolerance && ! $is_full;

		if ( $is_full ) {
			$payment_status = 'paid';
		} elseif ( $is_partial ) {
			$payment_status = 'partially_paid';
		} elseif ( $has_success && $collected_amount <= $tolerance ) {
			// PayU reported success but collected amount is unknown / zero.
			// Treat as paid (full) so the order is not left in pending limbo.
			$is_full        = true;
			$payment_status = 'paid';
		} else {
			$payment_status = 'pending';
		}

		return array(
			'payment_status' => $payment_status,
			'is_full'        => $is_full,
			'is_partial'     => $is_partial,
		);
	}

	/**
	 * Summarize transaction rows into state needed by order reconciliation.
	 *
	 * @param array $txns Raw transaction rows.
	 * @return array{success_txn_id:string,failed_txn_id:string,collected_amount:float,has_success:bool}
	 */
	public static function summarize_payment_transactions( $txns ) {
		$success_txn_id   = '';
		$failed_txn_id    = '';
		$collected_amount = 0.0;
		$has_success      = false;

		foreach ( $txns as $txn ) {
			if ( ! is_array( $txn ) ) {
				continue;
			}

			$txn_status = self::extract_transaction_status( $txn );
			$txn_id     = self::extract_transaction_id( $txn );

			if ( in_array( $txn_status, array( 'success', 'paid', 'captured', 'charged', 'settled', 'credited' ), true ) ) {
				$has_success      = true;
				$success_txn_id   = $txn_id ? $txn_id : $success_txn_id;
				$collected_amount += self::extract_transaction_amount( $txn );
				continue;
			}

			if ( in_array( $txn_status, array( 'failure', 'failed', 'declined', 'cancelled', 'canceled' ), true ) ) {
				$failed_txn_id = $txn_id ? $txn_id : $failed_txn_id;
			}
		}

		return array(
			'success_txn_id'   => $success_txn_id,
			'failed_txn_id'    => $failed_txn_id,
			'collected_amount' => round( $collected_amount, 2 ),
			'has_success'      => $has_success,
		);
	}

	/**
	 * Resolve the comparison amount for a link, preferring Woo order total.
	 *
	 * @param object $link Link DB row.
	 * @return float
	 */
	private static function get_order_total_for_link( $link ) {
		if ( ! empty( $link->order_id ) ) {
			$order = wc_get_order( (int) $link->order_id );
			if ( $order && is_a( $order, 'WC_Order' ) ) {
				return (float) $order->get_total();
			}
		}
		return isset( $link->amount ) ? (float) $link->amount : 0.0;
	}

	/**
	 * Extract normalized transaction status from a PayU transaction row.
	 *
	 * @param array $txn PayU transaction row.
	 * @return string
	 */
	private static function extract_transaction_status( $txn ) {
		$txn_status = isset( $txn['status'] ) ? strtolower( (string) $txn['status'] ) : '';
		if ( ! $txn_status && isset( $txn['transactionStatus'] ) ) {
			$txn_status = strtolower( (string) $txn['transactionStatus'] );
		}
		if ( ! $txn_status && isset( $txn['txnStatus'] ) ) {
			$txn_status = strtolower( (string) $txn['txnStatus'] );
		}
		if ( ! $txn_status && isset( $txn['paymentStatus'] ) ) {
			$txn_status = strtolower( (string) $txn['paymentStatus'] );
		}
		return $txn_status;
	}

	/**
	 * Extract canonical transaction ID from a PayU transaction row.
	 *
	 * @param array $txn PayU transaction row.
	 * @return string
	 */
	private static function extract_transaction_id( $txn ) {
		$txn_id = isset( $txn['transactionId'] ) ? (string) $txn['transactionId'] : '';
		if ( ! $txn_id && isset( $txn['mihpayid'] ) ) {
			$txn_id = (string) $txn['mihpayid'];
		}
		if ( ! $txn_id && isset( $txn['payuId'] ) ) {
			$txn_id = (string) $txn['payuId'];
		}
		if ( ! $txn_id && isset( $txn['txnId'] ) ) {
			$txn_id = (string) $txn['txnId'];
		}
		return trim( $txn_id );
	}

	/**
	 * Extract transaction amount from a PayU transaction row.
	 *
	 * @param array $txn PayU transaction row.
	 * @return float
	 */
	private static function extract_transaction_amount( $txn ) {
		$keys = array( 'amount', 'txnAmount', 'transactionAmount', 'paidAmount', 'netAmount', 'value', 'totalAmountCollected', 'collectedAmount', 'subAmount', 'amountPaid', 'totalPaidAmount' );
		foreach ( $keys as $key ) {
			if ( isset( $txn[ $key ] ) && is_numeric( $txn[ $key ] ) ) {
				return max( 0.0, (float) $txn[ $key ] );
			}
		}
		return 0.0;
	}

	/**
	 * Guard statuses where payment callbacks must not alter order state.
	 *
	 * @param string $status Woo order status.
	 * @return bool
	 */
	private static function is_protected_order_status( $status ) {
		return in_array( $status, array( 'refunded', 'partial-refund' ), true );
	}

	/**
	 * Check if order already has a successful/refund payment link state.
	 *
	 * @param int $order_id          Woo order ID.
	 * @param int $exclude_link_id   Optional link ID to exclude from lookup.
	 * @return bool
	 */
	private static function order_has_paid_link( $order_id, $exclude_link_id = 0 ) {
		$links = PayU_DB::get_by_order( $order_id );
		if ( empty( $links ) ) {
			return false;
		}
		foreach ( $links as $sibling ) {
			if ( $exclude_link_id && (int) $sibling->id === (int) $exclude_link_id ) {
				continue;
			}
			$sibling_payment_status = isset( $sibling->payment_status ) ? (string) $sibling->payment_status : '';
			if ( in_array( $sibling_payment_status, array( 'paid', 'partially_paid', 'partially_refunded', 'refunded' ), true ) ) {
				return true;
			}
		}
		return false;
	}
}
