<?php
/**
 * Database helper: custom table for payment links.
 *
 * @package PayU_Payment_Links_WooCommerce
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class PayU_DB
 */
class PayU_DB {

	const DB_VERSION = '1.8.0';

	/** Default maximum allowed failed payment attempts before a link is auto-expired. */
	const MAX_FAILURE_COUNT = 5;

	/**
	 * Get the full table name (with WP prefix).
	 *
	 * @return string
	 */
	public static function get_table_name() {
		global $wpdb;
		return $wpdb->prefix . 'payu_payment_links';
	}

	/**
	 * Get event log table name.
	 *
	 * @return string
	 */
	public static function get_events_table_name() {
		global $wpdb;
		return $wpdb->prefix . 'payu_payment_link_events';
	}

	/**
	 * Create or upgrade the custom table via dbDelta.
	 */
	public static function create_table() {
		global $wpdb;
		$table           = self::get_table_name();
		$events_table    = self::get_events_table_name();
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			order_id BIGINT UNSIGNED DEFAULT NULL,
			invoice_number VARCHAR(100) NOT NULL DEFAULT '',
			payment_link_url TEXT NOT NULL,
			amount DECIMAL(12,2) NOT NULL DEFAULT 0,
			currency VARCHAR(10) NOT NULL DEFAULT 'INR',
			status VARCHAR(30) NOT NULL DEFAULT 'active',
			payment_status VARCHAR(30) NOT NULL DEFAULT 'pending',
			description TEXT DEFAULT NULL,
			expiry_date DATETIME DEFAULT NULL,
			created_at DATETIME NOT NULL,
			udf1 VARCHAR(255) DEFAULT NULL,
			udf5 VARCHAR(255) DEFAULT NULL,
			customer_email VARCHAR(255) DEFAULT NULL,
			customer_phone VARCHAR(50) DEFAULT NULL,
			customer_name VARCHAR(255) DEFAULT NULL,
			payu_txn_id VARCHAR(100) DEFAULT NULL,
			paid_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
			failure_count TINYINT UNSIGNED NOT NULL DEFAULT 0,
			utr_number VARCHAR(100) DEFAULT NULL,
			refund_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
			refund_request_id VARCHAR(100) DEFAULT NULL,
			refund_status VARCHAR(30) DEFAULT NULL,
			last_shared_to TEXT DEFAULT NULL,
			last_shared_at DATETIME DEFAULT NULL,
			PRIMARY KEY  (id),
			KEY idx_order_id (order_id),
			KEY idx_invoice_number (invoice_number),
			KEY idx_status (status),
			KEY idx_created_at (created_at),
			KEY idx_currency (currency)
		) {$charset_collate};";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );
		$events_sql = "CREATE TABLE {$events_table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			event_type VARCHAR(40) NOT NULL DEFAULT '',
			direction VARCHAR(10) NOT NULL DEFAULT '',
			endpoint TEXT DEFAULT NULL,
			order_id BIGINT UNSIGNED DEFAULT NULL,
			link_id BIGINT UNSIGNED DEFAULT NULL,
			invoice_number VARCHAR(100) DEFAULT NULL,
			request_id VARCHAR(100) DEFAULT NULL,
			http_code INT DEFAULT NULL,
			status VARCHAR(30) DEFAULT NULL,
			request_payload LONGTEXT DEFAULT NULL,
			response_payload LONGTEXT DEFAULT NULL,
			error_message TEXT DEFAULT NULL,
			context_payload LONGTEXT DEFAULT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY idx_event_type (event_type),
			KEY idx_direction (direction),
			KEY idx_order_id (order_id),
			KEY idx_link_id (link_id),
			KEY idx_invoice_number (invoice_number),
			KEY idx_created_at (created_at)
		) {$charset_collate};";
		dbDelta( $events_sql );

		update_option( 'payu_payment_links_db_version', self::DB_VERSION );
	}

	/**
	 * Check DB version and upgrade if needed (safe to call on every load).
	 */
	public static function maybe_upgrade() {
		$installed = get_option( 'payu_payment_links_db_version', '' );
		if ( $installed !== self::DB_VERSION ) {
			self::create_table();
		}
	}

	/**
	 * Drop the custom table (used on uninstall).
	 */
	public static function drop_table() {
		global $wpdb;
		$table = self::get_table_name();
		$events_table = self::get_events_table_name();
		$wpdb->query( "DROP TABLE IF EXISTS {$table}" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( "DROP TABLE IF EXISTS {$events_table}" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/**
	 * Persist an integration event row for observability/audit.
	 *
	 * @param array $data Event payload.
	 * @return int|false
	 */
	public static function log_event( array $data ) {
		global $wpdb;
		if ( ! is_object( $wpdb ) || ! method_exists( $wpdb, 'insert' ) ) {
			return false;
		}
		$defaults = array(
			'event_type'       => '',
			'direction'        => '',
			'endpoint'         => null,
			'order_id'         => null,
			'link_id'          => null,
			'invoice_number'   => null,
			'request_id'       => null,
			'http_code'        => null,
			'status'           => null,
			'request_payload'  => null,
			'response_payload' => null,
			'error_message'    => null,
			'context_payload'  => null,
			'created_at'       => current_time( 'mysql', true ),
		);
		$row = array_intersect_key( array_merge( $defaults, $data ), $defaults );

		$fields_to_cap = array(
			'event_type'       => 40,   // VARCHAR(40).
			'direction'        => 10,   // VARCHAR(10).
			'endpoint'         => 2000,
			'invoice_number'   => 100,
			'request_id'       => 100,
			'status'           => 30,
			'error_message'    => 2000,
			'request_payload'  => 30000,
			'response_payload' => 30000,
			'context_payload'  => 30000,
		);
		foreach ( $fields_to_cap as $field => $limit ) {
			if ( isset( $row[ $field ] ) && null !== $row[ $field ] ) {
				$row[ $field ] = substr( (string) $row[ $field ], 0, $limit );
			}
		}

		$result = $wpdb->insert( self::get_events_table_name(), $row );
		if ( false === $result ) {
			return false;
		}
		return (int) $wpdb->insert_id;
	}

	/**
	 * Insert a payment link row.
	 *
	 * @param array $data Column => value pairs.
	 * @return int|false Inserted row ID or false on failure.
	 */
	public static function insert( array $data ) {
		global $wpdb;
		$defaults = array(
			'order_id'         => null,
			'invoice_number'   => '',
			'payment_link_url' => '',
			'amount'           => 0,
			'currency'         => 'INR',
			'status'           => 'active',
			'payment_status'   => 'pending',
			'description'      => null,
			'expiry_date'      => null,
			'created_at'       => current_time( 'mysql', true ),
			'udf1'             => null,
			'udf5'             => null,
			'customer_email'   => null,
			'customer_phone'   => null,
			'customer_name'    => null,
			'payu_txn_id'      => null,
			'paid_amount'      => 0,
			'failure_count'    => 0,
			'utr_number'       => null,
			'refund_amount'    => 0,
			'refund_request_id' => null,
			'refund_status'    => null,
			'last_shared_to'   => null,
			'last_shared_at'   => null,
		);
		$data   = array_intersect_key( array_merge( $defaults, $data ), $defaults );
		$result = $wpdb->insert( self::get_table_name(), $data );
		if ( false === $result ) {
			return false;
		}
		return (int) $wpdb->insert_id;
	}

	/**
	 * Update a payment link row by ID.
	 *
	 * @param int   $id   Row ID.
	 * @param array $data Column => value pairs to update.
	 * @return bool
	 */
	public static function update( $id, array $data ) {
		global $wpdb;
		$allowed = array(
			'order_id', 'invoice_number', 'payment_link_url', 'amount',
			'currency', 'status', 'payment_status', 'description', 'expiry_date',
			'udf1', 'udf5', 'customer_email', 'customer_phone',
			'customer_name', 'payu_txn_id', 'paid_amount', 'failure_count', 'utr_number',
			'refund_amount', 'refund_request_id', 'refund_status',
			'last_shared_to', 'last_shared_at',
		);
		$data = array_intersect_key( $data, array_flip( $allowed ) );
		if ( empty( $data ) ) {
			return false;
		}
		$result = $wpdb->update( self::get_table_name(), $data, array( 'id' => (int) $id ) );
		return false !== $result;
	}

	/**
	 * Get a single row by ID.
	 *
	 * @param int $id Row ID.
	 * @return object|null
	 */
	public static function get_by_id( $id ) {
		global $wpdb;
		$table = self::get_table_name();
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/**
	 * Get a single row by invoice number.
	 *
	 * @param string $invoice_number PayU invoice number.
	 * @return object|null
	 */
	public static function get_by_invoice( $invoice_number ) {
		global $wpdb;
		$table = self::get_table_name();
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE invoice_number = %s LIMIT 1", $invoice_number ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/**
	 * Get all payment links for an order.
	 *
	 * @param int $order_id WooCommerce order ID.
	 * @return array Array of row objects.
	 */
	public static function get_by_order( $order_id ) {
		global $wpdb;
		$table = self::get_table_name();
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE order_id = %d ORDER BY created_at DESC", $order_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/**
	 * Query payment links for a date range with optional filters.
	 *
	 * @param string      $from_date  MySQL datetime (UTC).
	 * @param string      $to_date    MySQL datetime (UTC).
	 * @param array       $args       Optional: status, currency, limit, offset.
	 * @return array Array of row objects.
	 */
	public static function get_for_date_range( $from_date, $to_date, $args = array() ) {
		global $wpdb;
		$table  = self::get_table_name();
		$where  = array( $wpdb->prepare( 'created_at BETWEEN %s AND %s', $from_date, $to_date ) );
		$params = array();

		if ( ! empty( $args['status'] ) ) {
			$where[] = $wpdb->prepare( 'status = %s', $args['status'] );
		}
		if ( ! empty( $args['currency'] ) ) {
			$where[] = $wpdb->prepare( 'currency = %s', $args['currency'] );
		}

		$where_clause = implode( ' AND ', $where );
		$limit        = isset( $args['limit'] ) ? absint( $args['limit'] ) : 500;
		$offset       = isset( $args['offset'] ) ? absint( $args['offset'] ) : 0;

		return $wpdb->get_results( // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			"SELECT * FROM {$table} WHERE {$where_clause} ORDER BY created_at DESC LIMIT {$limit} OFFSET {$offset}"
		);
	}

	/**
	 * Get paid links that do not yet have a UTR number (for cron processing).
	 *
	 * @param int $limit Max rows to return.
	 * @return array Array of row objects.
	 */
	public static function get_paid_without_utr( $limit = 200 ) {
		global $wpdb;
		$table = self::get_table_name();
		return $wpdb->get_results( $wpdb->prepare( // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			"SELECT * FROM {$table} WHERE payment_status = 'paid' AND ( utr_number IS NULL OR utr_number = '' ) AND payu_txn_id IS NOT NULL AND payu_txn_id != '' ORDER BY created_at DESC LIMIT %d",
			$limit
		) );
	}

	/**
	 * Find a link row by PayU transaction ID.
	 *
	 * @param string $txn_id PayU transaction ID.
	 * @return object|null
	 */
	public static function get_by_txn_id( $txn_id ) {
		global $wpdb;
		$table = self::get_table_name();
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE payu_txn_id = %s LIMIT 1", $txn_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/**
	 * Count links matching filters (for pagination).
	 *
	 * @param string $from_date MySQL datetime.
	 * @param string $to_date   MySQL datetime.
	 * @param array  $args      Optional: status, currency.
	 * @return int
	 */
	public static function count_for_date_range( $from_date, $to_date, $args = array() ) {
		global $wpdb;
		$table  = self::get_table_name();
		$where  = array( $wpdb->prepare( 'created_at BETWEEN %s AND %s', $from_date, $to_date ) );

		if ( ! empty( $args['status'] ) ) {
			$where[] = $wpdb->prepare( 'status = %s', $args['status'] );
		}
		if ( ! empty( $args['currency'] ) ) {
			$where[] = $wpdb->prepare( 'currency = %s', $args['currency'] );
		}

		$where_clause = implode( ' AND ', $where );
		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE {$where_clause}" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}

	/**
	 * Get links with pending refunds (refund initiated but not yet final).
	 *
	 * @param int $limit Max rows.
	 * @return array
	 */
	public static function get_pending_refunds( $limit = 200 ) {
		global $wpdb;
		$table = self::get_table_name();
		return $wpdb->get_results( $wpdb->prepare( // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			"SELECT * FROM {$table} WHERE refund_request_id IS NOT NULL AND refund_request_id != '' AND ( refund_status IS NULL OR refund_status IN ('queued','in_progress','requested','pending','od_hit') ) ORDER BY created_at DESC LIMIT %d",
			$limit
		) );
	}

	/**
	 * Get PayU-linked refund candidates for on-hold order reconciliation via PayU ID API.
	 *
	 * @param int $limit Max rows.
	 * @return array
	 */
	public static function get_on_hold_refund_candidates( $limit = 200 ) {
		global $wpdb;
		$table = self::get_table_name();
		return $wpdb->get_results( $wpdb->prepare( // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			"SELECT * FROM {$table}
			 WHERE order_id IS NOT NULL
			   AND payu_txn_id IS NOT NULL
			   AND payu_txn_id != ''
			   AND payment_status IN ('paid','partially_paid','partially_refunded','refunded')
			 ORDER BY created_at DESC
			 LIMIT %d",
			$limit
		) );
	}

	/**
	 * Get links that need transaction polling (payment pending, link active or expired).
	 *
	 * @param int $limit Max rows.
	 * @return array
	 */
	public static function get_active_pending_links( $limit = 100 ) {
		global $wpdb;
		$table     = self::get_table_name();
		$max_fails = (int) apply_filters( 'payu_payment_links_max_failure_count', self::MAX_FAILURE_COUNT );
		return $wpdb->get_results( $wpdb->prepare( // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			"SELECT * FROM {$table} WHERE payment_status IN ('pending','failed','partially_paid') AND status IN ('active','expired') AND invoice_number != '' AND failure_count < %d ORDER BY created_at DESC LIMIT %d",
			$max_fails,
			$limit
		) );
	}
}
