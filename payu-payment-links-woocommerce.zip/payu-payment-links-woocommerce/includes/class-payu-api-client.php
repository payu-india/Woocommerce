<?php
/**
 * PayU API client: OAuth tokens, Payment Link CRUD, Share, and Settlement APIs.
 *
 * @package PayU_Payment_Links_WooCommerce
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class PayU_API_Client
 */
class PayU_API_Client {

	const TOKEN_URL_UAT  = 'https://uat-accounts.payu.in/oauth/token';
	const TOKEN_URL_PROD = 'https://accounts.payu.in/oauth/token';

	const PAYMENT_LINKS_URL_UAT  = 'https://uatoneapi.payu.in/payment-links';
	const PAYMENT_LINKS_URL_PROD = 'https://oneapi.payu.in/payment-links';

	const SETTLEMENT_URL_UAT  = 'https://test.payu.in/merchant/postservice?form=2';
	const SETTLEMENT_URL_PROD = 'https://info.payu.in/merchant/postservice?form=2';

	const SCOPE       = 'create_payment_links read_payment_links update_payment_links';
	const UDF5_SOURCE = 'WooCommerce_paymentlink';
	const MAX_RETRIES = 2;

	/* ---------------------------------------------------------------
	 * Credentials
	 * ------------------------------------------------------------- */

	/**
	 * Get full credentials for a currency (from multi-currency config or legacy single config).
	 *
	 * @param string|null $currency Currency code (e.g. INR, USD). Null = first available.
	 * @return array{currency:string, merchant_id:string, client_id:string, client_secret:string, merchant_key:string, salt:string}
	 * @throws Exception When no credentials found.
	 */
	public function get_credentials_for_currency( $currency = null ) {
		$creds = PayU_Config::credentials();
		$mid   = $creds['merchant_id'];
		$cid   = $creds['client_id'];
		$sec   = $creds['client_secret'];

		if ( $mid && $cid && $sec ) {
			return $creds;
		}

		throw new PayU_Configuration_Exception(
			__( 'PayU credentials not configured. Go to WooCommerce → Settings → PayU Payment Links.', 'payu-payment-links-woocommerce' ),
			0,
			array( 'currency' => $currency ? (string) $currency : 'INR' )
		);
	}

	/* ---------------------------------------------------------------
	 * OAuth Token
	 * ------------------------------------------------------------- */

	/**
	 * Get OAuth token (cached in transients) for the given currency.
	 *
	 * @param string|null $currency Currency code.
	 * @return string Access token.
	 * @throws Exception When token request fails.
	 */
	public function get_token( $currency = null ) {
		$creds     = $this->get_credentials_for_currency( $currency );
		$env       = PayU_Config::env();
		$cache_key = 'payu_payment_links_token_' . $env . '_' . $creds['currency'] . '_' . md5( $creds['client_id'] );
		$cached    = get_transient( $cache_key );

		if ( is_array( $cached ) && ! empty( $cached['access_token'] ) && ! empty( $cached['expires_at'] ) && $cached['expires_at'] > ( time() + 300 ) ) {
			return $cached['access_token'];
		}

		$url      = 'test' === $env ? self::TOKEN_URL_UAT : self::TOKEN_URL_PROD;
		$body = $this->request_json(
			'token',
			'POST',
			$url,
			array(
				'headers' => array( 'Content-Type' => 'application/x-www-form-urlencoded' ),
				'body'    => http_build_query( array(
					'client_id'     => $creds['client_id'],
					'client_secret' => $creds['client_secret'],
					'grant_type'    => 'client_credentials',
					'scope'         => self::SCOPE,
				) ),
				'timeout' => 30,
			),
			array(
				'currency' => $creds['currency'],
			)
		);

		if ( empty( $body['access_token'] ) ) {
			$msg = isset( $body['error_description'] ) ? $body['error_description'] : __( 'Failed to obtain PayU access token.', 'payu-payment-links-woocommerce' );
			throw new PayU_API_Exception( $msg, 0, array( 'endpoint' => 'token' ) );
		}

		$expires_in = isset( $body['expires_in'] ) ? (int) $body['expires_in'] : 3600;
		set_transient( $cache_key, array(
			'access_token' => $body['access_token'],
			'expires_at'   => time() + $expires_in,
		), max( $expires_in - 300, 60 ) );

		return $body['access_token'];
	}

	/* ---------------------------------------------------------------
	 * Helpers
	 * ------------------------------------------------------------- */

	/**
	 * Get environment string.
	 *
	 * @return string 'test' or 'prod'.
	 */
	private function get_env() {
		return PayU_Config::env();
	}

	/**
	 * Get Payment Links base URL for current environment.
	 *
	 * @return string
	 */
	private function get_base_url() {
		return 'test' === $this->get_env() ? self::PAYMENT_LINKS_URL_UAT : self::PAYMENT_LINKS_URL_PROD;
	}

	/**
	 * Execute remote request with retry + event logging.
	 *
	 * @param string $event_type Event type.
	 * @param string $method     GET/POST.
	 * @param string $url        URL.
	 * @param array  $args       Request args.
	 * @param array  $context    Additional event context.
	 * @return array
	 * @throws PayU_Transport_Exception When transport fails.
	 */
	private function request_with_retry( $event_type, $method, $url, array $args, array $context = array() ) {
		$attempt = 0;
		$max     = self::MAX_RETRIES + 1;
		$last    = null;

		while ( $attempt < $max ) {
			$attempt++;
			$response = 'GET' === strtoupper( $method ) ? wp_remote_get( $url, $args ) : wp_remote_post( $url, $args );
			$last     = $response;

			$is_error = function_exists( 'is_wp_error' ) && is_wp_error( $response );
			$code     = $is_error ? 0 : (int) wp_remote_retrieve_response_code( $response );
			$body     = $is_error ? '' : (string) wp_remote_retrieve_body( $response );
			$err_msg  = $is_error ? $response->get_error_message() : '';

			PayU_DB::log_event( array(
				'event_type'       => $event_type,
				'direction'        => 'outgoing',
				'endpoint'         => $url,
				'order_id'         => isset( $context['order_id'] ) ? (int) $context['order_id'] : null,
				'link_id'          => isset( $context['link_id'] ) ? (int) $context['link_id'] : null,
				'invoice_number'   => isset( $context['invoice_number'] ) ? (string) $context['invoice_number'] : null,
				'request_id'       => isset( $context['request_id'] ) ? (string) $context['request_id'] : null,
				'http_code'        => $code,
				'status'           => $is_error ? 'transport_error' : ( $code >= 200 && $code < 300 ? 'success' : 'http_error' ),
				'request_payload'  => isset( $args['body'] ) ? ( is_string( $args['body'] ) ? $args['body'] : wp_json_encode( $args['body'] ) ) : '',
				'response_payload' => $body,
				'error_message'    => $err_msg,
				'context_payload'  => wp_json_encode( array_merge( $context, array( 'attempt' => $attempt ) ) ),
			) );

			if ( ! $is_error && ! $this->is_retryable_http_code( $code ) ) {
				return $response;
			}
			if ( $is_error && $attempt < $max ) {
				usleep( 150000 * $attempt );
				continue;
			}
			if ( ! $is_error && $this->is_retryable_http_code( $code ) && $attempt < $max ) {
				usleep( 150000 * $attempt );
				continue;
			}
			break;
		}

		if ( function_exists( 'is_wp_error' ) && is_wp_error( $last ) ) {
			throw new PayU_Transport_Exception(
				$last->get_error_message(),
				0,
				array_merge( $context, array( 'endpoint' => $url, 'event_type' => $event_type ) )
			);
		}

		return $last;
	}

	/**
	 * Execute request and decode JSON body.
	 *
	 * @param string $event_type Event type.
	 * @param string $method     GET/POST.
	 * @param string $url        URL.
	 * @param array  $args       Request args.
	 * @param array  $context    Additional context.
	 * @return array
	 * @throws PayU_Plugin_Exception On request errors.
	 */
	private function request_json( $event_type, $method, $url, array $args, array $context = array() ) {
		$response = $this->request_with_retry( $event_type, $method, $url, $args, $context );
		$code     = wp_remote_retrieve_response_code( $response );
		$raw      = wp_remote_retrieve_body( $response );
		$body     = json_decode( $raw, true );

		if ( ! is_array( $body ) ) {
			// Distinguish a genuine empty/non-JSON response from a successful empty result.
			$body = array( '_json_parse_error' => true );
		}
		$body['_http_code'] = (int) $code;
		return $body;
	}

	/**
	 * Check if status code should trigger retry.
	 *
	 * @param int $code HTTP status code.
	 * @return bool
	 */
	private function is_retryable_http_code( $code ) {
		return in_array( (int) $code, array( 408, 425, 429, 500, 502, 503, 504 ), true );
	}

	/**
	 * Normalize address fields to PayU format.
	 *
	 * @param array $address Input address.
	 * @return array
	 */
	private function normalize_address( $address ) {
		return array(
			'line1'   => isset( $address['line1'] ) ? $address['line1'] : ( isset( $address['address1'] ) ? $address['address1'] : '' ),
			'line2'   => isset( $address['line2'] ) ? $address['line2'] : ( isset( $address['address2'] ) ? $address['address2'] : '' ),
			'city'    => isset( $address['city'] ) ? $address['city'] : '',
			'state'   => isset( $address['state'] ) ? $address['state'] : '',
			'zipCode' => isset( $address['zipCode'] ) ? $address['zipCode'] : ( isset( $address['zip'] ) ? $address['zip'] : '' ),
		);
	}

	/* ---------------------------------------------------------------
	 * Create Payment Link API
	 * ------------------------------------------------------------- */

	/**
	 * Create a payment link.
	 *
	 * @param array $args amount, description, currency, order_id, invoice_number, customer, address,
	 *                    success_url, failure_url, expiry_date, is_partial_payment_allowed.
	 * @return array paymentLink, invoiceNumber, totalAmount, expiryDate, currency.
	 * @throws Exception On API error.
	 */
	public function create_payment_link( array $args ) {
		$currency = isset( $args['currency'] ) ? $args['currency'] : null;
		$creds    = $this->get_credentials_for_currency( $currency );
		$token    = $this->get_token( $currency );

		$is_partial = isset( $args['is_partial_payment_allowed'] )
			? $args['is_partial_payment_allowed']
			: PayU_Config::is_partial_payment_enabled();

		$payload = array(
			'subAmount'               => (float) $args['amount'],
			'description'             => isset( $args['description'] ) ? $args['description'] : '',
			'source'                  => 'API',
			'isPartialPaymentAllowed' => $is_partial,
		);

		if ( ! empty( $args['invoice_number'] ) ) {
			$payload['invoiceNumber'] = $args['invoice_number'];
		}
		if ( ! empty( $creds['currency'] ) ) {
			$payload['currency'] = $creds['currency'];
		}
		if ( ! empty( $args['customer'] ) && is_array( $args['customer'] ) ) {
			$payload['customer'] = $args['customer'];
		}
		if ( ! empty( $args['address'] ) && is_array( $args['address'] ) ) {
			$payload['address'] = $this->normalize_address( $args['address'] );
		}
		if ( ! empty( $args['success_url'] ) ) {
			$payload['successURL'] = $args['success_url'];
		}
		if ( ! empty( $args['failure_url'] ) ) {
			$payload['failureURL'] = $args['failure_url'];
		}
		if ( ! empty( $args['expiry_date'] ) ) {
			$payload['expiryDate'] = $args['expiry_date'];
		}

		// PRD: udf5 must always be set for plugin-created links; udf1 = orderId when available.
		$payload['udf'] = array(
			'udf1' => ! empty( $args['order_id'] ) ? (string) $args['order_id'] : '',
			'udf5' => self::UDF5_SOURCE,
		);

		$body = $this->request_json( 'create_payment_link', 'POST', $this->get_base_url(), array(
			'headers' => array(
				'Content-Type'  => 'application/json',
				'Authorization' => 'Bearer ' . $token,
				'merchantId'    => $creds['merchant_id'],
			),
			'body'    => wp_json_encode( $payload ),
			'timeout' => 30,
		), array(
			'order_id'       => isset( $args['order_id'] ) ? (int) $args['order_id'] : 0,
			'invoice_number' => isset( $args['invoice_number'] ) ? (string) $args['invoice_number'] : '',
		) );

		if ( 200 !== (int) $body['_http_code'] ) {
			throw new PayU_API_Exception( isset( $body['message'] ) ? $body['message'] : __( 'PayU Create Payment Link request failed.', 'payu-payment-links-woocommerce' ), 0, array( 'endpoint' => 'create_payment_link' ) );
		}
		if ( isset( $body['status'] ) && 0 !== (int) $body['status'] ) {
			throw new PayU_API_Exception( isset( $body['msg'] ) ? $body['msg'] : __( 'PayU returned an error creating the payment link.', 'payu-payment-links-woocommerce' ), 0, array( 'endpoint' => 'create_payment_link' ) );
		}

		$result = isset( $body['result'] ) ? $body['result'] : $body;

		$payment_link   = isset( $result['paymentLink'] ) ? $result['paymentLink'] : '';
		$invoice_number = isset( $result['invoiceNumber'] ) ? $result['invoiceNumber'] : '';

		if ( empty( $payment_link ) || empty( $invoice_number ) ) {
			throw new PayU_API_Exception(
				__( 'PayU returned an incomplete response for Create Payment Link (missing paymentLink or invoiceNumber).', 'payu-payment-links-woocommerce' ),
				0,
				array( 'endpoint' => 'create_payment_link', 'result' => $result )
			);
		}

		return array(
			'paymentLink'   => $payment_link,
			'invoiceNumber' => $invoice_number,
			'totalAmount'   => isset( $result['totalAmount'] ) ? $result['totalAmount'] : $args['amount'],
			'expiryDate'    => isset( $result['expiryDate'] ) ? $result['expiryDate'] : '',
			'currency'      => $creds['currency'],
		);
	}

	/* ---------------------------------------------------------------
	 * Get Single Payment Link API
	 * ------------------------------------------------------------- */

	/**
	 * Fetch a single payment link from PayU.
	 *
	 * @param string      $invoice_number PayU invoice number.
	 * @param string|null $currency       Currency to resolve credentials.
	 * @return array PayU link data (result block).
	 * @throws Exception On API error.
	 */
	public function get_payment_link( $invoice_number, $currency = null ) {
		$creds = $this->get_credentials_for_currency( $currency );
		$token = $this->get_token( $currency );
		$url   = $this->get_base_url() . '/' . rawurlencode( $invoice_number );

		$body = $this->request_json( 'get_payment_link', 'GET', $url, array(
			'headers' => array(
				'Content-Type'  => 'application/json',
				'Authorization' => 'Bearer ' . $token,
				'merchantId'    => $creds['merchant_id'],
			),
			'timeout' => 30,
		), array(
			'invoice_number' => (string) $invoice_number,
		) );

		if ( 200 !== (int) $body['_http_code'] ) {
			throw new PayU_API_Exception( isset( $body['message'] ) ? $body['message'] : __( 'PayU Get Payment Link request failed.', 'payu-payment-links-woocommerce' ), 0, array( 'endpoint' => 'get_payment_link' ) );
		}
		if ( isset( $body['status'] ) && 0 !== (int) $body['status'] ) {
			throw new PayU_API_Exception( isset( $body['message'] ) ? $body['message'] : __( 'Payment link not found on PayU.', 'payu-payment-links-woocommerce' ), 0, array( 'endpoint' => 'get_payment_link' ) );
		}

		return isset( $body['result'] ) ? $body['result'] : $body;
	}

	/* ---------------------------------------------------------------
	 * Get All Payment Links API
	 * ------------------------------------------------------------- */

	/**
	 * List payment links from PayU for a date range.
	 *
	 * @param string      $date_from   yyyy-MM-dd.
	 * @param string      $date_to     yyyy-MM-dd.
	 * @param string|null $currency    Currency to resolve credentials.
	 * @param int         $page_offset Row offset.
	 * @param int         $page_size   Page size.
	 * @return array PayU response body.
	 * @throws Exception On API error.
	 */
	public function get_all_payment_links( $date_from, $date_to, $currency = null, $page_offset = 0, $page_size = 100 ) {
		$creds = $this->get_credentials_for_currency( $currency );
		$token = $this->get_token( $currency );
		$url   = add_query_arg( array(
			'dateFrom'   => $date_from,
			'dateTo'     => $date_to,
			'pageOffset' => $page_offset,
			'pageSize'   => $page_size,
			'orderBy'    => 'addedOn',
			'order'      => 'des',
		), $this->get_base_url() );

		$body = $this->request_json( 'get_all_payment_links', 'GET', $url, array(
			'headers' => array(
				'Content-Type'  => 'application/json',
				'Authorization' => 'Bearer ' . $token,
				'mid'           => $creds['merchant_id'],
			),
			'timeout' => 30,
		) );

		if ( 200 !== (int) $body['_http_code'] ) {
			throw new PayU_API_Exception( isset( $body['message'] ) ? $body['message'] : __( 'PayU Get All Payment Links request failed.', 'payu-payment-links-woocommerce' ), 0, array( 'endpoint' => 'get_all_payment_links' ) );
		}
		unset( $body['_http_code'] );

		return $body;
	}

	/* ---------------------------------------------------------------
	 * Share Payment Link API
	 * ------------------------------------------------------------- */

	/**
	 * Share a payment link via email/phone using PayU Share API.
	 *
	 * @param string      $invoice_number PayU invoice number.
	 * @param array       $channel_list   Array of email addresses and/or phone numbers.
	 * @param string|null $currency       Currency to resolve credentials.
	 * @return array PayU response body.
	 * @throws Exception On API error.
	 */
	public function share_payment_link( $invoice_number, array $channel_list, $currency = null ) {
		$creds = $this->get_credentials_for_currency( $currency );
		$token = $this->get_token( $currency );

		// channelList is passed as a comma-separated query parameter, no body, no Content-Type.
		$url = $this->get_base_url() . '/' . rawurlencode( $invoice_number ) . '/share'
			. '?channelList=' . rawurlencode( implode( ',', array_values( $channel_list ) ) );

		$body = $this->request_json( 'share_payment_link', 'POST', $url, array(
			'headers' => array(
				'Authorization' => 'Bearer ' . $token,
				'merchantId'    => $creds['merchant_id'],
			),
			'timeout' => 30,
		), array(
			'invoice_number' => (string) $invoice_number,
		) );

		if ( 200 !== (int) $body['_http_code'] ) {
			throw new PayU_API_Exception( isset( $body['message'] ) ? $body['message'] : __( 'PayU Share Payment Link request failed.', 'payu-payment-links-woocommerce' ), 0, array( 'endpoint' => 'share_payment_link' ) );
		}
		unset( $body['_http_code'] );

		return $body;
	}

	/* ---------------------------------------------------------------
	 * Expire Payment Link API
	 * ------------------------------------------------------------- */

	/**
	 * Expire a payment link on PayU by setting its expiryDate to the past.
	 *
	 * @param string      $invoice_number PayU invoice number.
	 * @param string|null $currency       Currency to resolve credentials.
	 * @return bool True on success.
	 * @throws PayU_API_Exception On API error.
	 */
	public function expire_payment_link( $invoice_number, $currency = null ) {
		$creds = $this->get_credentials_for_currency( $currency );
		$token = $this->get_token( $currency );
		$url   = $this->get_base_url() . '/' . rawurlencode( $invoice_number );

		// PayU requires PUT with active:false to deactivate a link.
		// Passing a past expiryDate is explicitly rejected by the API with
		// "expiry cannot be less than the current date".
		// wp_remote_post respects 'method' => 'PUT' in $args to send a real PUT request.
		// Header must be 'merchantId' (not 'mid') consistent with create/get endpoints.
		$body = $this->request_json( 'expire_payment_link', 'PUT', $url, array(
			'method'  => 'PUT',
			'headers' => array(
				'Content-Type'  => 'application/json',
				'Authorization' => 'Bearer ' . $token,
				'merchantId'    => $creds['merchant_id'],
			),
			'body'    => wp_json_encode( array( 'active' => false ) ),
			'timeout' => 20,
		), array(
			'invoice_number' => (string) $invoice_number,
		) );

		$http_code = isset( $body['_http_code'] ) ? (int) $body['_http_code'] : 0;
		if ( $http_code >= 200 && $http_code < 300 ) {
			return true;
		}
		if ( isset( $body['status'] ) && 0 !== (int) $body['status'] ) {
			throw new PayU_API_Exception(
				isset( $body['msg'] ) ? $body['msg'] : __( 'PayU returned an error while expiring the payment link.', 'payu-payment-links-woocommerce' ),
				0,
				array( 'endpoint' => 'expire_payment_link', 'invoice_number' => $invoice_number )
			);
		}
		throw new PayU_API_Exception(
			isset( $body['message'] ) ? $body['message'] : __( 'PayU expire payment link request failed.', 'payu-payment-links-woocommerce' ),
			0,
			array( 'endpoint' => 'expire_payment_link', 'http_code' => $http_code )
		);
	}

	/* ---------------------------------------------------------------
	 * Get Payment Link Transactions API (OAuth-based, no key/salt needed)
	 * ------------------------------------------------------------- */

	/**
	 * Get transactions for a payment link invoice. Used for polling payment status.
	 *
	 * @param string      $invoice_number PayU invoice number.
	 * @param string|null $currency       Currency to resolve credentials.
	 * @return array Transaction data array (result.data).
	 * @throws Exception On API error.
	 */
	public function get_payment_link_transactions( $invoice_number, $currency = null ) {
		$creds = $this->get_credentials_for_currency( $currency );
		$token = $this->get_token( $currency );

		$date_from = gmdate( 'Y-m-d', strtotime( '-90 days' ) );
		$date_to   = gmdate( 'Y-m-d', strtotime( '+1 day' ) );

		$url = add_query_arg( array(
			'dateFrom' => $date_from,
			'dateTo'   => $date_to,
			'pageSize' => 10,
		), $this->get_base_url() . '/' . rawurlencode( $invoice_number ) . '/txns' );

		$body = $this->request_json( 'get_payment_link_transactions', 'GET', $url, array(
			'headers' => array(
				'Authorization' => 'Bearer ' . $token,
				'merchantId'    => $creds['merchant_id'],
			),
			'timeout' => 30,
		), array(
			'invoice_number' => (string) $invoice_number,
		) );

		if ( 200 !== (int) $body['_http_code'] ) {
			throw new PayU_API_Exception( isset( $body['message'] ) ? $body['message'] : __( 'Get Transaction Details request failed.', 'payu-payment-links-woocommerce' ), 0, array( 'endpoint' => 'get_payment_link_transactions' ) );
		}

		if ( isset( $body['result']['data'] ) && is_array( $body['result']['data'] ) ) {
			return $body['result']['data'];
		}
		if ( isset( $body['result']['transactions'] ) && is_array( $body['result']['transactions'] ) ) {
			return $body['result']['transactions'];
		}
		if ( isset( $body['result'] ) && is_array( $body['result'] ) && isset( $body['result'][0] ) ) {
			return $body['result'];
		}
		if ( isset( $body['data'] ) && is_array( $body['data'] ) ) {
			return $body['data'];
		}

		return array();
	}

	/* ---------------------------------------------------------------
	 * Settlement Reconciliation API
	 * ------------------------------------------------------------- */

	/**
	 * Get settlement details for a date range (for UTR number retrieval).
	 *
	 * Uses merchant key + salt hash authentication (different from OAuth).
	 *
	 * @param string      $date_from yyyy-MM-dd.
	 * @param string      $date_to   yyyy-MM-dd.
	 * @param string|null $currency  Currency to resolve credentials.
	 * @return array Settlement results.
	 * @throws Exception On API error or missing credentials.
	 */
	public function get_settlement_details( $date_from, $date_to, $currency = null ) {
		$creds = $this->get_credentials_for_currency( $currency );

		if ( empty( $creds['merchant_key'] ) || empty( $creds['salt'] ) ) {
			throw new PayU_Configuration_Exception(
				__( 'Merchant Key and Salt are required for the Settlement API. Configure them in WooCommerce → Settings → PayU Payment Links.', 'payu-payment-links-woocommerce' )
			);
		}

		$command  = 'get_settlement_details_range';
		$hash_str = $creds['merchant_key'] . '|' . $command . '|' . $date_from . '|' . $creds['salt'];
		$hash     = hash( 'sha512', $hash_str );

		$env = $this->get_env();
		$url = 'test' === $env ? self::SETTLEMENT_URL_UAT : self::SETTLEMENT_URL_PROD;

		$post_body = array(
			'key'     => $creds['merchant_key'],
			'command' => $command,
			'var1'    => $date_from,
			'var2'    => $date_to,
			'hash'    => $hash,
		);

		$body = $this->request_json( 'get_settlement_details', 'POST', $url, array(
			'headers' => array( 'Content-Type' => 'application/x-www-form-urlencoded' ),
			'body'    => http_build_query( $post_body ),
			'timeout' => 60,
		) );

		if ( 200 !== (int) $body['_http_code'] || empty( $body ) ) {
			throw new PayU_API_Exception( __( 'Settlement API request failed.', 'payu-payment-links-woocommerce' ), 0, array( 'endpoint' => 'get_settlement_details' ) );
		}

		if ( isset( $body['status'] ) && 1 !== (int) $body['status'] ) {
			$msg = isset( $body['msg'] ) ? $body['msg'] : ( isset( $body['message'] ) ? $body['message'] : __( 'Settlement API returned an error.', 'payu-payment-links-woocommerce' ) );
			throw new PayU_API_Exception( $msg, 0, array( 'endpoint' => 'get_settlement_details' ) );
		}

		return isset( $body['result'] ) ? $body['result'] : array();
	}

	/* ---------------------------------------------------------------
	 * Refund Transaction API
	 * ------------------------------------------------------------- */

	/**
	 * Initiate a full or partial refund via PayU.
	 *
	 * @param string      $payu_txn_id  PayU transaction ID (mihpayid).
	 * @param float       $amount       Amount to refund (in major currency units, e.g. 100.00).
	 * @param string|null $currency     Currency to resolve credentials.
	 * @return array{request_id: string, msg: string} On success.
	 * @throws Exception On failure or missing credentials.
	 */
	public function refund_transaction( $payu_txn_id, $amount, $currency = null ) {
		$creds = $this->get_credentials_for_currency( $currency );

		if ( empty( $creds['merchant_key'] ) || empty( $creds['salt'] ) ) {
			throw new PayU_Configuration_Exception(
				__( 'Merchant Key and Salt are required for refunds. Configure them in WooCommerce → Settings → PayU Payment Links.', 'payu-payment-links-woocommerce' )
			);
		}

		$command      = 'cancel_refund_transaction';
		$refund_token = 'WCR' . substr( md5( $payu_txn_id . time() ), 0, 20 );
		$hash_str     = $creds['merchant_key'] . '|' . $command . '|' . $payu_txn_id . '|' . $creds['salt'];
		$hash         = hash( 'sha512', $hash_str );

		$env = $this->get_env();
		$url = 'test' === $env ? self::SETTLEMENT_URL_UAT : self::SETTLEMENT_URL_PROD;

		$post_body = array(
			'key'     => $creds['merchant_key'],
			'command' => $command,
			'var1'    => $payu_txn_id,
			'var2'    => $refund_token,
			'var3'    => number_format( $amount, 2, '.', '' ),
			'hash'    => $hash,
		);

		$body = $this->request_json( 'refund_transaction', 'POST', $url, array(
			'headers' => array( 'Content-Type' => 'application/x-www-form-urlencoded' ),
			'body'    => http_build_query( $post_body ),
			'timeout' => 60,
		), array(
			'request_id' => $refund_token,
		) );

		if ( 200 !== (int) $body['_http_code'] || empty( $body ) ) {
			throw new PayU_API_Exception( __( 'Refund API request failed.', 'payu-payment-links-woocommerce' ), 0, array( 'endpoint' => 'refund_transaction' ) );
		}

		$status     = isset( $body['status'] ) ? (int) $body['status'] : 0;
		$error_code = isset( $body['error_code'] ) ? (int) $body['error_code'] : 0;

		// error_code 102 is treated as success per PayU docs.
		if ( 1 !== $status && 102 !== $error_code ) {
			$msg = isset( $body['msg'] ) ? $body['msg'] : ( isset( $body['message'] ) ? $body['message'] : __( 'Refund request failed.', 'payu-payment-links-woocommerce' ) );
			throw new PayU_API_Exception( $msg, 0, array( 'endpoint' => 'refund_transaction' ) );
		}

		return array(
			'request_id'   => isset( $body['request_id'] ) ? $body['request_id'] : ( isset( $body['txn_update_id'] ) ? $body['txn_update_id'] : '' ),
			'msg'          => isset( $body['msg'] ) ? $body['msg'] : 'Refund Request Queued',
			'refund_token' => $refund_token,
		);
	}

	/* ---------------------------------------------------------------
	 * Check Refund Status API (with Request ID)
	 * ------------------------------------------------------------- */

	/**
	 * Check action/refund status by PayU transaction ID (mihpayid).
	 *
	 * @param string      $payu_txn_id PayU transaction ID (mihpayid).
	 * @param string|null $currency    Currency to resolve credentials.
	 * @return array Normalized list of refund actions (status, amt, request_id, action).
	 * @throws Exception On API error.
	 */
	public function check_action_status_by_payu_id( $payu_txn_id, $currency = null ) {
		$creds = $this->get_credentials_for_currency( $currency );

		if ( empty( $creds['merchant_key'] ) || empty( $creds['salt'] ) ) {
			throw new PayU_Configuration_Exception( __( 'Merchant Key and Salt are required.', 'payu-payment-links-woocommerce' ) );
		}
		if ( empty( $payu_txn_id ) ) {
			throw new PayU_Validation_Exception( __( 'PayU transaction ID is required.', 'payu-payment-links-woocommerce' ) );
		}

		$command  = 'check_action_status';
		$hash_str = $creds['merchant_key'] . '|' . $command . '|' . $payu_txn_id . '|' . $creds['salt'];
		$hash     = hash( 'sha512', $hash_str );

		$env = $this->get_env();
		$url = 'test' === $env ? self::SETTLEMENT_URL_UAT : self::SETTLEMENT_URL_PROD;

		$body = $this->request_json( 'check_action_status_by_payu_id', 'POST', $url, array(
			'headers' => array( 'Content-Type' => 'application/x-www-form-urlencoded' ),
			'body'    => http_build_query( array(
				'key'     => $creds['merchant_key'],
				'command' => $command,
				'var1'    => $payu_txn_id,
				'var2'    => 'payuid',
				'hash'    => $hash,
			) ),
			'timeout' => 30,
		), array(
			'request_id' => (string) $payu_txn_id,
		) );

		if ( 200 !== (int) $body['_http_code'] || empty( $body ) ) {
			throw new PayU_API_Exception( __( 'Check action status (PayU ID) API request failed.', 'payu-payment-links-woocommerce' ), 0, array( 'endpoint' => 'check_action_status_by_payu_id' ) );
		}

		if ( ! isset( $body['status'] ) || 1 !== (int) $body['status'] ) {
			throw new PayU_API_Exception( isset( $body['msg'] ) ? $body['msg'] : __( 'Action status not found for PayU ID.', 'payu-payment-links-woocommerce' ), 0, array( 'endpoint' => 'check_action_status_by_payu_id' ) );
		}

		$refund_actions = array();
		if ( isset( $body['transaction_details'] ) && is_array( $body['transaction_details'] ) ) {
			foreach ( $body['transaction_details'] as $txn_group ) {
				if ( ! is_array( $txn_group ) ) {
					continue;
				}
				foreach ( $txn_group as $action_row ) {
					if ( ! is_array( $action_row ) ) {
						continue;
					}
					$action = isset( $action_row['action'] ) ? strtolower( trim( (string) $action_row['action'] ) ) : '';
					if ( 'refund' !== $action ) {
						continue;
					}
					$status = isset( $action_row['status'] ) ? strtolower( trim( (string) $action_row['status'] ) ) : '';
					if ( ! $status ) {
						continue;
					}

					$refund_actions[] = array(
						'status'     => $status,
						'amt'        => isset( $action_row['amt'] ) ? (float) $action_row['amt'] : 0.0,
						'request_id' => isset( $action_row['request_id'] ) ? (string) $action_row['request_id'] : '',
						'action'     => $action,
					);
				}
			}
		}

		return $refund_actions;
	}

	/**
	 * Check the status of a refund request.
	 *
	 * @param string      $request_id PayU refund request ID.
	 * @param string|null $currency   Currency to resolve credentials.
	 * @return string Refund status: queued, success, failure, in_progress, requested, pending.
	 * @throws Exception On API error.
	 */
	public function check_refund_status( $request_id, $currency = null ) {
		$creds = $this->get_credentials_for_currency( $currency );

		if ( empty( $creds['merchant_key'] ) || empty( $creds['salt'] ) ) {
			throw new PayU_Configuration_Exception( __( 'Merchant Key and Salt are required.', 'payu-payment-links-woocommerce' ) );
		}

		$command  = 'check_action_status';
		$hash_str = $creds['merchant_key'] . '|' . $command . '|' . $request_id . '|' . $creds['salt'];
		$hash     = hash( 'sha512', $hash_str );

		$env = $this->get_env();
		$url = 'test' === $env ? self::SETTLEMENT_URL_UAT : self::SETTLEMENT_URL_PROD;

		$body = $this->request_json( 'check_refund_status', 'POST', $url, array(
			'headers' => array( 'Content-Type' => 'application/x-www-form-urlencoded' ),
			'body'    => http_build_query( array(
				'key'     => $creds['merchant_key'],
				'command' => $command,
				'var1'    => $request_id,
				'hash'    => $hash,
			) ),
			'timeout' => 30,
		), array(
			'request_id' => (string) $request_id,
		) );

		if ( 200 !== (int) $body['_http_code'] || empty( $body ) ) {
			throw new PayU_API_Exception( __( 'Check refund status API request failed.', 'payu-payment-links-woocommerce' ), 0, array( 'endpoint' => 'check_refund_status' ) );
		}

		if ( ! isset( $body['status'] ) || 1 !== (int) $body['status'] ) {
			throw new PayU_API_Exception( isset( $body['msg'] ) ? $body['msg'] : __( 'Refund status not found.', 'payu-payment-links-woocommerce' ), 0, array( 'endpoint' => 'check_refund_status' ) );
		}

		// Extract status from nested transaction_details structure.
		$refund_status = '';
		if ( isset( $body['transaction_details'] ) && is_array( $body['transaction_details'] ) ) {
			foreach ( $body['transaction_details'] as $txn_group ) {
				if ( is_array( $txn_group ) ) {
					foreach ( $txn_group as $detail ) {
						if ( is_array( $detail ) && isset( $detail['status'] ) ) {
							$refund_status = strtolower( trim( $detail['status'] ) );
							break 2;
						}
					}
				}
			}
		}

		if ( ! $refund_status ) {
			throw new PayU_API_Exception( __( 'Could not determine refund status from response.', 'payu-payment-links-woocommerce' ), 0, array( 'endpoint' => 'check_refund_status' ) );
		}

		return $refund_status;
	}
}
