<?php
/**
 * PayU webhook handler: callback endpoint, reverse hash verification, order + DB status update.
 *
 * @package PayU_Payment_Links_WooCommerce
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class PayU_Webhook_Handler
 */
class PayU_Webhook_Handler {

	/**
	 * Check if the current request is a PayU webhook and handle it.
	 */
	public static function maybe_handle() {
		$value = get_query_var( 'payu_payment_link_webhook', null );
		if ( empty( $value ) && isset( $_GET['payu_payment_link_webhook'] ) ) {
			$value = sanitize_text_field( wp_unslash( $_GET['payu_payment_link_webhook'] ) );
		}
		if ( '1' !== $value && 'payu_payment_link_webhook' !== $value ) {
			return;
		}
		self::handle();
		exit;
	}

	/**
	 * Process incoming PayU callback.
	 */
	private static function handle() {
		// Block webhooks when merchant has no key/salt (relies on polling instead).
		if ( PayU_Config::is_no_key_salt_mode() ) {
			self::respond( 200, 'OK' );
			return;
		}

		$raw = file_get_contents( 'php://input' );
		if ( empty( $raw ) ) {
			self::respond( 400, 'Empty body' );
			return;
		}

		$data = array();
		parse_str( $raw, $data );
		if ( empty( $data ) || ! isset( $data['txnid'] ) ) {
			$json = json_decode( $raw, true );
			if ( is_array( $json ) ) {
				$data = $json;
			}
		}
		PayU_DB::log_event( array(
			'event_type'       => 'webhook_callback',
			'direction'        => 'incoming',
			'endpoint'         => 'payu_payment_link_webhook',
			'request_payload'  => $raw,
			'response_payload' => wp_json_encode( $data ),
			'status'           => 'received',
		) );

		// Normalise shape before hash check so UDF flattening is applied once.
		$data = self::normalize_payload( $data );

		if ( ! self::verify_reverse_hash( $data ) ) {
			self::respond( 401, 'Invalid hash' );
			return;
		}

		$txnid            = isset( $data['txnid'] ) ? sanitize_text_field( $data['txnid'] ) : ( isset( $data['mihpayid'] ) ? sanitize_text_field( $data['mihpayid'] ) : '' );
		$status           = isset( $data['status'] ) ? sanitize_text_field( $data['status'] ) : '';
		$amount           = isset( $data['amount'] ) ? $data['amount'] : '';
		$invoice          = isset( $data['invoiceNumber'] ) ? sanitize_text_field( $data['invoiceNumber'] ) : '';
		$order_id_from_udf = ( isset( $data['udf1'] ) && is_numeric( $data['udf1'] ) ) ? (int) $data['udf1'] : 0;

		if ( ! $invoice && ! $txnid ) {
			self::respond( 200, 'OK' );
			return;
		}

		$link = null;
		if ( $invoice ) {
			$link = PayU_DB::get_by_invoice( $invoice );
		}
		if ( ! $link && $txnid ) {
			$link = PayU_DB::get_by_txn_id( $txnid );
		}
		if ( ! $link && $order_id_from_udf > 0 ) {
			$by_order = PayU_DB::get_by_order( $order_id_from_udf );
			if ( ! empty( $by_order ) ) {
				// Prefer an unresolved link first, otherwise latest record.
				foreach ( $by_order as $candidate ) {
					$candidate_payment = isset( $candidate->payment_status ) ? (string) $candidate->payment_status : '';
					if ( in_array( $candidate_payment, array( 'pending', 'failed', 'partially_paid' ), true ) ) {
						$link = $candidate;
						break;
					}
				}
				if ( ! $link ) {
					$link = $by_order[0];
				}
				if ( empty( $invoice ) && ! empty( $link->invoice_number ) ) {
					$invoice = (string) $link->invoice_number;
				}
			}
		}

		$order_id = null;
		if ( $link && $link->order_id ) {
			$order_id = (int) $link->order_id;
		} elseif ( $invoice ) {
			$order_id = self::order_id_from_invoice( $invoice );
		} elseif ( $order_id_from_udf > 0 ) {
			$order_id = $order_id_from_udf;
		}

		$order      = $order_id ? wc_get_order( $order_id ) : null;
		$is_success = in_array( strtolower( $status ), array( 'success', 'credited' ), true );
		$is_failure = in_array( strtolower( $status ), array( 'failure', 'failed', 'declined', 'cancelled', 'canceled' ), true );
		$order_total     = ( $order && is_a( $order, 'WC_Order' ) ) ? (float) $order->get_total() : ( $link && isset( $link->amount ) ? (float) $link->amount : 0.0 );
		$webhook_amount  = is_numeric( $amount ) ? (float) $amount : 0.0;
		$collected_amount = $webhook_amount;

		// Respond 200 immediately to prevent delivery timeouts.
		// For success payloads, reconciliation (get_payment_link + get_payment_link_transactions)
		// is deferred to a one-off WP-Cron event so the webhook connection is released fast.
		if ( $is_success && $link ) {
			$invoice_for_reconcile = ! empty( $link->invoice_number ) ? (string) $link->invoice_number : (string) $invoice;
			if ( '' !== $invoice_for_reconcile ) {
				// Store txnid immediately so refunds can proceed even before reconciliation.
				if ( $txnid ) {
					PayU_DB::update( $link->id, array( 'payu_txn_id' => $txnid ) );
				}
				// Schedule deferred reconciliation (runs within the next WP-Cron cycle).
				wp_schedule_single_event( time(), 'payu_payment_links_webhook_reconcile', array(
					(int) $link->id,
					$invoice_for_reconcile,
					(float) $webhook_amount,
				) );
				self::respond( 200, 'OK' );
				return;
			}
		}

		$outcome = PayU_Payment_Links::resolve_payment_outcome( $order_total, $collected_amount, $is_success );

		// Log dedicated failure event before state machine (so it is always auditable).
		if ( $is_failure ) {
			PayU_DB::log_event( array(
				'event_type'      => 'webhook_payment_failed',
				'direction'       => 'incoming',
				'endpoint'        => 'payu_payment_link_webhook',
				'order_id'        => $order_id ? (int) $order_id : null,
				'link_id'         => $link ? (int) $link->id : null,
				'invoice_number'  => $invoice ?: null,
				'request_id'      => $txnid ?: null,
				'http_code'       => null,
				'status'          => 'payment_failed',
				'request_payload' => wp_json_encode( array( 'status' => $status, 'txnid' => $txnid, 'amount' => $amount ) ),
			) );
		}

		if ( $link ) {
			$extra = array();
			if ( $txnid ) {
				$extra['payu_txn_id'] = $txnid;
			}
			if ( $is_success && $collected_amount > 0 ) {
				$extra['paid_amount'] = round( $collected_amount, 2 );
			}

			if ( $is_success ) {
				$note = 'paid' === $outcome['payment_status']
					? sprintf( __( 'PayU payment successful. Transaction ID: %s. Amount: %s.', 'payu-payment-links-woocommerce' ), $txnid, $amount )
					: sprintf( __( 'PayU partial payment successful. Collected: %1$s of %2$s. Transaction ID: %3$s.', 'payu-payment-links-woocommerce' ), number_format( $collected_amount, 2 ), number_format( $order_total, 2 ), $txnid );

				PayU_Payment_Links::transition_payment_status( (int) $link->id, $outcome['payment_status'], $extra, $note );
			} elseif ( $is_failure ) {
				// Allow failure transition even without txnid so status is always recorded.
				$failure_note = $txnid
					? sprintf( __( 'PayU payment failed. Status: %s. Transaction ID: %s.', 'payu-payment-links-woocommerce' ), $status, $txnid )
					: sprintf( __( 'PayU payment failed. Status: %s. No transaction ID received.', 'payu-payment-links-woocommerce' ), $status );
				$transitioned = PayU_Payment_Links::transition_payment_status( (int) $link->id, 'failed', $extra, $failure_note );
				// If transition was blocked by state machine, still add an order note so failure is visible.
				if ( ! $transitioned && $link->order_id ) {
					$order_for_note = wc_get_order( (int) $link->order_id );
					if ( $order_for_note ) {
						$order_for_note->add_order_note(
							sprintf( __( 'PayU payment failure received (state transition blocked). Status: %s. Transaction ID: %s.', 'payu-payment-links-woocommerce' ), $status, $txnid ?: __( 'N/A', 'payu-payment-links-woocommerce' ) )
						);
					}
				}
			} elseif ( ! empty( $extra ) ) {
				PayU_DB::update( $link->id, $extra );
			}
		}

		self::respond( 200, 'OK' );
	}

	/**
	 * Normalize a raw PayU webhook payload for hash verification.
	 *
	 * PayU Payment Links server callbacks can deliver UDFs either as top-level
	 * keys (form-encoded) or nested under a "udf" object (JSON). This method
	 * flattens nested UDFs and aliases camelCase/alternative key names so
	 * verify_reverse_hash always receives a consistent flat array.
	 *
	 * @param array $data Raw parsed payload.
	 * @return array Normalized payload.
	 */
	private static function normalize_payload( array $data ) {
		// Flatten nested udf object e.g. {"udf":{"udf1":"123","udf5":"WooCommerce_paymentlink"}}.
		if ( isset( $data['udf'] ) && is_array( $data['udf'] ) ) {
			foreach ( array( 'udf1', 'udf2', 'udf3', 'udf4', 'udf5' ) as $key ) {
				if ( isset( $data['udf'][ $key ] ) && ! isset( $data[ $key ] ) ) {
					$data[ $key ] = $data['udf'][ $key ];
				}
			}
		}

		// Alias camelCase variants PayU sometimes sends in JSON callbacks.
		$aliases = array(
			'firstName'   => 'firstname',
			'first_name'  => 'firstname',
			'productInfo' => 'productinfo',
			'product_info' => 'productinfo',
			'txnId'        => 'txnid',
			'mihpayid'     => 'txnid', // fallback alias; only used if txnid absent.
		);
		foreach ( $aliases as $camel => $canonical ) {
			if ( isset( $data[ $camel ] ) && ! isset( $data[ $canonical ] ) ) {
				$data[ $canonical ] = $data[ $camel ];
			}
		}

		// PayU may send amount as float (40.0); keep raw string for hash but
		// normalise trailing zeros so "40" and "40.00" both work when compared
		// against our stored value — hash uses whatever PayU sent, so we use raw.
		// (No mutation of amount here: we keep $data['amount'] exactly as received.)

		return $data;
	}

	/**
	 * Verify callback using PayU reverse hash formula.
	 *
	 * Formula: sha512(SALT|status||||||udf5|udf4|udf3|udf2|udf1|email|firstname|productinfo|amount|txnid|key)
	 *
	 * @param array $data Parsed callback data.
	 * @return bool
	 */
	private static function verify_reverse_hash( $data ) {
		// Skip verification only when the plugin is explicitly in no-key/salt mode.
		// Do NOT skip when keys exist but happen to be empty due to misconfiguration.
		if ( PayU_Config::is_no_key_salt_mode() ) {
			return true;
		}

		$creds = PayU_Config::credentials();
		$key   = isset( $creds['merchant_key'] ) ? trim( (string) $creds['merchant_key'] ) : '';
		$salt  = isset( $creds['salt'] ) ? trim( (string) $creds['salt'] ) : '';

		if ( empty( $key ) || empty( $salt ) ) {
			// Credentials configured but incomplete — reject rather than accept unauthenticated callbacks.
			return false;
		}

		if ( ! isset( $data['hash'] ) || empty( $data['hash'] ) ) {
			return false;
		}

		$received_hash = $data['hash'];

		// Normalise payload shape before extracting fields.
		$data = self::normalize_payload( $data );

		$status      = isset( $data['status'] ) ? $data['status'] : '';
		$udf5        = isset( $data['udf5'] ) ? $data['udf5'] : '';
		$udf4        = isset( $data['udf4'] ) ? $data['udf4'] : '';
		$udf3        = isset( $data['udf3'] ) ? $data['udf3'] : '';
		$udf2        = isset( $data['udf2'] ) ? $data['udf2'] : '';
		$udf1        = isset( $data['udf1'] ) ? $data['udf1'] : '';
		$email       = isset( $data['email'] ) ? $data['email'] : '';
		$firstname   = isset( $data['firstname'] ) ? $data['firstname'] : '';
		$productinfo = isset( $data['productinfo'] ) ? $data['productinfo'] : '';
		$amount      = isset( $data['amount'] ) ? $data['amount'] : '';
		$txnid       = isset( $data['txnid'] ) ? $data['txnid'] : '';

		$additional_charges = isset( $data['additionalCharges'] ) ? $data['additionalCharges'] : '';

		if ( $additional_charges ) {
			$hash_string = $additional_charges . '|' . $salt . '|' . $status . '||||||' . $udf5 . '|' . $udf4 . '|' . $udf3 . '|' . $udf2 . '|' . $udf1 . '|' . $email . '|' . $firstname . '|' . $productinfo . '|' . $amount . '|' . $txnid . '|' . $key;
		} else {
			$hash_string = $salt . '|' . $status . '||||||' . $udf5 . '|' . $udf4 . '|' . $udf3 . '|' . $udf2 . '|' . $udf1 . '|' . $email . '|' . $firstname . '|' . $productinfo . '|' . $amount . '|' . $txnid . '|' . $key;
		}

		$expected_hash = hash( 'sha512', $hash_string );

		return hash_equals( $expected_hash, $received_hash );
	}

	/**
	 * Extract WooCommerce order ID from invoice string.
	 *
	 * @param string $invoice Invoice number.
	 * @return int|null
	 */
	private static function order_id_from_invoice( $invoice ) {
		if ( preg_match( '/^WC[- ]?(\d+)/i', trim( $invoice ), $m ) ) {
			return (int) $m[1];
		}
		// Do not coerce a bare numeric string to an order ID — it may be a PayU
		// numeric invoice that does not correspond to a WC order ID.
		return null;
	}

	/**
	 * Send HTTP response.
	 *
	 * @param int    $code HTTP code.
	 * @param string $body Body.
	 */
	private static function respond( $code, $body ) {
		status_header( $code );
		echo esc_html( $body );
	}
}
