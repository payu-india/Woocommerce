<?php
/**
 * Fired when the plugin is uninstalled.
 *
 * @package PayU_Payment_Links_WooCommerce
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

// Intentionally preserve all plugin data/options on uninstall so merchants can
// reinstall and continue with existing payment links, mappings, and history.

// Cron — clear recurring and any pending single-event jobs.
wp_clear_scheduled_hook( 'payu_payment_links_fetch_utr' );
wp_clear_scheduled_hook( 'payu_payment_links_poll_refunds' );
wp_clear_scheduled_hook( 'payu_payment_links_poll_txns' );
wp_unschedule_hook( 'payu_payment_links_webhook_reconcile' );
